/* Linear Systems */
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_model.h"
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* linear systems */

/*
equation index: 586
type: SIMPLE_ASSIGN
$DER.$DER.surgeTank.M = surgeTank.m * $DER.$DER.surgeTank.v + surgeTank.mdot * $DER.surgeTank.v + surgeTank.mdot * $DER.surgeTank.v + $DER.surgeTank.mdot * surgeTank.v
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_586(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,586};
  (data->localData[0]->realVars[18] /* der(der(surgeTank.M)) DUMMY_DER */) = ((data->localData[0]->realVars[2] /* surgeTank.m STATE(1,surgeTank.mdot) */)) * ((data->localData[0]->realVars[21] /* der(der(surgeTank.v)) DUMMY_DER */)) + ((data->localData[0]->realVars[151] /* surgeTank.mdot DUMMY_STATE */)) * ((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)) + ((data->localData[0]->realVars[151] /* surgeTank.mdot DUMMY_STATE */)) * ((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)) + ((data->localData[0]->realVars[55] /* der(surgeTank.mdot) DUMMY_DER */)) * ((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 587
type: SIMPLE_ASSIGN
$DER.$DER.surgeTank.Vdot = $DER.$DER.surgeTank.v * surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_587(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,587};
  (data->localData[0]->realVars[19] /* der(der(surgeTank.Vdot)) DUMMY_DER */) = ((data->localData[0]->realVars[21] /* der(der(surgeTank.v)) DUMMY_DER */)) * ((data->localData[0]->realVars[138] /* surgeTank.A variable */));
  TRACE_POP
}
/*
equation index: 588
type: SIMPLE_ASSIGN
$DER.$DER.surgeTank.mdot = data.rho * $DER.$DER.surgeTank.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_588(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,588};
  (data->localData[0]->realVars[20] /* der(der(surgeTank.mdot)) DUMMY_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->localData[0]->realVars[19] /* der(der(surgeTank.Vdot)) DUMMY_DER */));
  TRACE_POP
}
/*
equation index: 589
type: SIMPLE_ASSIGN
$DER.surgeTank.F = $DER.$DER.surgeTank.M - $DER.surgeTank.Mdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_589(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,589};
  (data->localData[0]->realVars[47] /* der(surgeTank.F) DUMMY_DER */) = (data->localData[0]->realVars[18] /* der(der(surgeTank.M)) DUMMY_DER */) - (data->localData[0]->realVars[52] /* der(surgeTank.Mdot) DUMMY_DER */);
  TRACE_POP
}
/*
equation index: 590
type: SIMPLE_ASSIGN
$DER.surgeTank.F_p = $DER.surgeTank.F - ((-$DER.surgeTank.F_f) - $DER.surgeTank.F_g)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_590(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,590};
  (data->localData[0]->realVars[50] /* der(surgeTank.F_p) DUMMY_DER */) = (data->localData[0]->realVars[47] /* der(surgeTank.F) DUMMY_DER */) - ((-(data->localData[0]->realVars[48] /* der(surgeTank.F_f) DUMMY_DER */)) - (data->localData[0]->realVars[49] /* der(surgeTank.F_g) DUMMY_DER */));
  TRACE_POP
}
/*
equation index: 591
type: SIMPLE_ASSIGN
$DER.intake.p_o = $DER.surgeTank.F_p / surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_591(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,591};
  (data->localData[0]->realVars[40] /* der(intake.p_o) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[50] /* der(surgeTank.F_p) DUMMY_DER */),(data->localData[0]->realVars[138] /* surgeTank.A variable */),"surgeTank.A",equationIndexes);
  TRACE_POP
}
/*
equation index: 592
type: SIMPLE_ASSIGN
$DER.$DER.intake.M = 2.0 * data.rho * intake.Vdot * $DER.intake.Vdot * (1.0 / intake.A_i + (-1.0) / intake.A_o) + (-$DER.intake.F_f) - $DER.intake.p_o * intake.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_592(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,592};
  (data->localData[0]->realVars[13] /* der(der(intake.M)) DUMMY_DER */) = (2.0) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[110] /* intake.Vdot DUMMY_STATE */)) * (((data->localData[0]->realVars[38] /* der(intake.Vdot) DUMMY_DER */)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[106] /* intake.A_i variable */),"intake.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[107] /* intake.A_o variable */),"intake.A_o",equationIndexes))))) + (-(data->localData[0]->realVars[37] /* der(intake.F_f) DUMMY_DER */)) - (((data->localData[0]->realVars[40] /* der(intake.p_o) DUMMY_DER */)) * ((data->localData[0]->realVars[107] /* intake.A_o variable */)));
  TRACE_POP
}
/*
equation index: 593
type: SIMPLE_ASSIGN
$DER.$DER.intake.Vdot = $DER.$DER.intake.M / (data.rho * intake.L)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_593(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,593};
  (data->localData[0]->realVars[14] /* der(der(intake.Vdot)) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[13] /* der(der(intake.M)) DUMMY_DER */),((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->simulationInfo->realParameter[62] /* intake.L PARAM */)),"data.rho * intake.L",equationIndexes);
  TRACE_POP
}
/*
equation index: 594
type: SIMPLE_ASSIGN
$DER.$DER.intake.mdot = $DER.$DER.intake.Vdot * data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_594(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,594};
  (data->localData[0]->realVars[15] /* der(der(intake.mdot)) DUMMY_DER */) = ((data->localData[0]->realVars[14] /* der(der(intake.Vdot)) DUMMY_DER */)) * ((data->simulationInfo->realParameter[47] /* data.rho PARAM */));
  TRACE_POP
}
/*
equation index: 595
type: SIMPLE_ASSIGN
$DER.$DER.discharge.mdot = $DER.$DER.intake.mdot - $DER.$DER.surgeTank.mdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_595(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,595};
  (data->localData[0]->realVars[12] /* der(der(discharge.mdot)) DUMMY_DER */) = (data->localData[0]->realVars[15] /* der(der(intake.mdot)) DUMMY_DER */) - (data->localData[0]->realVars[20] /* der(der(surgeTank.mdot)) DUMMY_DER */);
  TRACE_POP
}
/*
equation index: 596
type: SIMPLE_ASSIGN
$DER.$DER.discharge.Vdot = $DER.$DER.discharge.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_596(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,596};
  (data->localData[0]->realVars[11] /* der(der(discharge.Vdot)) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[12] /* der(der(discharge.mdot)) DUMMY_DER */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes);
  TRACE_POP
}
/*
equation index: 597
type: SIMPLE_ASSIGN
$DER.$DER.discharge.M = data.rho * discharge.L * $DER.$DER.discharge.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_597(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,597};
  (data->localData[0]->realVars[10] /* der(der(discharge.M)) DUMMY_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[51] /* discharge.L PARAM */)) * ((data->localData[0]->realVars[11] /* der(der(discharge.Vdot)) DUMMY_DER */)));
  TRACE_POP
}
/*
equation index: 598
type: SIMPLE_ASSIGN
$DER.discharge.p_i = ($DER.$DER.discharge.M - (2.0 * data.rho * discharge.Vdot * $DER.discharge.Vdot * (1.0 / discharge.A_i + (-1.0) / discharge.A_o) - $DER.discharge.F_f)) / discharge.A_i
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_598(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,598};
  (data->localData[0]->realVars[32] /* der(discharge.p_i) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[10] /* der(der(discharge.M)) DUMMY_DER */) - ((2.0) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[94] /* discharge.Vdot DUMMY_STATE */)) * (((data->localData[0]->realVars[30] /* der(discharge.Vdot) DUMMY_DER */)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[89] /* discharge.A_i variable */),"discharge.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[90] /* discharge.A_o variable */),"discharge.A_o",equationIndexes))))) - (data->localData[0]->realVars[28] /* der(discharge.F_f) DUMMY_DER */)),(data->localData[0]->realVars[89] /* discharge.A_i variable */),"discharge.A_i",equationIndexes);
  TRACE_POP
}
/*
equation index: 599
type: SIMPLE_ASSIGN
$DER.$DER.penstock.Vdot = $DER.$DER.discharge.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_599(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,599};
  (data->localData[0]->realVars[17] /* der(der(penstock.Vdot)) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[12] /* der(der(discharge.mdot)) DUMMY_DER */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes);
  TRACE_POP
}
/*
equation index: 600
type: SIMPLE_ASSIGN
$DER.$DER.penstock.M = data.rho * penstock.L * $DER.$DER.penstock.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_600(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,600};
  (data->localData[0]->realVars[16] /* der(der(penstock.M)) DUMMY_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[69] /* penstock.L PARAM */)) * ((data->localData[0]->realVars[17] /* der(der(penstock.Vdot)) DUMMY_DER */)));
  TRACE_POP
}
/*
equation index: 601
type: SIMPLE_ASSIGN
$DER.penstock.p_o = (2.0 * data.rho * penstock.Vdot * $DER.penstock.Vdot * (1.0 / penstock.A_i + (-1.0) / penstock.A_o) + $DER.intake.p_o * penstock.A_i - $DER.penstock.F_f - $DER.$DER.penstock.M) / penstock.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_601(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,601};
  (data->localData[0]->realVars[44] /* der(penstock.p_o) DUMMY_DER */) = DIVISION_SIM((2.0) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[123] /* penstock.Vdot DUMMY_STATE */)) * (((data->localData[0]->realVars[43] /* der(penstock.Vdot) DUMMY_DER */)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[119] /* penstock.A_i variable */),"penstock.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[120] /* penstock.A_o variable */),"penstock.A_o",equationIndexes))))) + ((data->localData[0]->realVars[40] /* der(intake.p_o) DUMMY_DER */)) * ((data->localData[0]->realVars[119] /* penstock.A_i variable */)) - (data->localData[0]->realVars[42] /* der(penstock.F_f) DUMMY_DER */) - (data->localData[0]->realVars[16] /* der(der(penstock.M)) DUMMY_DER */),(data->localData[0]->realVars[120] /* penstock.A_o variable */),"penstock.A_o",equationIndexes);
  TRACE_POP
}
/*
equation index: 602
type: SIMPLE_ASSIGN
$DER.turbine1.Vdot = if turbine1.WaterCompress then data.rho * ($DER.discharge.mdot * (1.0 + data.beta * (penstock.p_o - data.p_a)) - discharge.mdot * data.beta * $DER.penstock.p_o) / (data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 2.0 else $DER.discharge.mdot * data.rho / data.rho ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_602(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,602};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_boolean tmp2;
  modelica_real tmp3;
  tmp2 = (modelica_boolean)(data->simulationInfo->booleanParameter[15] /* turbine1.WaterCompress PARAM */);
  if(tmp2)
  {
    tmp0 = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (1.0 + ((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->simulationInfo->realParameter[45] /* data.p_a PARAM */)));
    tmp3 = DIVISION_SIM(((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[31] /* der(discharge.mdot) DUMMY_DER */)) * (1.0 + ((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->simulationInfo->realParameter[45] /* data.p_a PARAM */))) - (((data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */)) * (((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[44] /* der(penstock.p_o) DUMMY_DER */))))),(tmp0 * tmp0),"(data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 2.0",equationIndexes);
  }
  else
  {
    tmp1 = (data->simulationInfo->realParameter[47] /* data.rho PARAM */);
    tmp3 = DIVISION_SIM(((data->localData[0]->realVars[31] /* der(discharge.mdot) DUMMY_DER */)) * ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)),(tmp1 * tmp1),"data.rho ^ 2.0",equationIndexes);
  }
  (data->localData[0]->realVars[58] /* der(turbine1.Vdot) DUMMY_DER */) = tmp3;
  TRACE_POP
}
/*
equation index: 603
type: SIMPLE_ASSIGN
$DER.turbine1.dp = 2.0 * (turbine1.Vdot ^ 2.0 * (-data.p_a) * turbine1.C_v_ ^ 2.0 * turbine1.look_up_table.u[1] * $DER.turbine1.look_up_table.u[1] / (turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 4.0 + turbine1.Vdot * $DER.turbine1.Vdot * data.p_a / (turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_603(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,603};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  tmp0 = (data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */);
  tmp1 = (data->localData[0]->realVars[162] /* turbine1.C_v_ variable */);
  tmp2 = ((data->localData[0]->realVars[162] /* turbine1.C_v_ variable */)) * ((data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */));
  tmp2 *= tmp2;tmp3 = ((data->localData[0]->realVars[162] /* turbine1.C_v_ variable */)) * ((data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */));
  (data->localData[0]->realVars[60] /* der(turbine1.dp) DUMMY_DER */) = (2.0) * (((tmp0 * tmp0)) * (((-(data->simulationInfo->realParameter[45] /* data.p_a PARAM */))) * (((tmp1 * tmp1)) * (((data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */)) * (DIVISION_SIM((data->localData[0]->realVars[63] /* der(turbine1.look_up_table.u[1]) DUMMY_DER */),(tmp2 * tmp2),"(turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 4.0",equationIndexes))))) + ((data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */)) * (((data->localData[0]->realVars[58] /* der(turbine1.Vdot) DUMMY_DER */)) * (DIVISION_SIM((data->simulationInfo->realParameter[45] /* data.p_a PARAM */),(tmp3 * tmp3),"(turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0",equationIndexes))));
  TRACE_POP
}

void residualFunc621(RESIDUAL_USERDATA* userData, const double* xloc, double* res, const int* iflag)
{
  TRACE_PUSH
  DATA *data = userData->data;
  threadData_t *threadData = userData->threadData;
  const int equationIndexes[2] = {1,621};
  ANALYTIC_JACOBIAN* jacobian = NULL;
  (data->localData[0]->realVars[21] /* der(der(surgeTank.v)) DUMMY_DER */) = xloc[0];
  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_586(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_587(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_588(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_589(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_590(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_591(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_592(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_593(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_594(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_595(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_596(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_597(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_598(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_599(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_600(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_601(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_602(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_603(data, threadData);
  res[0] = (data->localData[0]->realVars[44] /* der(penstock.p_o) DUMMY_DER */) + (-(data->localData[0]->realVars[32] /* der(discharge.p_i) DUMMY_DER */)) - (data->localData[0]->realVars[60] /* der(turbine1.dp) DUMMY_DER */);
  TRACE_POP
}
OMC_DISABLE_OPT
void initializeStaticLSData621(DATA* data, threadData_t* threadData, LINEAR_SYSTEM_DATA* linearSystemData, modelica_boolean initSparsePattern)
{
  int i=0;
  /* static ls data for der(der(surgeTank.v)) */
  linearSystemData->nominal[i] = data->modelData->realVarsData[21].attribute /* der(der(surgeTank.v)) */.nominal;
  linearSystemData->min[i]     = data->modelData->realVarsData[21].attribute /* der(der(surgeTank.v)) */.min;
  linearSystemData->max[i++]   = data->modelData->realVarsData[21].attribute /* der(der(surgeTank.v)) */.max;
}


/*
equation index: 378
type: SIMPLE_ASSIGN
$DER.$DER.surgeTank.M = surgeTank.m * $DER.$DER.surgeTank.v + surgeTank.mdot * $DER.surgeTank.v + surgeTank.mdot * $DER.surgeTank.v + $DER.surgeTank.mdot * surgeTank.v
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_378(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,378};
  (data->localData[0]->realVars[18] /* der(der(surgeTank.M)) DUMMY_DER */) = ((data->localData[0]->realVars[2] /* surgeTank.m STATE(1,surgeTank.mdot) */)) * ((data->localData[0]->realVars[21] /* der(der(surgeTank.v)) DUMMY_DER */)) + ((data->localData[0]->realVars[151] /* surgeTank.mdot DUMMY_STATE */)) * ((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)) + ((data->localData[0]->realVars[151] /* surgeTank.mdot DUMMY_STATE */)) * ((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)) + ((data->localData[0]->realVars[55] /* der(surgeTank.mdot) DUMMY_DER */)) * ((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 379
type: SIMPLE_ASSIGN
$DER.$DER.surgeTank.Vdot = $DER.$DER.surgeTank.v * surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_379(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,379};
  (data->localData[0]->realVars[19] /* der(der(surgeTank.Vdot)) DUMMY_DER */) = ((data->localData[0]->realVars[21] /* der(der(surgeTank.v)) DUMMY_DER */)) * ((data->localData[0]->realVars[138] /* surgeTank.A variable */));
  TRACE_POP
}
/*
equation index: 380
type: SIMPLE_ASSIGN
$DER.$DER.surgeTank.mdot = data.rho * $DER.$DER.surgeTank.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_380(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,380};
  (data->localData[0]->realVars[20] /* der(der(surgeTank.mdot)) DUMMY_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->localData[0]->realVars[19] /* der(der(surgeTank.Vdot)) DUMMY_DER */));
  TRACE_POP
}
/*
equation index: 381
type: SIMPLE_ASSIGN
$DER.surgeTank.F = $DER.$DER.surgeTank.M - $DER.surgeTank.Mdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_381(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,381};
  (data->localData[0]->realVars[47] /* der(surgeTank.F) DUMMY_DER */) = (data->localData[0]->realVars[18] /* der(der(surgeTank.M)) DUMMY_DER */) - (data->localData[0]->realVars[52] /* der(surgeTank.Mdot) DUMMY_DER */);
  TRACE_POP
}
/*
equation index: 382
type: SIMPLE_ASSIGN
$DER.surgeTank.F_p = $DER.surgeTank.F - ((-$DER.surgeTank.F_f) - $DER.surgeTank.F_g)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_382(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,382};
  (data->localData[0]->realVars[50] /* der(surgeTank.F_p) DUMMY_DER */) = (data->localData[0]->realVars[47] /* der(surgeTank.F) DUMMY_DER */) - ((-(data->localData[0]->realVars[48] /* der(surgeTank.F_f) DUMMY_DER */)) - (data->localData[0]->realVars[49] /* der(surgeTank.F_g) DUMMY_DER */));
  TRACE_POP
}
/*
equation index: 383
type: SIMPLE_ASSIGN
$DER.intake.p_o = $DER.surgeTank.F_p / surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_383(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,383};
  (data->localData[0]->realVars[40] /* der(intake.p_o) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[50] /* der(surgeTank.F_p) DUMMY_DER */),(data->localData[0]->realVars[138] /* surgeTank.A variable */),"surgeTank.A",equationIndexes);
  TRACE_POP
}
/*
equation index: 384
type: SIMPLE_ASSIGN
$DER.$DER.intake.M = 2.0 * data.rho * intake.Vdot * $DER.intake.Vdot * (1.0 / intake.A_i + (-1.0) / intake.A_o) + (-$DER.intake.F_f) - $DER.intake.p_o * intake.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_384(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,384};
  (data->localData[0]->realVars[13] /* der(der(intake.M)) DUMMY_DER */) = (2.0) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[110] /* intake.Vdot DUMMY_STATE */)) * (((data->localData[0]->realVars[38] /* der(intake.Vdot) DUMMY_DER */)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[106] /* intake.A_i variable */),"intake.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[107] /* intake.A_o variable */),"intake.A_o",equationIndexes))))) + (-(data->localData[0]->realVars[37] /* der(intake.F_f) DUMMY_DER */)) - (((data->localData[0]->realVars[40] /* der(intake.p_o) DUMMY_DER */)) * ((data->localData[0]->realVars[107] /* intake.A_o variable */)));
  TRACE_POP
}
/*
equation index: 385
type: SIMPLE_ASSIGN
$DER.$DER.intake.Vdot = $DER.$DER.intake.M / (data.rho * intake.L)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_385(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,385};
  (data->localData[0]->realVars[14] /* der(der(intake.Vdot)) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[13] /* der(der(intake.M)) DUMMY_DER */),((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->simulationInfo->realParameter[62] /* intake.L PARAM */)),"data.rho * intake.L",equationIndexes);
  TRACE_POP
}
/*
equation index: 386
type: SIMPLE_ASSIGN
$DER.$DER.intake.mdot = $DER.$DER.intake.Vdot * data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_386(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,386};
  (data->localData[0]->realVars[15] /* der(der(intake.mdot)) DUMMY_DER */) = ((data->localData[0]->realVars[14] /* der(der(intake.Vdot)) DUMMY_DER */)) * ((data->simulationInfo->realParameter[47] /* data.rho PARAM */));
  TRACE_POP
}
/*
equation index: 387
type: SIMPLE_ASSIGN
$DER.$DER.discharge.mdot = $DER.$DER.intake.mdot - $DER.$DER.surgeTank.mdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_387(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,387};
  (data->localData[0]->realVars[12] /* der(der(discharge.mdot)) DUMMY_DER */) = (data->localData[0]->realVars[15] /* der(der(intake.mdot)) DUMMY_DER */) - (data->localData[0]->realVars[20] /* der(der(surgeTank.mdot)) DUMMY_DER */);
  TRACE_POP
}
/*
equation index: 388
type: SIMPLE_ASSIGN
$DER.$DER.discharge.Vdot = $DER.$DER.discharge.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_388(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,388};
  (data->localData[0]->realVars[11] /* der(der(discharge.Vdot)) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[12] /* der(der(discharge.mdot)) DUMMY_DER */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes);
  TRACE_POP
}
/*
equation index: 389
type: SIMPLE_ASSIGN
$DER.$DER.discharge.M = data.rho * discharge.L * $DER.$DER.discharge.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_389(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,389};
  (data->localData[0]->realVars[10] /* der(der(discharge.M)) DUMMY_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[51] /* discharge.L PARAM */)) * ((data->localData[0]->realVars[11] /* der(der(discharge.Vdot)) DUMMY_DER */)));
  TRACE_POP
}
/*
equation index: 390
type: SIMPLE_ASSIGN
$DER.discharge.p_i = ($DER.$DER.discharge.M - (2.0 * data.rho * discharge.Vdot * $DER.discharge.Vdot * (1.0 / discharge.A_i + (-1.0) / discharge.A_o) - $DER.discharge.F_f)) / discharge.A_i
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_390(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,390};
  (data->localData[0]->realVars[32] /* der(discharge.p_i) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[10] /* der(der(discharge.M)) DUMMY_DER */) - ((2.0) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[94] /* discharge.Vdot DUMMY_STATE */)) * (((data->localData[0]->realVars[30] /* der(discharge.Vdot) DUMMY_DER */)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[89] /* discharge.A_i variable */),"discharge.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[90] /* discharge.A_o variable */),"discharge.A_o",equationIndexes))))) - (data->localData[0]->realVars[28] /* der(discharge.F_f) DUMMY_DER */)),(data->localData[0]->realVars[89] /* discharge.A_i variable */),"discharge.A_i",equationIndexes);
  TRACE_POP
}
/*
equation index: 391
type: SIMPLE_ASSIGN
$DER.$DER.penstock.Vdot = $DER.$DER.discharge.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_391(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,391};
  (data->localData[0]->realVars[17] /* der(der(penstock.Vdot)) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[12] /* der(der(discharge.mdot)) DUMMY_DER */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes);
  TRACE_POP
}
/*
equation index: 392
type: SIMPLE_ASSIGN
$DER.$DER.penstock.M = data.rho * penstock.L * $DER.$DER.penstock.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_392(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,392};
  (data->localData[0]->realVars[16] /* der(der(penstock.M)) DUMMY_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[69] /* penstock.L PARAM */)) * ((data->localData[0]->realVars[17] /* der(der(penstock.Vdot)) DUMMY_DER */)));
  TRACE_POP
}
/*
equation index: 393
type: SIMPLE_ASSIGN
$DER.penstock.p_o = (2.0 * data.rho * penstock.Vdot * $DER.penstock.Vdot * (1.0 / penstock.A_i + (-1.0) / penstock.A_o) + $DER.intake.p_o * penstock.A_i - $DER.penstock.F_f - $DER.$DER.penstock.M) / penstock.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_393(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,393};
  (data->localData[0]->realVars[44] /* der(penstock.p_o) DUMMY_DER */) = DIVISION_SIM((2.0) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[123] /* penstock.Vdot DUMMY_STATE */)) * (((data->localData[0]->realVars[43] /* der(penstock.Vdot) DUMMY_DER */)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[119] /* penstock.A_i variable */),"penstock.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[120] /* penstock.A_o variable */),"penstock.A_o",equationIndexes))))) + ((data->localData[0]->realVars[40] /* der(intake.p_o) DUMMY_DER */)) * ((data->localData[0]->realVars[119] /* penstock.A_i variable */)) - (data->localData[0]->realVars[42] /* der(penstock.F_f) DUMMY_DER */) - (data->localData[0]->realVars[16] /* der(der(penstock.M)) DUMMY_DER */),(data->localData[0]->realVars[120] /* penstock.A_o variable */),"penstock.A_o",equationIndexes);
  TRACE_POP
}
/*
equation index: 394
type: SIMPLE_ASSIGN
$DER.turbine1.Vdot = if turbine1.WaterCompress then data.rho * ($DER.discharge.mdot * (1.0 + data.beta * (penstock.p_o - data.p_a)) - discharge.mdot * data.beta * $DER.penstock.p_o) / (data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 2.0 else $DER.discharge.mdot * data.rho / data.rho ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_394(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,394};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_boolean tmp2;
  modelica_real tmp3;
  tmp2 = (modelica_boolean)(data->simulationInfo->booleanParameter[15] /* turbine1.WaterCompress PARAM */);
  if(tmp2)
  {
    tmp0 = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (1.0 + ((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->simulationInfo->realParameter[45] /* data.p_a PARAM */)));
    tmp3 = DIVISION_SIM(((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[31] /* der(discharge.mdot) DUMMY_DER */)) * (1.0 + ((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->simulationInfo->realParameter[45] /* data.p_a PARAM */))) - (((data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */)) * (((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[44] /* der(penstock.p_o) DUMMY_DER */))))),(tmp0 * tmp0),"(data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 2.0",equationIndexes);
  }
  else
  {
    tmp1 = (data->simulationInfo->realParameter[47] /* data.rho PARAM */);
    tmp3 = DIVISION_SIM(((data->localData[0]->realVars[31] /* der(discharge.mdot) DUMMY_DER */)) * ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)),(tmp1 * tmp1),"data.rho ^ 2.0",equationIndexes);
  }
  (data->localData[0]->realVars[58] /* der(turbine1.Vdot) DUMMY_DER */) = tmp3;
  TRACE_POP
}
/*
equation index: 395
type: SIMPLE_ASSIGN
$DER.turbine1.dp = 2.0 * (turbine1.Vdot ^ 2.0 * (-data.p_a) * turbine1.C_v_ ^ 2.0 * turbine1.look_up_table.u[1] * $DER.turbine1.look_up_table.u[1] / (turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 4.0 + turbine1.Vdot * $DER.turbine1.Vdot * data.p_a / (turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_395(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,395};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  tmp0 = (data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */);
  tmp1 = (data->localData[0]->realVars[162] /* turbine1.C_v_ variable */);
  tmp2 = ((data->localData[0]->realVars[162] /* turbine1.C_v_ variable */)) * ((data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */));
  tmp2 *= tmp2;tmp3 = ((data->localData[0]->realVars[162] /* turbine1.C_v_ variable */)) * ((data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */));
  (data->localData[0]->realVars[60] /* der(turbine1.dp) DUMMY_DER */) = (2.0) * (((tmp0 * tmp0)) * (((-(data->simulationInfo->realParameter[45] /* data.p_a PARAM */))) * (((tmp1 * tmp1)) * (((data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */)) * (DIVISION_SIM((data->localData[0]->realVars[63] /* der(turbine1.look_up_table.u[1]) DUMMY_DER */),(tmp2 * tmp2),"(turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 4.0",equationIndexes))))) + ((data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */)) * (((data->localData[0]->realVars[58] /* der(turbine1.Vdot) DUMMY_DER */)) * (DIVISION_SIM((data->simulationInfo->realParameter[45] /* data.p_a PARAM */),(tmp3 * tmp3),"(turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0",equationIndexes))));
  TRACE_POP
}

void residualFunc413(RESIDUAL_USERDATA* userData, const double* xloc, double* res, const int* iflag)
{
  TRACE_PUSH
  DATA *data = userData->data;
  threadData_t *threadData = userData->threadData;
  const int equationIndexes[2] = {1,413};
  ANALYTIC_JACOBIAN* jacobian = NULL;
  (data->localData[0]->realVars[21] /* der(der(surgeTank.v)) DUMMY_DER */) = xloc[0];
  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_378(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_379(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_380(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_381(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_382(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_383(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_384(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_385(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_386(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_387(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_388(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_389(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_390(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_391(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_392(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_393(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_394(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_395(data, threadData);
  res[0] = (data->localData[0]->realVars[44] /* der(penstock.p_o) DUMMY_DER */) + (-(data->localData[0]->realVars[32] /* der(discharge.p_i) DUMMY_DER */)) - (data->localData[0]->realVars[60] /* der(turbine1.dp) DUMMY_DER */);
  TRACE_POP
}
OMC_DISABLE_OPT
void initializeStaticLSData413(DATA* data, threadData_t* threadData, LINEAR_SYSTEM_DATA* linearSystemData, modelica_boolean initSparsePattern)
{
  int i=0;
  /* static ls data for der(der(surgeTank.v)) */
  linearSystemData->nominal[i] = data->modelData->realVarsData[21].attribute /* der(der(surgeTank.v)) */.nominal;
  linearSystemData->min[i]     = data->modelData->realVarsData[21].attribute /* der(der(surgeTank.v)) */.min;
  linearSystemData->max[i++]   = data->modelData->realVarsData[21].attribute /* der(der(surgeTank.v)) */.max;
}


/*
equation index: 149
type: SIMPLE_ASSIGN
$DER.$DER.surgeTank.M = surgeTank.m * $DER.$DER.surgeTank.v + surgeTank.mdot * $DER.surgeTank.v + surgeTank.mdot * $DER.surgeTank.v + $DER.surgeTank.mdot * surgeTank.v
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_149(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,149};
  (data->localData[0]->realVars[18] /* der(der(surgeTank.M)) DUMMY_DER */) = ((data->localData[0]->realVars[2] /* surgeTank.m STATE(1,surgeTank.mdot) */)) * ((data->localData[0]->realVars[21] /* der(der(surgeTank.v)) DUMMY_DER */)) + ((data->localData[0]->realVars[151] /* surgeTank.mdot DUMMY_STATE */)) * ((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)) + ((data->localData[0]->realVars[151] /* surgeTank.mdot DUMMY_STATE */)) * ((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)) + ((data->localData[0]->realVars[55] /* der(surgeTank.mdot) DUMMY_DER */)) * ((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 150
type: SIMPLE_ASSIGN
$DER.$DER.surgeTank.Vdot = $DER.$DER.surgeTank.v * surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_150(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,150};
  (data->localData[0]->realVars[19] /* der(der(surgeTank.Vdot)) DUMMY_DER */) = ((data->localData[0]->realVars[21] /* der(der(surgeTank.v)) DUMMY_DER */)) * ((data->localData[0]->realVars[138] /* surgeTank.A variable */));
  TRACE_POP
}
/*
equation index: 151
type: SIMPLE_ASSIGN
$DER.$DER.surgeTank.mdot = data.rho * $DER.$DER.surgeTank.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_151(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,151};
  (data->localData[0]->realVars[20] /* der(der(surgeTank.mdot)) DUMMY_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->localData[0]->realVars[19] /* der(der(surgeTank.Vdot)) DUMMY_DER */));
  TRACE_POP
}
/*
equation index: 152
type: SIMPLE_ASSIGN
$DER.surgeTank.F = $DER.$DER.surgeTank.M - $DER.surgeTank.Mdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_152(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,152};
  (data->localData[0]->realVars[47] /* der(surgeTank.F) DUMMY_DER */) = (data->localData[0]->realVars[18] /* der(der(surgeTank.M)) DUMMY_DER */) - (data->localData[0]->realVars[52] /* der(surgeTank.Mdot) DUMMY_DER */);
  TRACE_POP
}
/*
equation index: 153
type: SIMPLE_ASSIGN
$DER.surgeTank.F_p = $DER.surgeTank.F - ((-$DER.surgeTank.F_f) - $DER.surgeTank.F_g)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_153(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,153};
  (data->localData[0]->realVars[50] /* der(surgeTank.F_p) DUMMY_DER */) = (data->localData[0]->realVars[47] /* der(surgeTank.F) DUMMY_DER */) - ((-(data->localData[0]->realVars[48] /* der(surgeTank.F_f) DUMMY_DER */)) - (data->localData[0]->realVars[49] /* der(surgeTank.F_g) DUMMY_DER */));
  TRACE_POP
}
/*
equation index: 154
type: SIMPLE_ASSIGN
$DER.intake.p_o = $DER.surgeTank.F_p / surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_154(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,154};
  (data->localData[0]->realVars[40] /* der(intake.p_o) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[50] /* der(surgeTank.F_p) DUMMY_DER */),(data->localData[0]->realVars[138] /* surgeTank.A variable */),"surgeTank.A",equationIndexes);
  TRACE_POP
}
/*
equation index: 155
type: SIMPLE_ASSIGN
$DER.$DER.intake.M = 2.0 * data.rho * intake.Vdot * $DER.intake.Vdot * (1.0 / intake.A_i + (-1.0) / intake.A_o) + (-$DER.intake.F_f) - $DER.intake.p_o * intake.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_155(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,155};
  (data->localData[0]->realVars[13] /* der(der(intake.M)) DUMMY_DER */) = (2.0) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[110] /* intake.Vdot DUMMY_STATE */)) * (((data->localData[0]->realVars[38] /* der(intake.Vdot) DUMMY_DER */)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[106] /* intake.A_i variable */),"intake.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[107] /* intake.A_o variable */),"intake.A_o",equationIndexes))))) + (-(data->localData[0]->realVars[37] /* der(intake.F_f) DUMMY_DER */)) - (((data->localData[0]->realVars[40] /* der(intake.p_o) DUMMY_DER */)) * ((data->localData[0]->realVars[107] /* intake.A_o variable */)));
  TRACE_POP
}
/*
equation index: 156
type: SIMPLE_ASSIGN
$DER.$DER.intake.Vdot = $DER.$DER.intake.M / (data.rho * intake.L)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_156(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,156};
  (data->localData[0]->realVars[14] /* der(der(intake.Vdot)) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[13] /* der(der(intake.M)) DUMMY_DER */),((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->simulationInfo->realParameter[62] /* intake.L PARAM */)),"data.rho * intake.L",equationIndexes);
  TRACE_POP
}
/*
equation index: 157
type: SIMPLE_ASSIGN
$DER.$DER.intake.mdot = $DER.$DER.intake.Vdot * data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_157(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,157};
  (data->localData[0]->realVars[15] /* der(der(intake.mdot)) DUMMY_DER */) = ((data->localData[0]->realVars[14] /* der(der(intake.Vdot)) DUMMY_DER */)) * ((data->simulationInfo->realParameter[47] /* data.rho PARAM */));
  TRACE_POP
}
/*
equation index: 158
type: SIMPLE_ASSIGN
$DER.$DER.discharge.mdot = $DER.$DER.intake.mdot - $DER.$DER.surgeTank.mdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_158(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,158};
  (data->localData[0]->realVars[12] /* der(der(discharge.mdot)) DUMMY_DER */) = (data->localData[0]->realVars[15] /* der(der(intake.mdot)) DUMMY_DER */) - (data->localData[0]->realVars[20] /* der(der(surgeTank.mdot)) DUMMY_DER */);
  TRACE_POP
}
/*
equation index: 159
type: SIMPLE_ASSIGN
$DER.$DER.discharge.Vdot = $DER.$DER.discharge.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_159(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,159};
  (data->localData[0]->realVars[11] /* der(der(discharge.Vdot)) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[12] /* der(der(discharge.mdot)) DUMMY_DER */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes);
  TRACE_POP
}
/*
equation index: 160
type: SIMPLE_ASSIGN
$DER.$DER.discharge.M = data.rho * discharge.L * $DER.$DER.discharge.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_160(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,160};
  (data->localData[0]->realVars[10] /* der(der(discharge.M)) DUMMY_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[51] /* discharge.L PARAM */)) * ((data->localData[0]->realVars[11] /* der(der(discharge.Vdot)) DUMMY_DER */)));
  TRACE_POP
}
/*
equation index: 161
type: SIMPLE_ASSIGN
$DER.discharge.p_i = ($DER.$DER.discharge.M - (2.0 * data.rho * discharge.Vdot * $DER.discharge.Vdot * (1.0 / discharge.A_i + (-1.0) / discharge.A_o) - $DER.discharge.F_f)) / discharge.A_i
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_161(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,161};
  (data->localData[0]->realVars[32] /* der(discharge.p_i) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[10] /* der(der(discharge.M)) DUMMY_DER */) - ((2.0) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[94] /* discharge.Vdot DUMMY_STATE */)) * (((data->localData[0]->realVars[30] /* der(discharge.Vdot) DUMMY_DER */)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[89] /* discharge.A_i variable */),"discharge.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[90] /* discharge.A_o variable */),"discharge.A_o",equationIndexes))))) - (data->localData[0]->realVars[28] /* der(discharge.F_f) DUMMY_DER */)),(data->localData[0]->realVars[89] /* discharge.A_i variable */),"discharge.A_i",equationIndexes);
  TRACE_POP
}
/*
equation index: 162
type: SIMPLE_ASSIGN
$DER.$DER.penstock.Vdot = $DER.$DER.discharge.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_162(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,162};
  (data->localData[0]->realVars[17] /* der(der(penstock.Vdot)) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[12] /* der(der(discharge.mdot)) DUMMY_DER */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes);
  TRACE_POP
}
/*
equation index: 163
type: SIMPLE_ASSIGN
$DER.$DER.penstock.M = data.rho * penstock.L * $DER.$DER.penstock.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_163(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,163};
  (data->localData[0]->realVars[16] /* der(der(penstock.M)) DUMMY_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[69] /* penstock.L PARAM */)) * ((data->localData[0]->realVars[17] /* der(der(penstock.Vdot)) DUMMY_DER */)));
  TRACE_POP
}
/*
equation index: 164
type: SIMPLE_ASSIGN
$DER.penstock.p_o = (2.0 * data.rho * penstock.Vdot * $DER.penstock.Vdot * (1.0 / penstock.A_i + (-1.0) / penstock.A_o) + $DER.intake.p_o * penstock.A_i - $DER.penstock.F_f - $DER.$DER.penstock.M) / penstock.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_164(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,164};
  (data->localData[0]->realVars[44] /* der(penstock.p_o) DUMMY_DER */) = DIVISION_SIM((2.0) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[123] /* penstock.Vdot DUMMY_STATE */)) * (((data->localData[0]->realVars[43] /* der(penstock.Vdot) DUMMY_DER */)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[119] /* penstock.A_i variable */),"penstock.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[120] /* penstock.A_o variable */),"penstock.A_o",equationIndexes))))) + ((data->localData[0]->realVars[40] /* der(intake.p_o) DUMMY_DER */)) * ((data->localData[0]->realVars[119] /* penstock.A_i variable */)) - (data->localData[0]->realVars[42] /* der(penstock.F_f) DUMMY_DER */) - (data->localData[0]->realVars[16] /* der(der(penstock.M)) DUMMY_DER */),(data->localData[0]->realVars[120] /* penstock.A_o variable */),"penstock.A_o",equationIndexes);
  TRACE_POP
}
/*
equation index: 165
type: SIMPLE_ASSIGN
$DER.turbine1.Vdot = if turbine1.WaterCompress then data.rho * ($DER.discharge.mdot * (1.0 + data.beta * (penstock.p_o - data.p_a)) - discharge.mdot * data.beta * $DER.penstock.p_o) / (data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 2.0 else $DER.discharge.mdot * data.rho / data.rho ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_165(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,165};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_boolean tmp2;
  modelica_real tmp3;
  tmp2 = (modelica_boolean)(data->simulationInfo->booleanParameter[15] /* turbine1.WaterCompress PARAM */);
  if(tmp2)
  {
    tmp0 = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (1.0 + ((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->simulationInfo->realParameter[45] /* data.p_a PARAM */)));
    tmp3 = DIVISION_SIM(((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[31] /* der(discharge.mdot) DUMMY_DER */)) * (1.0 + ((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->simulationInfo->realParameter[45] /* data.p_a PARAM */))) - (((data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */)) * (((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[44] /* der(penstock.p_o) DUMMY_DER */))))),(tmp0 * tmp0),"(data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 2.0",equationIndexes);
  }
  else
  {
    tmp1 = (data->simulationInfo->realParameter[47] /* data.rho PARAM */);
    tmp3 = DIVISION_SIM(((data->localData[0]->realVars[31] /* der(discharge.mdot) DUMMY_DER */)) * ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)),(tmp1 * tmp1),"data.rho ^ 2.0",equationIndexes);
  }
  (data->localData[0]->realVars[58] /* der(turbine1.Vdot) DUMMY_DER */) = tmp3;
  TRACE_POP
}
/*
equation index: 166
type: SIMPLE_ASSIGN
$DER.turbine1.dp = 2.0 * (turbine1.Vdot ^ 2.0 * (-data.p_a) * turbine1.C_v_ ^ 2.0 * turbine1.look_up_table.u[1] * $DER.turbine1.look_up_table.u[1] / (turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 4.0 + turbine1.Vdot * $DER.turbine1.Vdot * data.p_a / (turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_166(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,166};
  modelica_real tmp0;
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  tmp0 = (data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */);
  tmp1 = (data->localData[0]->realVars[162] /* turbine1.C_v_ variable */);
  tmp2 = ((data->localData[0]->realVars[162] /* turbine1.C_v_ variable */)) * ((data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */));
  tmp2 *= tmp2;tmp3 = ((data->localData[0]->realVars[162] /* turbine1.C_v_ variable */)) * ((data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */));
  (data->localData[0]->realVars[60] /* der(turbine1.dp) DUMMY_DER */) = (2.0) * (((tmp0 * tmp0)) * (((-(data->simulationInfo->realParameter[45] /* data.p_a PARAM */))) * (((tmp1 * tmp1)) * (((data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */)) * (DIVISION_SIM((data->localData[0]->realVars[63] /* der(turbine1.look_up_table.u[1]) DUMMY_DER */),(tmp2 * tmp2),"(turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 4.0",equationIndexes))))) + ((data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */)) * (((data->localData[0]->realVars[58] /* der(turbine1.Vdot) DUMMY_DER */)) * (DIVISION_SIM((data->simulationInfo->realParameter[45] /* data.p_a PARAM */),(tmp3 * tmp3),"(turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0",equationIndexes))));
  TRACE_POP
}

void residualFunc184(RESIDUAL_USERDATA* userData, const double* xloc, double* res, const int* iflag)
{
  TRACE_PUSH
  DATA *data = userData->data;
  threadData_t *threadData = userData->threadData;
  const int equationIndexes[2] = {1,184};
  ANALYTIC_JACOBIAN* jacobian = NULL;
  (data->localData[0]->realVars[21] /* der(der(surgeTank.v)) DUMMY_DER */) = xloc[0];
  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_149(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_150(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_151(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_152(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_153(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_154(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_155(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_156(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_157(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_158(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_159(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_160(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_161(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_162(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_163(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_164(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_165(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_166(data, threadData);
  res[0] = (data->localData[0]->realVars[44] /* der(penstock.p_o) DUMMY_DER */) + (-(data->localData[0]->realVars[32] /* der(discharge.p_i) DUMMY_DER */)) - (data->localData[0]->realVars[60] /* der(turbine1.dp) DUMMY_DER */);
  TRACE_POP
}
OMC_DISABLE_OPT
void initializeStaticLSData184(DATA* data, threadData_t* threadData, LINEAR_SYSTEM_DATA* linearSystemData, modelica_boolean initSparsePattern)
{
  int i=0;
  /* static ls data for der(der(surgeTank.v)) */
  linearSystemData->nominal[i] = data->modelData->realVarsData[21].attribute /* der(der(surgeTank.v)) */.nominal;
  linearSystemData->min[i]     = data->modelData->realVarsData[21].attribute /* der(der(surgeTank.v)) */.min;
  linearSystemData->max[i++]   = data->modelData->realVarsData[21].attribute /* der(der(surgeTank.v)) */.max;
}

/* Prototypes for the strict sets (Dynamic Tearing) */

/* Global constraints for the casual sets */
/* function initialize linear systems */
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialLinearSystem(int nLinearSystems, LINEAR_SYSTEM_DATA* linearSystemData)
{
  /* linear systems */
  assertStreamPrint(NULL, nLinearSystems > 2, "Internal Error: indexlinearSystem mismatch!");
  linearSystemData[2].equationIndex = 621;
  linearSystemData[2].size = 1;
  linearSystemData[2].nnz = 0;
  linearSystemData[2].method = 1;   /* Symbolic Jacobian available */
  linearSystemData[2].residualFunc = residualFunc621;
  linearSystemData[2].strictTearingFunctionCall = NULL;
  linearSystemData[2].analyticalJacobianColumn = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacLSJac191_column;
  linearSystemData[2].initialAnalyticalJacobian = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianLSJac191;
  linearSystemData[2].jacobianIndex = 5 /*jacInx*/;
  linearSystemData[2].setA = NULL;  //setLinearMatrixA621;
  linearSystemData[2].setb = NULL;  //setLinearVectorb621;
  linearSystemData[2].initializeStaticLSData = initializeStaticLSData621;
  
  assertStreamPrint(NULL, nLinearSystems > 1, "Internal Error: indexlinearSystem mismatch!");
  linearSystemData[1].equationIndex = 413;
  linearSystemData[1].size = 1;
  linearSystemData[1].nnz = 0;
  linearSystemData[1].method = 1;   /* Symbolic Jacobian available */
  linearSystemData[1].residualFunc = residualFunc413;
  linearSystemData[1].strictTearingFunctionCall = NULL;
  linearSystemData[1].analyticalJacobianColumn = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacLSJac189_column;
  linearSystemData[1].initialAnalyticalJacobian = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianLSJac189;
  linearSystemData[1].jacobianIndex = 3 /*jacInx*/;
  linearSystemData[1].setA = NULL;  //setLinearMatrixA413;
  linearSystemData[1].setb = NULL;  //setLinearVectorb413;
  linearSystemData[1].initializeStaticLSData = initializeStaticLSData413;
  
  assertStreamPrint(NULL, nLinearSystems > 0, "Internal Error: indexlinearSystem mismatch!");
  linearSystemData[0].equationIndex = 184;
  linearSystemData[0].size = 1;
  linearSystemData[0].nnz = 0;
  linearSystemData[0].method = 1;   /* Symbolic Jacobian available */
  linearSystemData[0].residualFunc = residualFunc184;
  linearSystemData[0].strictTearingFunctionCall = NULL;
  linearSystemData[0].analyticalJacobianColumn = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacLSJac187_column;
  linearSystemData[0].initialAnalyticalJacobian = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianLSJac187;
  linearSystemData[0].jacobianIndex = 1 /*jacInx*/;
  linearSystemData[0].setA = NULL;  //setLinearMatrixA184;
  linearSystemData[0].setb = NULL;  //setLinearVectorb184;
  linearSystemData[0].initializeStaticLSData = initializeStaticLSData184;
}

#if defined(__cplusplus)
}
#endif

