#ifndef TestPackage_ActiveWork_WaterModel_HydroPowerModel1__H
#define TestPackage_ActiveWork_WaterModel_HydroPowerModel1__H
#include "meta/meta_modelica.h"
#include "util/modelica.h"
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#include "simulation/simulation_runtime.h"
#ifdef __cplusplus
extern "C" {
#endif


DLLExport
real_array omc__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf(threadData_t *threadData, real_array _A, real_array __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERA, integer_array *out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERpivots, modelica_integer *out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERinfo);
DLLExport
modelica_metatype boxptr__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf(threadData_t *threadData, modelica_metatype _A, modelica_metatype __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERA, modelica_metatype *out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERpivots, modelica_metatype *out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERinfo);
static const MMC_DEFSTRUCTLIT(boxvar_lit__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf,2,0) {(void*) boxptr__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf,0}};
#define boxvar__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf MMC_REFSTRUCTLIT(boxvar_lit__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf)


DLLExport
real_array omc__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri(threadData_t *threadData, real_array _LU, integer_array _pivots, real_array __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERLU, modelica_integer *out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinfo);
DLLExport
modelica_metatype boxptr__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri(threadData_t *threadData, modelica_metatype _LU, modelica_metatype _pivots, modelica_metatype __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERLU, modelica_metatype *out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinfo);
static const MMC_DEFSTRUCTLIT(boxvar_lit__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri,2,0) {(void*) boxptr__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri,0}};
#define boxvar__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri MMC_REFSTRUCTLIT(boxvar_lit__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri)


DLLExport
real_array omc__omcQ_24DER_24Modelica_24PMath_24PMatrices_24Pinv(threadData_t *threadData, real_array _A, real_array __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERA);
DLLExport
modelica_metatype boxptr__omcQ_24DER_24Modelica_24PMath_24PMatrices_24Pinv(threadData_t *threadData, modelica_metatype _A, modelica_metatype __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERA);
static const MMC_DEFSTRUCTLIT(boxvar_lit__omcQ_24DER_24Modelica_24PMath_24PMatrices_24Pinv,2,0) {(void*) boxptr__omcQ_24DER_24Modelica_24PMath_24PMatrices_24Pinv,0}};
#define boxvar__omcQ_24DER_24Modelica_24PMath_24PMatrices_24Pinv MMC_REFSTRUCTLIT(boxvar_lit__omcQ_24DER_24Modelica_24PMath_24PMatrices_24Pinv)


DLLExport
modelica_real omc__omcQ_24DER_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy(threadData_t *threadData, modelica_real _N_Re, modelica_real _D, modelica_real _p_eps, modelica_real __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe, modelica_real __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERD, modelica_real __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERp_5Feps);
DLLExport
modelica_metatype boxptr__omcQ_24DER_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy(threadData_t *threadData, modelica_metatype _N_Re, modelica_metatype _D, modelica_metatype _p_eps, modelica_metatype __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe, modelica_metatype __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERD, modelica_metatype __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERp_5Feps);
static const MMC_DEFSTRUCTLIT(boxvar_lit__omcQ_24DER_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy,2,0) {(void*) boxptr__omcQ_24DER_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy,0}};
#define boxvar__omcQ_24DER_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy MMC_REFSTRUCTLIT(boxvar_lit__omcQ_24DER_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy)


DLLExport
modelica_real omc_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmax(threadData_t *threadData, modelica_complex _tableID);
DLLExport
modelica_metatype boxptr_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmax(threadData_t *threadData, modelica_metatype _tableID);
static const MMC_DEFSTRUCTLIT(boxvar_lit_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmax,2,0) {(void*) boxptr_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmax,0}};
#define boxvar_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmax MMC_REFSTRUCTLIT(boxvar_lit_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmax)

extern double ModelicaStandardTables_CombiTable1D_maximumAbscissa(void * /*_tableID*/);

DLLExport
modelica_real omc_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmin(threadData_t *threadData, modelica_complex _tableID);
DLLExport
modelica_metatype boxptr_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmin(threadData_t *threadData, modelica_metatype _tableID);
static const MMC_DEFSTRUCTLIT(boxvar_lit_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmin,2,0) {(void*) boxptr_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmin,0}};
#define boxvar_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmin MMC_REFSTRUCTLIT(boxvar_lit_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmin)

extern double ModelicaStandardTables_CombiTable1D_minimumAbscissa(void * /*_tableID*/);

DLLExport
modelica_real omc_Modelica_Blocks_Tables_Internal_getTable1DValueNoDer2(threadData_t *threadData, modelica_complex _tableID, modelica_integer _icol, modelica_real _u);
DLLExport
modelica_metatype boxptr_Modelica_Blocks_Tables_Internal_getTable1DValueNoDer2(threadData_t *threadData, modelica_metatype _tableID, modelica_metatype _icol, modelica_metatype _u);
static const MMC_DEFSTRUCTLIT(boxvar_lit_Modelica_Blocks_Tables_Internal_getTable1DValueNoDer2,2,0) {(void*) boxptr_Modelica_Blocks_Tables_Internal_getTable1DValueNoDer2,0}};
#define boxvar_Modelica_Blocks_Tables_Internal_getTable1DValueNoDer2 MMC_REFSTRUCTLIT(boxvar_lit_Modelica_Blocks_Tables_Internal_getTable1DValueNoDer2)

extern double ModelicaStandardTables_CombiTable1D_getValue(void * /*_tableID*/, int /*_icol*/, double /*_u*/);

DLLExport
modelica_complex omc_Modelica_Blocks_Types_ExternalCombiTable1D_constructor(threadData_t *threadData, modelica_string _tableName, modelica_string _fileName, real_array _table, integer_array _columns, modelica_integer _smoothness, modelica_integer _extrapolation, modelica_boolean _verboseRead);
DLLExport
modelica_metatype boxptr_Modelica_Blocks_Types_ExternalCombiTable1D_constructor(threadData_t *threadData, modelica_metatype _tableName, modelica_metatype _fileName, modelica_metatype _table, modelica_metatype _columns, modelica_metatype _smoothness, modelica_metatype _extrapolation, modelica_metatype _verboseRead);
static const MMC_DEFSTRUCTLIT(boxvar_lit_Modelica_Blocks_Types_ExternalCombiTable1D_constructor,2,0) {(void*) boxptr_Modelica_Blocks_Types_ExternalCombiTable1D_constructor,0}};
#define boxvar_Modelica_Blocks_Types_ExternalCombiTable1D_constructor MMC_REFSTRUCTLIT(boxvar_lit_Modelica_Blocks_Types_ExternalCombiTable1D_constructor)

extern void * ModelicaStandardTables_CombiTable1D_init2(const char* /*_fileName*/, const char* /*_tableName*/, const double* /*_table*/, size_t, size_t, const int* /*_columns*/, size_t, int /*_smoothness*/, int /*_extrapolation*/, int /*_verboseRead*/);

DLLExport
void omc_Modelica_Blocks_Types_ExternalCombiTable1D_destructor(threadData_t *threadData, modelica_complex _externalCombiTable1D);
DLLExport
void boxptr_Modelica_Blocks_Types_ExternalCombiTable1D_destructor(threadData_t *threadData, modelica_metatype _externalCombiTable1D);
static const MMC_DEFSTRUCTLIT(boxvar_lit_Modelica_Blocks_Types_ExternalCombiTable1D_destructor,2,0) {(void*) boxptr_Modelica_Blocks_Types_ExternalCombiTable1D_destructor,0}};
#define boxvar_Modelica_Blocks_Types_ExternalCombiTable1D_destructor MMC_REFSTRUCTLIT(boxvar_lit_Modelica_Blocks_Types_ExternalCombiTable1D_destructor)

extern void ModelicaStandardTables_CombiTable1D_close(void * /*_externalCombiTable1D*/);

DLLExport
real_array omc_Modelica_Math_Matrices_inv(threadData_t *threadData, real_array _A);
DLLExport
modelica_metatype boxptr_Modelica_Math_Matrices_inv(threadData_t *threadData, modelica_metatype _A);
static const MMC_DEFSTRUCTLIT(boxvar_lit_Modelica_Math_Matrices_inv,2,0) {(void*) boxptr_Modelica_Math_Matrices_inv,0}};
#define boxvar_Modelica_Math_Matrices_inv MMC_REFSTRUCTLIT(boxvar_lit_Modelica_Math_Matrices_inv)


DLLExport
real_array omc_Modelica_Math_Matrices_LAPACK_dgetrf(threadData_t *threadData, real_array _A, integer_array *out_pivots, modelica_integer *out_info);
DLLExport
modelica_metatype boxptr_Modelica_Math_Matrices_LAPACK_dgetrf(threadData_t *threadData, modelica_metatype _A, modelica_metatype *out_pivots, modelica_metatype *out_info);
static const MMC_DEFSTRUCTLIT(boxvar_lit_Modelica_Math_Matrices_LAPACK_dgetrf,2,0) {(void*) boxptr_Modelica_Math_Matrices_LAPACK_dgetrf,0}};
#define boxvar_Modelica_Math_Matrices_LAPACK_dgetrf MMC_REFSTRUCTLIT(boxvar_lit_Modelica_Math_Matrices_LAPACK_dgetrf)

extern void dgetrf_(int* /*_m*/, int* /*_n*/, double* /*_LU*/, int* /*_lda*/, int* /*_pivots*/, int* /*_info*/);

DLLExport
real_array omc_Modelica_Math_Matrices_LAPACK_dgetri(threadData_t *threadData, real_array _LU, integer_array _pivots, modelica_integer *out_info);
DLLExport
modelica_metatype boxptr_Modelica_Math_Matrices_LAPACK_dgetri(threadData_t *threadData, modelica_metatype _LU, modelica_metatype _pivots, modelica_metatype *out_info);
static const MMC_DEFSTRUCTLIT(boxvar_lit_Modelica_Math_Matrices_LAPACK_dgetri,2,0) {(void*) boxptr_Modelica_Math_Matrices_LAPACK_dgetri,0}};
#define boxvar_Modelica_Math_Matrices_LAPACK_dgetri MMC_REFSTRUCTLIT(boxvar_lit_Modelica_Math_Matrices_LAPACK_dgetri)

extern void dgetri_(int* /*_n*/, double* /*_inv*/, int* /*_lda*/, int* /*_pivots*/, double* /*_work*/, int* /*_lwork*/, int* /*_info*/);

DLLExport
modelica_real omc_OpenHPL_Functions_DarcyFriction_Friction(threadData_t *threadData, modelica_real _v, modelica_real _D, modelica_real _L, modelica_real _rho, modelica_real _mu, modelica_real _p_eps);
DLLExport
modelica_metatype boxptr_OpenHPL_Functions_DarcyFriction_Friction(threadData_t *threadData, modelica_metatype _v, modelica_metatype _D, modelica_metatype _L, modelica_metatype _rho, modelica_metatype _mu, modelica_metatype _p_eps);
static const MMC_DEFSTRUCTLIT(boxvar_lit_OpenHPL_Functions_DarcyFriction_Friction,2,0) {(void*) boxptr_OpenHPL_Functions_DarcyFriction_Friction,0}};
#define boxvar_OpenHPL_Functions_DarcyFriction_Friction MMC_REFSTRUCTLIT(boxvar_lit_OpenHPL_Functions_DarcyFriction_Friction)


DLLExport
modelica_real omc_OpenHPL_Functions_DarcyFriction_fDarcy(threadData_t *threadData, modelica_real _N_Re, modelica_real _D, modelica_real _p_eps);
DLLExport
modelica_metatype boxptr_OpenHPL_Functions_DarcyFriction_fDarcy(threadData_t *threadData, modelica_metatype _N_Re, modelica_metatype _D, modelica_metatype _p_eps);
static const MMC_DEFSTRUCTLIT(boxvar_lit_OpenHPL_Functions_DarcyFriction_fDarcy,2,0) {(void*) boxptr_OpenHPL_Functions_DarcyFriction_fDarcy,0}};
#define boxvar_OpenHPL_Functions_DarcyFriction_fDarcy MMC_REFSTRUCTLIT(boxvar_lit_OpenHPL_Functions_DarcyFriction_fDarcy)
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_model.h"


#ifdef __cplusplus
}
#endif
#endif

