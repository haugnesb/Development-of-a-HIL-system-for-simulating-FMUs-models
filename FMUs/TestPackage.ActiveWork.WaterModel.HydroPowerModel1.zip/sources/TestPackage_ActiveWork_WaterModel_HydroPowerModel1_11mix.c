/* Mixed Systems */
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_model.h"
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_11mix.h"
/* initial mixed systems */
/* initial_lambda0 mixed systems */
/* parameter mixed systems */
/* model mixed systems */
/* jacobians mixed systems */


