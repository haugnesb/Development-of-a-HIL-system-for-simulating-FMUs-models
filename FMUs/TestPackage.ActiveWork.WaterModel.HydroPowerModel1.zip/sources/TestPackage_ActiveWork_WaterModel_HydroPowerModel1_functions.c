#include "omc_simulation_settings.h"
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functions.h"
#ifdef __cplusplus
extern "C" {
#endif

#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_includes.h"


DLLExport
real_array omc__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf(threadData_t *threadData, real_array _A, real_array __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERA, integer_array *out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERpivots, modelica_integer *out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERinfo)
{
  real_array __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERLU;
  modelica_integer tmp1;
  modelica_integer tmp2;
  integer_array __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERpivots;
  modelica_integer tmp3;
  modelica_integer tmp4;
  modelica_integer __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERinfo;
  modelica_integer _m;
  modelica_integer tmp5;
  modelica_integer _n;
  modelica_integer tmp6;
  modelica_integer _lda;
  modelica_integer tmp7;
  modelica_integer __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERm;
  modelica_integer tmp8;
  modelica_integer __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERn;
  modelica_integer tmp9;
  modelica_integer __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERlda;
  modelica_integer tmp10;
  modelica_integer tmp11;
  modelica_boolean tmp12;
  modelica_integer tmp13;
  real_array _LU;
  modelica_integer tmp14;
  modelica_integer tmp15;
  integer_array _pivots;
  modelica_integer tmp16;
  modelica_integer tmp17;
  modelica_integer _info;
  _tailrecursive: OMC_LABEL_UNUSED
  tmp1 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  tmp2 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  alloc_real_array(&(__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERLU), 2, (_index_t)tmp1, (_index_t)tmp2);
  real_array_copy_data(__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERA, __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERLU);
  
  tmp3 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  tmp4 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  alloc_integer_array(&(__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERpivots), 1, (_index_t)modelica_integer_min((modelica_integer)(tmp3),(modelica_integer)(tmp4))); // __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERpivots has no default value.
  // __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERinfo has no default value.
  tmp5 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  _m = tmp5;
  tmp6 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  _n = tmp6;
  tmp7 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  _lda = modelica_integer_max((modelica_integer)(((modelica_integer) 1)),(modelica_integer)(tmp7));
  tmp8 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERm = tmp8;
  tmp9 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERn = tmp9;
  tmp10 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  tmp12 = (modelica_boolean)(((modelica_integer) 1) > tmp10);
  if(tmp12)
  {
    tmp13 = ((modelica_integer) 0);
  }
  else
  {
    tmp11 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
    tmp13 = tmp11;
  }
  __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERlda = tmp13;
  tmp14 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  tmp15 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  alloc_real_array(&(_LU), 2, (_index_t)tmp14, (_index_t)tmp15);
  real_array_copy_data(_A, _LU);
  
  tmp16 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  tmp17 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  alloc_integer_array(&(_pivots), 1, (_index_t)modelica_integer_min((modelica_integer)(tmp16),(modelica_integer)(tmp17))); // _pivots has no default value.
  // _info has no default value.
  _return: OMC_LABEL_UNUSED
  if (out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERpivots) { if (out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERpivots->dim_size == NULL) {copy_integer_array(__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERpivots, out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERpivots);} else {integer_array_copy_data(__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERpivots, *out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERpivots);} }
  if (out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERinfo) { *out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERinfo = __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERinfo; }
  return __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERLU;
}
modelica_metatype boxptr__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf(threadData_t *threadData, modelica_metatype _A, modelica_metatype __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERA, modelica_metatype *out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERpivots, modelica_metatype *out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERinfo)
{
  integer_array __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERpivots;
  modelica_integer tmp1;
  modelica_integer tmp2;
  modelica_integer __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERinfo;
  real_array __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERLU;
  modelica_integer tmp3;
  modelica_integer tmp4;
  modelica_metatype out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERLU;
  __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERLU = omc__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf(threadData, *((base_array_t*)_A), *((base_array_t*)__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERA), &__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERpivots, &__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERinfo);
  out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERLU = mmc_mk_modelica_array(__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERLU);
  if (out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERpivots) { *out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERpivots = mmc_mk_modelica_array(__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERpivots); }
  if (out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERinfo) { *out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERinfo = mmc_mk_icon(__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERinfo); }
  return out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf_24funDERLU;
}

DLLExport
real_array omc__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri(threadData_t *threadData, real_array _LU, integer_array _pivots, real_array __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERLU, modelica_integer *out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinfo)
{
  real_array __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinv;
  modelica_integer tmp1;
  modelica_integer tmp2;
  modelica_integer __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinfo;
  modelica_integer _n;
  modelica_integer tmp3;
  modelica_integer _lda;
  modelica_integer tmp4;
  modelica_integer _lwork;
  modelica_integer tmp5;
  modelica_integer tmp6;
  real_array _work;
  modelica_integer tmp7;
  modelica_integer tmp8;
  modelica_integer __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERn;
  modelica_integer tmp9;
  modelica_integer __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERlda;
  modelica_integer tmp10;
  modelica_integer tmp11;
  modelica_boolean tmp12;
  modelica_integer tmp13;
  modelica_integer __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERlwork;
  modelica_integer tmp14;
  modelica_integer tmp15;
  modelica_integer tmp16;
  modelica_integer tmp17;
  modelica_integer tmp18;
  modelica_integer tmp19;
  modelica_boolean tmp20;
  modelica_integer tmp21;
  modelica_boolean tmp22;
  modelica_integer tmp23;
  real_array __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERwork;
  modelica_integer tmp24;
  modelica_integer tmp25;
  real_array _inv;
  modelica_integer tmp26;
  modelica_integer tmp27;
  modelica_integer _info;
  _tailrecursive: OMC_LABEL_UNUSED
  tmp1 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  tmp2 = size_of_dimension_base_array(_LU, ((modelica_integer) 2));
  alloc_real_array(&(__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinv), 2, (_index_t)tmp1, (_index_t)tmp2);
  real_array_copy_data(__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERLU, __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinv);
  
  // __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinfo has no default value.
  tmp3 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  _n = tmp3;
  tmp4 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  _lda = modelica_integer_max((modelica_integer)(((modelica_integer) 1)),(modelica_integer)(tmp4));
  tmp5 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  tmp6 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  _lwork = modelica_integer_max((modelica_integer)(((modelica_integer) 1)),(modelica_integer)((modelica_integer_min((modelica_integer)(((modelica_integer) 10)),(modelica_integer)(tmp5))) * (tmp6)));
  tmp7 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  tmp8 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  alloc_real_array(&(_work), 1, (_index_t)modelica_integer_max((modelica_integer)(((modelica_integer) 1)),(modelica_integer)((modelica_integer_min((modelica_integer)(((modelica_integer) 10)),(modelica_integer)(tmp7))) * (tmp8)))); // _work has no default value.
  tmp9 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERn = tmp9;
  tmp10 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  tmp12 = (modelica_boolean)(((modelica_integer) 1) > tmp10);
  if(tmp12)
  {
    tmp13 = ((modelica_integer) 0);
  }
  else
  {
    tmp11 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
    tmp13 = tmp11;
  }
  __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERlda = tmp13;
  tmp14 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  tmp15 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  tmp22 = (modelica_boolean)(((modelica_integer) 1) > (modelica_integer_min((modelica_integer)(((modelica_integer) 10)),(modelica_integer)(tmp14))) * (tmp15));
  if(tmp22)
  {
    tmp23 = ((modelica_integer) 0);
  }
  else
  {
    tmp16 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
    tmp17 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
    tmp18 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
    tmp20 = (modelica_boolean)(((modelica_integer) 10) < tmp18);
    if(tmp20)
    {
      tmp21 = ((modelica_integer) 0);
    }
    else
    {
      tmp19 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
      tmp21 = tmp19;
    }
    tmp23 = (tmp16) * (modelica_integer_min((modelica_integer)(((modelica_integer) 10)),(modelica_integer)(tmp17)) + tmp21);
  }
  __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERlwork = tmp23;
  tmp24 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  tmp25 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  alloc_real_array(&(__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERwork), 1, (_index_t)modelica_integer_max((modelica_integer)(((modelica_integer) 1)),(modelica_integer)((modelica_integer_min((modelica_integer)(((modelica_integer) 10)),(modelica_integer)(tmp24))) * (tmp25)))); // __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERwork has no default value.
  tmp26 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  tmp27 = size_of_dimension_base_array(_LU, ((modelica_integer) 2));
  alloc_real_array(&(_inv), 2, (_index_t)tmp26, (_index_t)tmp27);
  real_array_copy_data(_LU, _inv);
  
  // _info has no default value.
  _return: OMC_LABEL_UNUSED
  if (out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinfo) { *out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinfo = __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinfo; }
  return __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinv;
}
modelica_metatype boxptr__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri(threadData_t *threadData, modelica_metatype _LU, modelica_metatype _pivots, modelica_metatype __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERLU, modelica_metatype *out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinfo)
{
  modelica_integer __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinfo;
  real_array __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinv;
  modelica_integer tmp1;
  modelica_integer tmp2;
  modelica_metatype out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinv;
  __omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinv = omc__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri(threadData, *((base_array_t*)_LU), *((base_array_t*)_pivots), *((base_array_t*)__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERLU), &__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinfo);
  out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinv = mmc_mk_modelica_array(__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinv);
  if (out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinfo) { *out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinfo = mmc_mk_icon(__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinfo); }
  return out__omcQ_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri_24funDERinv;
}

DLLExport
real_array omc__omcQ_24DER_24Modelica_24PMath_24PMatrices_24Pinv(threadData_t *threadData, real_array _A, real_array __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERA)
{
  real_array __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERinvA;
  modelica_integer tmp1;
  modelica_integer tmp2;
  modelica_integer _info;
  integer_array _pivots;
  modelica_integer tmp3;
  real_array _LU;
  modelica_integer tmp4;
  modelica_integer tmp5;
  modelica_integer __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERinfo;
  integer_array __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERpivots;
  modelica_integer tmp6;
  real_array __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERLU;
  modelica_integer tmp7;
  modelica_integer tmp8;
  real_array _invA;
  modelica_integer tmp9;
  modelica_integer tmp10;
  _tailrecursive: OMC_LABEL_UNUSED
  tmp1 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  tmp2 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  alloc_real_array(&(__omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERinvA), 2, (_index_t)tmp1, (_index_t)tmp2); // __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERinvA has no default value.
  // _info has no default value.
  tmp3 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  alloc_integer_array(&(_pivots), 1, (_index_t)tmp3); // _pivots has no default value.
  tmp4 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  tmp5 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  alloc_real_array(&(_LU), 2, (_index_t)tmp4, (_index_t)tmp5); // _LU has no default value.
  // __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERinfo has no default value.
  tmp6 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  alloc_integer_array(&(__omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERpivots), 1, (_index_t)tmp6); // __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERpivots has no default value.
  tmp7 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  tmp8 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  alloc_real_array(&(__omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERLU), 2, (_index_t)tmp7, (_index_t)tmp8); // __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERLU has no default value.
  tmp9 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  tmp10 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  alloc_real_array(&(_invA), 2, (_index_t)tmp9, (_index_t)tmp10); // _invA has no default value.
  real_array_copy_data(omc_Modelica_Math_Matrices_LAPACK_dgetrf(threadData, _A ,&_pivots ,&_info), _LU);

  real_array_copy_data(omc__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetrf(threadData, _A, __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERA ,&__omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERpivots ,&__omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERinfo), __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERLU);

  real_array_copy_data(omc_Modelica_Math_Matrices_LAPACK_dgetri(threadData, _LU, _pivots, NULL), _invA);

  real_array_copy_data(omc__omcQ_24DER_24Modelica_24PMath_24PMatrices_24PLAPACK_24Pdgetri(threadData, _LU, _pivots, __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERLU, NULL), __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERinvA);
  _return: OMC_LABEL_UNUSED
  return __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERinvA;
}
modelica_metatype boxptr__omcQ_24DER_24Modelica_24PMath_24PMatrices_24Pinv(threadData_t *threadData, modelica_metatype _A, modelica_metatype __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERA)
{
  real_array __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERinvA;
  modelica_integer tmp1;
  modelica_integer tmp2;
  modelica_metatype out__omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERinvA;
  __omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERinvA = omc__omcQ_24DER_24Modelica_24PMath_24PMatrices_24Pinv(threadData, *((base_array_t*)_A), *((base_array_t*)__omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERA));
  out__omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERinvA = mmc_mk_modelica_array(__omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERinvA);
  return out__omcQ_24Modelica_24PMath_24PMatrices_24Pinv_24funDERinvA;
}

DLLExport
modelica_real omc__omcQ_24DER_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy(threadData_t *threadData, modelica_real _N_Re, modelica_real _D, modelica_real _p_eps, modelica_real __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe, modelica_real __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERD, modelica_real __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERp_5Feps)
{
  modelica_real __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERfD;
  modelica_real _arg;
  modelica_real _N_Re_lam;
  modelica_real _N_Re_tur;
  real_array _X;
  real_array _Y;
  real_array _K;
  modelica_real __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERarg;
  modelica_real __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe_5Flam;
  modelica_real __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe_5Ftur;
  real_array __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERX;
  real_array __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERY;
  real_array __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERK;
  modelica_real _fD;
  real_array tmp1;
  real_array tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  real_array tmp5;
  modelica_real tmp6;
  modelica_real tmp7;
  real_array tmp8;
  modelica_real tmp9;
  real_array tmp10;
  modelica_real tmp11;
  real_array tmp12;
  real_array tmp13;
  modelica_real tmp14;
  real_array tmp15;
  modelica_real tmp16;
  real_array tmp17;
  real_array tmp18;
  real_array tmp19;
  modelica_real tmp20;
  modelica_real tmp21;
  modelica_real tmp22;
  modelica_real tmp23;
  modelica_real tmp24;
  modelica_real tmp25;
  modelica_real tmp26;
  modelica_real tmp27;
  modelica_real tmp28;
  modelica_real tmp29;
  modelica_real tmp30;
  modelica_real tmp31;
  modelica_real tmp32;
  modelica_real tmp33;
  modelica_real tmp34;
  modelica_real tmp35;
  modelica_real tmp36;
  modelica_real tmp37;
  modelica_real tmp38;
  modelica_real tmp39;
  modelica_real tmp40;
  modelica_real tmp41;
  modelica_real tmp42;
  modelica_real tmp43;
  real_array tmp44;
  modelica_real tmp45;
  modelica_real tmp46;
  modelica_real tmp47;
  modelica_real tmp48;
  modelica_real tmp49;
  modelica_real tmp50;
  modelica_real tmp51;
  modelica_real tmp52;
  modelica_real tmp53;
  modelica_real tmp54;
  modelica_real tmp55;
  modelica_real tmp56;
  modelica_real tmp57;
  modelica_real tmp58;
  modelica_real tmp59;
  modelica_real tmp60;
  modelica_real tmp61;
  modelica_real tmp62;
  modelica_real tmp63;
  modelica_real tmp64;
  modelica_real tmp65;
  modelica_real tmp66;
  modelica_real tmp67;
  modelica_real tmp68;
  modelica_real tmp69;
  modelica_real tmp70;
  modelica_real tmp71;
  modelica_real tmp72;
  modelica_real tmp73;
  modelica_real tmp74;
  modelica_real tmp75;
  modelica_real tmp76;
  modelica_real tmp77;
  modelica_real tmp78;
  modelica_real tmp79;
  modelica_real tmp80;
  modelica_real tmp81;
  modelica_real tmp82;
  modelica_real tmp83;
  modelica_real tmp84;
  modelica_real tmp85;
  modelica_real tmp86;
  modelica_real tmp87;
  modelica_real tmp88;
  modelica_real tmp89;
  modelica_real tmp90;
  modelica_real tmp91;
  modelica_real tmp92;
  modelica_real tmp93;
  modelica_real tmp94;
  modelica_real tmp95;
  modelica_real tmp96;
  modelica_real tmp97;
  modelica_real tmp98;
  modelica_real tmp99;
  modelica_real tmp100;
  modelica_real tmp101;
  modelica_real tmp102;
  modelica_real tmp103;
  modelica_real tmp104;
  modelica_real tmp105;
  modelica_real tmp106;
  modelica_real tmp107;
  modelica_real tmp108;
  modelica_real tmp109;
  modelica_real tmp110;
  modelica_real tmp111;
  modelica_real tmp112;
  modelica_real tmp113;
  modelica_real tmp114;
  modelica_real tmp115;
  modelica_real tmp116;
  modelica_real tmp117;
  modelica_real tmp118;
  modelica_real tmp119;
  modelica_real tmp120;
  modelica_real tmp121;
  modelica_real tmp122;
  modelica_real tmp123;
  modelica_real tmp124;
  modelica_real tmp125;
  modelica_real tmp126;
  modelica_real tmp127;
  modelica_real tmp128;
  modelica_real tmp129;
  modelica_real tmp130;
  modelica_real tmp131;
  modelica_real tmp132;
  modelica_real tmp133;
  modelica_real tmp134;
  modelica_real tmp135;
  modelica_real tmp136;
  modelica_real tmp137;
  modelica_real tmp138;
  modelica_real tmp139;
  modelica_real tmp140;
  modelica_real tmp141;
  modelica_real tmp142;
  modelica_real tmp143;
  modelica_real tmp144;
  modelica_real tmp145;
  modelica_real tmp146;
  modelica_real tmp147;
  modelica_real tmp148;
  modelica_real tmp149;
  modelica_real tmp150;
  modelica_real tmp151;
  modelica_real tmp152;
  modelica_real tmp153;
  modelica_real tmp154;
  modelica_real tmp155;
  modelica_real tmp156;
  modelica_real tmp157;
  _tailrecursive: OMC_LABEL_UNUSED
  // __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERfD has no default value.
  // _arg has no default value.
  _N_Re_lam = 2100.0;
  _N_Re_tur = 2300.0;
  alloc_real_array(&(_X), 2, (_index_t)4, (_index_t)4); // _X has no default value.
  alloc_real_array(&(_Y), 1, (_index_t)4); // _Y has no default value.
  alloc_real_array(&(_K), 1, (_index_t)4); // _K has no default value.
  // __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERarg has no default value.
  __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe_5Flam = 0.0;
  __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe_5Ftur = 0.0;
  alloc_real_array(&(__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERX), 2, (_index_t)4, (_index_t)4); // __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERX has no default value.
  alloc_real_array(&(__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERY), 1, (_index_t)4); // __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERY has no default value.
  alloc_real_array(&(__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERK), 1, (_index_t)4); // __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERK has no default value.
  // _fD has no default value.
  tmp3 = _N_Re_lam;
  tmp4 = _N_Re_lam;
  array_alloc_scalar_real_array(&tmp2, 4, (modelica_real)(tmp3 * tmp3 * tmp3), (modelica_real)(tmp4 * tmp4), (modelica_real)_N_Re_lam, (modelica_real)1.0);
  tmp6 = _N_Re_tur;
  tmp7 = _N_Re_tur;
  array_alloc_scalar_real_array(&tmp5, 4, (modelica_real)(tmp6 * tmp6 * tmp6), (modelica_real)(tmp7 * tmp7), (modelica_real)_N_Re_tur, (modelica_real)1.0);
  tmp9 = _N_Re_lam;
  array_alloc_scalar_real_array(&tmp8, 4, (modelica_real)(3.0) * ((tmp9 * tmp9)), (modelica_real)(2.0) * (_N_Re_lam), (modelica_real)1.0, (modelica_real)0.0);
  tmp11 = _N_Re_tur;
  array_alloc_scalar_real_array(&tmp10, 4, (modelica_real)(3.0) * ((tmp11 * tmp11)), (modelica_real)(2.0) * (_N_Re_tur), (modelica_real)1.0, (modelica_real)0.0);
  array_alloc_real_array(&tmp1, 4, tmp2, tmp5, tmp8, tmp10);
  real_array_copy_data(tmp1, _X);

  tmp14 = _N_Re_lam;
  array_alloc_scalar_real_array(&tmp13, 4, (modelica_real)((3.0) * ((tmp14 * tmp14))) * (__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe_5Flam), (modelica_real)((2.0) * (_N_Re_lam)) * (__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe_5Flam), (modelica_real)__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe_5Flam, (modelica_real)0.0);
  tmp16 = _N_Re_tur;
  array_alloc_scalar_real_array(&tmp15, 4, (modelica_real)((3.0) * ((tmp16 * tmp16))) * (__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe_5Ftur), (modelica_real)((2.0) * (_N_Re_tur)) * (__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe_5Ftur), (modelica_real)__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe_5Ftur, (modelica_real)0.0);
  array_alloc_scalar_real_array(&tmp17, 4, (modelica_real)(3.0) * (((2.0) * (_N_Re_lam)) * (__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe_5Flam)), (modelica_real)(2.0) * (__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe_5Flam), (modelica_real)0.0, (modelica_real)0.0);
  array_alloc_scalar_real_array(&tmp18, 4, (modelica_real)(3.0) * (((2.0) * (_N_Re_tur)) * (__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe_5Ftur)), (modelica_real)(2.0) * (__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe_5Ftur), (modelica_real)0.0, (modelica_real)0.0);
  array_alloc_real_array(&tmp12, 4, tmp13, tmp15, tmp17, tmp18);
  real_array_copy_data(tmp12, __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERX);

  tmp20 = _N_Re_lam;
  if (tmp20 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "64.0 / N_Re_lam");}
  tmp21 = 3.7;
  if (tmp21 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "p_eps / 3.7");}
  tmp22 = _D;
  if (tmp22 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "p_eps / 3.7 / D");}
  tmp23 = _N_Re_tur;
  tmp24 = 0.9;
  if(tmp23 < 0.0 && tmp24 != 0.0)
  {
    tmp26 = modf(tmp24, &tmp27);
    
    if(tmp26 > 0.5)
    {
      tmp26 -= 1.0;
      tmp27 += 1.0;
    }
    else if(tmp26 < -0.5)
    {
      tmp26 += 1.0;
      tmp27 -= 1.0;
    }
    
    if(fabs(tmp26) < 1e-10)
      tmp25 = pow(tmp23, tmp27);
    else
    {
      tmp29 = modf(1.0/tmp24, &tmp28);
      if(tmp29 > 0.5)
      {
        tmp29 -= 1.0;
        tmp28 += 1.0;
      }
      else if(tmp29 < -0.5)
      {
        tmp29 += 1.0;
        tmp28 -= 1.0;
      }
      if(fabs(tmp29) < 1e-10 && ((unsigned long)tmp28 & 1))
      {
        tmp25 = -pow(-tmp23, tmp26)*pow(tmp23, tmp27);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp23, tmp24);
      }
    }
  }
  else
  {
    tmp25 = pow(tmp23, tmp24);
  }
  if(isnan(tmp25) || isinf(tmp25))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp23, tmp24);
  }tmp30 = tmp25;
  if (tmp30 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "5.74 / N_Re_tur ^ 0.9");}
  tmp31 = ((_p_eps) / tmp21) / tmp22 + (5.74) / tmp30;
  if(!(tmp31 > 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert(threadData, info, "Model error: Argument of log10(p_eps / 3.7 / D + 5.74 / N_Re_tur ^ 0.9) was %g should be > 0", tmp31);
  }tmp32 = (2.0) * (log10(tmp31));
  tmp33 = (tmp32 * tmp32);
  if (tmp33 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "1.0 / (2.0 * log10(p_eps / 3.7 / D + 5.74 / N_Re_tur ^ 0.9)) ^ 2.0");}
  tmp34 = _N_Re_lam;
  tmp35 = (tmp34 * tmp34);
  if (tmp35 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "64.0 / N_Re_lam ^ 2.0");}
  tmp36 = _N_Re_tur;
  tmp37 = 1.25;
  if(tmp36 < 0.0 && tmp37 != 0.0)
  {
    tmp39 = modf(tmp37, &tmp40);
    
    if(tmp39 > 0.5)
    {
      tmp39 -= 1.0;
      tmp40 += 1.0;
    }
    else if(tmp39 < -0.5)
    {
      tmp39 += 1.0;
      tmp40 -= 1.0;
    }
    
    if(fabs(tmp39) < 1e-10)
      tmp38 = pow(tmp36, tmp40);
    else
    {
      tmp42 = modf(1.0/tmp37, &tmp41);
      if(tmp42 > 0.5)
      {
        tmp42 -= 1.0;
        tmp41 += 1.0;
      }
      else if(tmp42 < -0.5)
      {
        tmp42 += 1.0;
        tmp41 -= 1.0;
      }
      if(fabs(tmp42) < 1e-10 && ((unsigned long)tmp41 & 1))
      {
        tmp38 = -pow(-tmp36, tmp39)*pow(tmp36, tmp40);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp36, tmp37);
      }
    }
  }
  else
  {
    tmp38 = pow(tmp36, tmp37);
  }
  if(isnan(tmp38) || isinf(tmp38))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp36, tmp37);
  }tmp43 = tmp38;
  if (tmp43 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "0.079 / N_Re_tur ^ 1.25");}
  array_alloc_scalar_real_array(&tmp19, 4, (modelica_real)(64.0) / tmp20, (modelica_real)(1.0) / tmp33, (modelica_real)(-((64.0) / tmp35)), (modelica_real)(-((0.079) / tmp43)));
  real_array_copy_data(tmp19, _Y);

  tmp45 = _N_Re_lam;
  tmp46 = (tmp45 * tmp45);
  if (tmp46 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "(-64.0) * $OpenHPL$PFunctions$PDarcyFriction$PfDarcy$funDERN_Re_lam / N_Re_lam ^ 2.0");}
  tmp47 = (3.7) * (_D);
  if (tmp47 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "p_eps / (3.7 * D)");}
  tmp48 = _N_Re_tur;
  tmp49 = 0.9;
  if(tmp48 < 0.0 && tmp49 != 0.0)
  {
    tmp51 = modf(tmp49, &tmp52);
    
    if(tmp51 > 0.5)
    {
      tmp51 -= 1.0;
      tmp52 += 1.0;
    }
    else if(tmp51 < -0.5)
    {
      tmp51 += 1.0;
      tmp52 -= 1.0;
    }
    
    if(fabs(tmp51) < 1e-10)
      tmp50 = pow(tmp48, tmp52);
    else
    {
      tmp54 = modf(1.0/tmp49, &tmp53);
      if(tmp54 > 0.5)
      {
        tmp54 -= 1.0;
        tmp53 += 1.0;
      }
      else if(tmp54 < -0.5)
      {
        tmp54 += 1.0;
        tmp53 -= 1.0;
      }
      if(fabs(tmp54) < 1e-10 && ((unsigned long)tmp53 & 1))
      {
        tmp50 = -pow(-tmp48, tmp51)*pow(tmp48, tmp52);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp48, tmp49);
      }
    }
  }
  else
  {
    tmp50 = pow(tmp48, tmp49);
  }
  if(isnan(tmp50) || isinf(tmp50))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp48, tmp49);
  }tmp55 = tmp50;
  if (tmp55 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "5.74 / N_Re_tur ^ 0.9");}
  tmp56 = (_p_eps) / tmp47 + (5.74) / tmp55;
  if(!(tmp56 > 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert(threadData, info, "Model error: Argument of log10(p_eps / (3.7 * D) + 5.74 / N_Re_tur ^ 0.9) was %g should be > 0", tmp56);
  }tmp57 = 3.7;
  if (tmp57 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "p_eps / 3.7");}
  tmp58 = _D;
  tmp59 = (tmp58 * tmp58);
  if (tmp59 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "(0.2702702702702703 * $OpenHPL$PFunctions$PDarcyFriction$PfDarcy$funDERp_eps * D - p_eps / 3.7 * $OpenHPL$PFunctions$PDarcyFriction$PfDarcy$funDERD) / D ^ 2.0");}
  tmp60 = _N_Re_tur;
  tmp61 = 0.09999999999999998;
  if(tmp60 < 0.0 && tmp61 != 0.0)
  {
    tmp63 = modf(tmp61, &tmp64);
    
    if(tmp63 > 0.5)
    {
      tmp63 -= 1.0;
      tmp64 += 1.0;
    }
    else if(tmp63 < -0.5)
    {
      tmp63 += 1.0;
      tmp64 -= 1.0;
    }
    
    if(fabs(tmp63) < 1e-10)
      tmp62 = pow(tmp60, tmp64);
    else
    {
      tmp66 = modf(1.0/tmp61, &tmp65);
      if(tmp66 > 0.5)
      {
        tmp66 -= 1.0;
        tmp65 += 1.0;
      }
      else if(tmp66 < -0.5)
      {
        tmp66 += 1.0;
        tmp65 -= 1.0;
      }
      if(fabs(tmp66) < 1e-10 && ((unsigned long)tmp65 & 1))
      {
        tmp62 = -pow(-tmp60, tmp63)*pow(tmp60, tmp64);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp60, tmp61);
      }
    }
  }
  else
  {
    tmp62 = pow(tmp60, tmp61);
  }
  if(isnan(tmp62) || isinf(tmp62))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp60, tmp61);
  }tmp67 = tmp62;
  if (tmp67 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "0.9 / N_Re_tur ^ 0.09999999999999998");}
  tmp68 = fabs(_N_Re_tur);
  tmp69 = 1.8;
  if(tmp68 < 0.0 && tmp69 != 0.0)
  {
    tmp71 = modf(tmp69, &tmp72);
    
    if(tmp71 > 0.5)
    {
      tmp71 -= 1.0;
      tmp72 += 1.0;
    }
    else if(tmp71 < -0.5)
    {
      tmp71 += 1.0;
      tmp72 -= 1.0;
    }
    
    if(fabs(tmp71) < 1e-10)
      tmp70 = pow(tmp68, tmp72);
    else
    {
      tmp74 = modf(1.0/tmp69, &tmp73);
      if(tmp74 > 0.5)
      {
        tmp74 -= 1.0;
        tmp73 += 1.0;
      }
      else if(tmp74 < -0.5)
      {
        tmp74 += 1.0;
        tmp73 -= 1.0;
      }
      if(fabs(tmp74) < 1e-10 && ((unsigned long)tmp73 & 1))
      {
        tmp70 = -pow(-tmp68, tmp71)*pow(tmp68, tmp72);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp68, tmp69);
      }
    }
  }
  else
  {
    tmp70 = pow(tmp68, tmp69);
  }
  if(isnan(tmp70) || isinf(tmp70))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp68, tmp69);
  }tmp75 = tmp70;
  if (tmp75 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "5.74 * 0.9 / N_Re_tur ^ 0.09999999999999998 * $OpenHPL$PFunctions$PDarcyFriction$PfDarcy$funDERN_Re_tur / abs(N_Re_tur) ^ 1.8");}
  tmp76 = (3.7) * (_D);
  if (tmp76 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "p_eps / (3.7 * D)");}
  tmp77 = _N_Re_tur;
  tmp78 = 0.9;
  if(tmp77 < 0.0 && tmp78 != 0.0)
  {
    tmp80 = modf(tmp78, &tmp81);
    
    if(tmp80 > 0.5)
    {
      tmp80 -= 1.0;
      tmp81 += 1.0;
    }
    else if(tmp80 < -0.5)
    {
      tmp80 += 1.0;
      tmp81 -= 1.0;
    }
    
    if(fabs(tmp80) < 1e-10)
      tmp79 = pow(tmp77, tmp81);
    else
    {
      tmp83 = modf(1.0/tmp78, &tmp82);
      if(tmp83 > 0.5)
      {
        tmp83 -= 1.0;
        tmp82 += 1.0;
      }
      else if(tmp83 < -0.5)
      {
        tmp83 += 1.0;
        tmp82 -= 1.0;
      }
      if(fabs(tmp83) < 1e-10 && ((unsigned long)tmp82 & 1))
      {
        tmp79 = -pow(-tmp77, tmp80)*pow(tmp77, tmp81);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp77, tmp78);
      }
    }
  }
  else
  {
    tmp79 = pow(tmp77, tmp78);
  }
  if(isnan(tmp79) || isinf(tmp79))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp77, tmp78);
  }tmp84 = tmp79;
  if (tmp84 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "5.74 / N_Re_tur ^ 0.9");}
  tmp85 = ((_p_eps) / tmp76 + (5.74) / tmp84) * (2.302585092994046);
  if (tmp85 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "((0.2702702702702703 * $OpenHPL$PFunctions$PDarcyFriction$PfDarcy$funDERp_eps * D - p_eps / 3.7 * $OpenHPL$PFunctions$PDarcyFriction$PfDarcy$funDERD) / D ^ 2.0 - 5.74 * 0.9 / N_Re_tur ^ 0.09999999999999998 * $OpenHPL$PFunctions$PDarcyFriction$PfDarcy$funDERN_Re_tur / abs(N_Re_tur) ^ 1.8) / ((p_eps / (3.7 * D) + 5.74 / N_Re_tur ^ 0.9) * 2.302585092994046)");}
  tmp86 = (3.7) * (_D);
  if (tmp86 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "p_eps / (3.7 * D)");}
  tmp87 = _N_Re_tur;
  tmp88 = 0.9;
  if(tmp87 < 0.0 && tmp88 != 0.0)
  {
    tmp90 = modf(tmp88, &tmp91);
    
    if(tmp90 > 0.5)
    {
      tmp90 -= 1.0;
      tmp91 += 1.0;
    }
    else if(tmp90 < -0.5)
    {
      tmp90 += 1.0;
      tmp91 -= 1.0;
    }
    
    if(fabs(tmp90) < 1e-10)
      tmp89 = pow(tmp87, tmp91);
    else
    {
      tmp93 = modf(1.0/tmp88, &tmp92);
      if(tmp93 > 0.5)
      {
        tmp93 -= 1.0;
        tmp92 += 1.0;
      }
      else if(tmp93 < -0.5)
      {
        tmp93 += 1.0;
        tmp92 -= 1.0;
      }
      if(fabs(tmp93) < 1e-10 && ((unsigned long)tmp92 & 1))
      {
        tmp89 = -pow(-tmp87, tmp90)*pow(tmp87, tmp91);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp87, tmp88);
      }
    }
  }
  else
  {
    tmp89 = pow(tmp87, tmp88);
  }
  if(isnan(tmp89) || isinf(tmp89))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp87, tmp88);
  }tmp94 = tmp89;
  if (tmp94 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "5.74 / N_Re_tur ^ 0.9");}
  tmp95 = (_p_eps) / tmp86 + (5.74) / tmp94;
  if(!(tmp95 > 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert(threadData, info, "Model error: Argument of log10(p_eps / (3.7 * D) + 5.74 / N_Re_tur ^ 0.9) was %g should be > 0", tmp95);
  }tmp96 = (2.0) * (log10(tmp95));
  tmp96 *= tmp96;tmp97 = (tmp96 * tmp96);
  if (tmp97 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "(-4.0) * log10(p_eps / (3.7 * D) + 5.74 / N_Re_tur ^ 0.9) * 2.0 * ((0.2702702702702703 * $OpenHPL$PFunctions$PDarcyFriction$PfDarcy$funDERp_eps * D - p_eps / 3.7 * $OpenHPL$PFunctions$PDarcyFriction$PfDarcy$funDERD) / D ^ 2.0 - 5.74 * 0.9 / N_Re_tur ^ 0.09999999999999998 * $OpenHPL$PFunctions$PDarcyFriction$PfDarcy$funDERN_Re_tur / abs(N_Re_tur) ^ 1.8) / ((p_eps / (3.7 * D) + 5.74 / N_Re_tur ^ 0.9) * 2.302585092994046) / (2.0 * log10(p_eps / (3.7 * D) + 5.74 / N_Re_tur ^ 0.9)) ^ 4.0");}
  tmp98 = _N_Re_lam;
  tmp98 *= tmp98;tmp99 = (tmp98 * tmp98);
  if (tmp99 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "64.0 * 2.0 * N_Re_lam * $OpenHPL$PFunctions$PDarcyFriction$PfDarcy$funDERN_Re_lam / N_Re_lam ^ 4.0");}
  tmp100 = _N_Re_tur;
  tmp101 = 0.25;
  if(tmp100 < 0.0 && tmp101 != 0.0)
  {
    tmp103 = modf(tmp101, &tmp104);
    
    if(tmp103 > 0.5)
    {
      tmp103 -= 1.0;
      tmp104 += 1.0;
    }
    else if(tmp103 < -0.5)
    {
      tmp103 += 1.0;
      tmp104 -= 1.0;
    }
    
    if(fabs(tmp103) < 1e-10)
      tmp102 = pow(tmp100, tmp104);
    else
    {
      tmp106 = modf(1.0/tmp101, &tmp105);
      if(tmp106 > 0.5)
      {
        tmp106 -= 1.0;
        tmp105 += 1.0;
      }
      else if(tmp106 < -0.5)
      {
        tmp106 += 1.0;
        tmp105 -= 1.0;
      }
      if(fabs(tmp106) < 1e-10 && ((unsigned long)tmp105 & 1))
      {
        tmp102 = -pow(-tmp100, tmp103)*pow(tmp100, tmp104);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp100, tmp101);
      }
    }
  }
  else
  {
    tmp102 = pow(tmp100, tmp101);
  }
  if(isnan(tmp102) || isinf(tmp102))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp100, tmp101);
  }tmp107 = fabs(_N_Re_tur);
  tmp108 = 2.5;
  if(tmp107 < 0.0 && tmp108 != 0.0)
  {
    tmp110 = modf(tmp108, &tmp111);
    
    if(tmp110 > 0.5)
    {
      tmp110 -= 1.0;
      tmp111 += 1.0;
    }
    else if(tmp110 < -0.5)
    {
      tmp110 += 1.0;
      tmp111 -= 1.0;
    }
    
    if(fabs(tmp110) < 1e-10)
      tmp109 = pow(tmp107, tmp111);
    else
    {
      tmp113 = modf(1.0/tmp108, &tmp112);
      if(tmp113 > 0.5)
      {
        tmp113 -= 1.0;
        tmp112 += 1.0;
      }
      else if(tmp113 < -0.5)
      {
        tmp113 += 1.0;
        tmp112 -= 1.0;
      }
      if(fabs(tmp113) < 1e-10 && ((unsigned long)tmp112 & 1))
      {
        tmp109 = -pow(-tmp107, tmp110)*pow(tmp107, tmp111);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp107, tmp108);
      }
    }
  }
  else
  {
    tmp109 = pow(tmp107, tmp108);
  }
  if(isnan(tmp109) || isinf(tmp109))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp107, tmp108);
  }tmp114 = tmp109;
  if (tmp114 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "0.079 * 1.25 * N_Re_tur ^ 0.25 * $OpenHPL$PFunctions$PDarcyFriction$PfDarcy$funDERN_Re_tur / abs(N_Re_tur) ^ 2.5");}
  array_alloc_scalar_real_array(&tmp44, 4, (modelica_real)((-64.0) * (__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe_5Flam)) / tmp46, (modelica_real)(((-4.0) * (log10(tmp56))) * ((2.0) * (((((0.2702702702702703) * (__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERp_5Feps)) * (_D) - (((_p_eps) / tmp57) * (__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERD))) / tmp59 - (((5.74) * (((0.9) / tmp67) * (__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe_5Ftur))) / tmp75)) / tmp85))) / tmp97, (modelica_real)((64.0) * (((2.0) * (_N_Re_lam)) * (__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe_5Flam))) / tmp99, (modelica_real)((0.079) * (((1.25) * (tmp102)) * (__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe_5Ftur))) / tmp114);
  real_array_copy_data(tmp44, __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERY);

  real_array_copy_data(mul_alloc_real_matrix_product_smart(omc_Modelica_Math_Matrices_inv(threadData, _X), _Y), _K);

  real_array_copy_data(add_alloc_real_array(mul_alloc_real_matrix_product_smart(omc_Modelica_Math_Matrices_inv(threadData, _X), __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERY), mul_alloc_real_matrix_product_smart(mul_alloc_real_array(__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERX, omc__omcQ_24DER_24Modelica_24PMath_24PMatrices_24Pinv(threadData, _X, _OMC_LIT4)), _Y)), __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERK);

  tmp115 = 3.7;
  if (tmp115 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "p_eps / 3.7");}
  tmp116 = _D;
  if (tmp116 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "p_eps / 3.7 / D");}
  tmp117 = _N_Re + 1e-15;
  tmp118 = 0.9;
  if(tmp117 < 0.0 && tmp118 != 0.0)
  {
    tmp120 = modf(tmp118, &tmp121);
    
    if(tmp120 > 0.5)
    {
      tmp120 -= 1.0;
      tmp121 += 1.0;
    }
    else if(tmp120 < -0.5)
    {
      tmp120 += 1.0;
      tmp121 -= 1.0;
    }
    
    if(fabs(tmp120) < 1e-10)
      tmp119 = pow(tmp117, tmp121);
    else
    {
      tmp123 = modf(1.0/tmp118, &tmp122);
      if(tmp123 > 0.5)
      {
        tmp123 -= 1.0;
        tmp122 += 1.0;
      }
      else if(tmp123 < -0.5)
      {
        tmp123 += 1.0;
        tmp122 -= 1.0;
      }
      if(fabs(tmp123) < 1e-10 && ((unsigned long)tmp122 & 1))
      {
        tmp119 = -pow(-tmp117, tmp120)*pow(tmp117, tmp121);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp117, tmp118);
      }
    }
  }
  else
  {
    tmp119 = pow(tmp117, tmp118);
  }
  if(isnan(tmp119) || isinf(tmp119))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp117, tmp118);
  }tmp124 = tmp119;
  if (tmp124 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "5.74 / (N_Re + 1e-15) ^ 0.9");}
  _arg = ((_p_eps) / tmp115) / tmp116 + (5.74) / tmp124;

  tmp125 = _D;
  tmp126 = (tmp125 * tmp125);
  if (tmp126 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "(0.2702702702702703 * $OpenHPL$PFunctions$PDarcyFriction$PfDarcy$funDERp_eps * D + 0.2702702702702702 * (-p_eps) * $OpenHPL$PFunctions$PDarcyFriction$PfDarcy$funDERD) / D ^ 2.0");}
  tmp127 = 1e-15 + _N_Re;
  tmp128 = -0.09999999999999998;
  if(tmp127 < 0.0 && tmp128 != 0.0)
  {
    tmp130 = modf(tmp128, &tmp131);
    
    if(tmp130 > 0.5)
    {
      tmp130 -= 1.0;
      tmp131 += 1.0;
    }
    else if(tmp130 < -0.5)
    {
      tmp130 += 1.0;
      tmp131 -= 1.0;
    }
    
    if(fabs(tmp130) < 1e-10)
      tmp129 = pow(tmp127, tmp131);
    else
    {
      tmp133 = modf(1.0/tmp128, &tmp132);
      if(tmp133 > 0.5)
      {
        tmp133 -= 1.0;
        tmp132 += 1.0;
      }
      else if(tmp133 < -0.5)
      {
        tmp133 += 1.0;
        tmp132 -= 1.0;
      }
      if(fabs(tmp133) < 1e-10 && ((unsigned long)tmp132 & 1))
      {
        tmp129 = -pow(-tmp127, tmp130)*pow(tmp127, tmp131);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp127, tmp128);
      }
    }
  }
  else
  {
    tmp129 = pow(tmp127, tmp128);
  }
  if(isnan(tmp129) || isinf(tmp129))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp127, tmp128);
  }tmp134 = fabs(_N_Re + 1e-15);
  tmp135 = 1.8;
  if(tmp134 < 0.0 && tmp135 != 0.0)
  {
    tmp137 = modf(tmp135, &tmp138);
    
    if(tmp137 > 0.5)
    {
      tmp137 -= 1.0;
      tmp138 += 1.0;
    }
    else if(tmp137 < -0.5)
    {
      tmp137 += 1.0;
      tmp138 -= 1.0;
    }
    
    if(fabs(tmp137) < 1e-10)
      tmp136 = pow(tmp134, tmp138);
    else
    {
      tmp140 = modf(1.0/tmp135, &tmp139);
      if(tmp140 > 0.5)
      {
        tmp140 -= 1.0;
        tmp139 += 1.0;
      }
      else if(tmp140 < -0.5)
      {
        tmp140 += 1.0;
        tmp139 -= 1.0;
      }
      if(fabs(tmp140) < 1e-10 && ((unsigned long)tmp139 & 1))
      {
        tmp136 = -pow(-tmp134, tmp137)*pow(tmp134, tmp138);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp134, tmp135);
      }
    }
  }
  else
  {
    tmp136 = pow(tmp134, tmp135);
  }
  if(isnan(tmp136) || isinf(tmp136))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp134, tmp135);
  }tmp141 = tmp136;
  if (tmp141 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "$OpenHPL$PFunctions$PDarcyFriction$PfDarcy$funDERN_Re / abs(N_Re + 1e-15) ^ 1.8");}
  __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERarg = ((0.2702702702702703) * ((__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERp_5Feps) * (_D)) + (0.2702702702702702) * (((-_p_eps)) * (__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERD))) / tmp126 + (-5.166) * ((tmp129) * ((__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe) / tmp141));

  if((_N_Re <= 0.0))
  {
    _fD = 0.0;

    __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERfD = 0.0;
  }
  else
  {
    if((_N_Re <= 2100.0))
    {
      tmp142 = _N_Re;
      if (tmp142 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "64.0 / N_Re");}
      _fD = (64.0) / tmp142;

      tmp143 = _N_Re;
      tmp144 = (tmp143 * tmp143);
      if (tmp144 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "$OpenHPL$PFunctions$PDarcyFriction$PfDarcy$funDERN_Re / N_Re ^ 2.0");}
      __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERfD = (-64.0) * ((__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe) / tmp144);
    }
    else
    {
      if((_N_Re < 2300.0))
      {
        tmp145 = _N_Re;
        tmp146 = _N_Re;
        _fD = (real_array_get(_K, 1, ((modelica_integer) 1))) * ((tmp145 * tmp145 * tmp145)) + (real_array_get(_K, 1, ((modelica_integer) 2))) * ((tmp146 * tmp146)) + (real_array_get(_K, 1, ((modelica_integer) 3))) * (_N_Re) + real_array_get(_K, 1, ((modelica_integer) 4));

        tmp147 = _N_Re;
        tmp148 = _N_Re;
        tmp149 = _N_Re;
        __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERfD = (3.0) * ((real_array_get(_K, 1, ((modelica_integer) 1))) * (((tmp147 * tmp147)) * (__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe))) + (real_array_get(__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERK, 1, ((modelica_integer) 1))) * ((tmp148 * tmp148 * tmp148)) + (2.0) * ((real_array_get(_K, 1, ((modelica_integer) 2))) * ((_N_Re) * (__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe))) + (real_array_get(__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERK, 1, ((modelica_integer) 2))) * ((tmp149 * tmp149)) + (real_array_get(_K, 1, ((modelica_integer) 3))) * (__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe) + (real_array_get(__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERK, 1, ((modelica_integer) 3))) * (_N_Re) + real_array_get(__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERK, 1, ((modelica_integer) 4));
      }
      else
      {
        tmp150 = _arg;
        if(!(tmp150 > 0.0))
        {
          FILE_INFO info = {"",0,0,0,0,0};
          omc_assert(threadData, info, "Model error: Argument of log10(arg) was %g should be > 0", tmp150);
        }tmp151 = (2.0) * (log10(tmp150));
        tmp152 = (tmp151 * tmp151);
        if (tmp152 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "1.0 / (2.0 * log10(arg)) ^ 2.0");}
        _fD = (1.0) / tmp152;

        tmp153 = _arg;
        if(!(tmp153 > 0.0))
        {
          FILE_INFO info = {"",0,0,0,0,0};
          omc_assert(threadData, info, "Model error: Argument of log10(arg) was %g should be > 0", tmp153);
        }tmp154 = (_arg) * (2.302585092994046);
        if (tmp154 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "$OpenHPL$PFunctions$PDarcyFriction$PfDarcy$funDERarg / (arg * 2.302585092994046)");}
        tmp155 = _arg;
        if(!(tmp155 > 0.0))
        {
          FILE_INFO info = {"",0,0,0,0,0};
          omc_assert(threadData, info, "Model error: Argument of log10(arg) was %g should be > 0", tmp155);
        }tmp156 = (2.0) * (log10(tmp155));
        tmp156 *= tmp156;tmp157 = (tmp156 * tmp156);
        if (tmp157 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "(-4.0) * log10(arg) * 2.0 * $OpenHPL$PFunctions$PDarcyFriction$PfDarcy$funDERarg / (arg * 2.302585092994046) / (2.0 * log10(arg)) ^ 4.0");}
        __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERfD = (((-4.0) * (log10(tmp153))) * ((2.0) * ((__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERarg) / tmp154))) / tmp157;
      }
    }
  }
  _return: OMC_LABEL_UNUSED
  return __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERfD;
}
modelica_metatype boxptr__omcQ_24DER_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy(threadData_t *threadData, modelica_metatype _N_Re, modelica_metatype _D, modelica_metatype _p_eps, modelica_metatype __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe, modelica_metatype __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERD, modelica_metatype __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERp_5Feps)
{
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  modelica_real tmp5;
  modelica_real tmp6;
  modelica_real __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERfD;
  modelica_metatype out__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERfD;
  tmp1 = mmc_unbox_real(_N_Re);
  tmp2 = mmc_unbox_real(_D);
  tmp3 = mmc_unbox_real(_p_eps);
  tmp4 = mmc_unbox_real(__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERN_5FRe);
  tmp5 = mmc_unbox_real(__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERD);
  tmp6 = mmc_unbox_real(__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERp_5Feps);
  __omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERfD = omc__omcQ_24DER_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy(threadData, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6);
  out__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERfD = mmc_mk_rcon(__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERfD);
  return out__omcQ_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy_24funDERfD;
}

modelica_real omc_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmax(threadData_t *threadData, modelica_complex _tableID)
{
  void * _tableID_ext;
  double _uMax_ext;
  modelica_real _uMax;
  // _uMax has no default value.
  _tableID_ext = (void *)_tableID;
  _uMax_ext = ModelicaStandardTables_CombiTable1D_maximumAbscissa(_tableID_ext);
  _uMax = (modelica_real)_uMax_ext;
  return _uMax;
}
modelica_metatype boxptr_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmax(threadData_t *threadData, modelica_metatype _tableID)
{
  modelica_real _uMax;
  modelica_metatype out_uMax;
  _uMax = omc_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmax(threadData, _tableID);
  out_uMax = mmc_mk_rcon(_uMax);
  return out_uMax;
}

modelica_real omc_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmin(threadData_t *threadData, modelica_complex _tableID)
{
  void * _tableID_ext;
  double _uMin_ext;
  modelica_real _uMin;
  // _uMin has no default value.
  _tableID_ext = (void *)_tableID;
  _uMin_ext = ModelicaStandardTables_CombiTable1D_minimumAbscissa(_tableID_ext);
  _uMin = (modelica_real)_uMin_ext;
  return _uMin;
}
modelica_metatype boxptr_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmin(threadData_t *threadData, modelica_metatype _tableID)
{
  modelica_real _uMin;
  modelica_metatype out_uMin;
  _uMin = omc_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmin(threadData, _tableID);
  out_uMin = mmc_mk_rcon(_uMin);
  return out_uMin;
}

modelica_real omc_Modelica_Blocks_Tables_Internal_getTable1DValueNoDer2(threadData_t *threadData, modelica_complex _tableID, modelica_integer _icol, modelica_real _u)
{
  void * _tableID_ext;
  int _icol_ext;
  double _u_ext;
  double _y_ext;
  modelica_real _y;
  // _y has no default value.
  _tableID_ext = (void *)_tableID;
  _icol_ext = (int)_icol;
  _u_ext = (double)_u;
  _y_ext = ModelicaStandardTables_CombiTable1D_getValue(_tableID_ext, _icol_ext, _u_ext);
  _y = (modelica_real)_y_ext;
  return _y;
}
modelica_metatype boxptr_Modelica_Blocks_Tables_Internal_getTable1DValueNoDer2(threadData_t *threadData, modelica_metatype _tableID, modelica_metatype _icol, modelica_metatype _u)
{
  modelica_integer tmp1;
  modelica_real tmp2;
  modelica_real _y;
  modelica_metatype out_y;
  tmp1 = mmc_unbox_integer(_icol);
  tmp2 = mmc_unbox_real(_u);
  _y = omc_Modelica_Blocks_Tables_Internal_getTable1DValueNoDer2(threadData, _tableID, tmp1, tmp2);
  out_y = mmc_mk_rcon(_y);
  return out_y;
}

modelica_complex omc_Modelica_Blocks_Types_ExternalCombiTable1D_constructor(threadData_t *threadData, modelica_string _tableName, modelica_string _fileName, real_array _table, integer_array _columns, modelica_integer _smoothness, modelica_integer _extrapolation, modelica_boolean _verboseRead)
{
  integer_array _columns_packed;
  int _smoothness_ext;
  int _extrapolation_ext;
  int _verboseRead_ext;
  void *_table_c89;
  void *_columns_c89;
  void * _externalCombiTable1D_ext;
  modelica_complex _externalCombiTable1D;
  // _externalCombiTable1D has no default value.
  pack_alloc_integer_array(&_columns, &_columns_packed);

  _smoothness_ext = (int)_smoothness;
  _extrapolation_ext = (int)_extrapolation;
  _verboseRead_ext = (int)_verboseRead;_table_c89 = (void*) data_of_real_c89_array(_table);
  _columns_c89 = (void*) data_of_integer_c89_array(_columns_packed);
  _externalCombiTable1D_ext = ModelicaStandardTables_CombiTable1D_init2(MMC_STRINGDATA(_fileName), MMC_STRINGDATA(_tableName), (const double*) _table_c89, size_of_dimension_base_array(_table, ((modelica_integer) 1)), size_of_dimension_base_array(_table, ((modelica_integer) 2)), (const int*) _columns_c89, size_of_dimension_base_array(_columns, ((modelica_integer) 1)), _smoothness_ext, _extrapolation_ext, _verboseRead_ext);
  _externalCombiTable1D = (modelica_complex)_externalCombiTable1D_ext;
  return _externalCombiTable1D;
}
modelica_metatype boxptr_Modelica_Blocks_Types_ExternalCombiTable1D_constructor(threadData_t *threadData, modelica_metatype _tableName, modelica_metatype _fileName, modelica_metatype _table, modelica_metatype _columns, modelica_metatype _smoothness, modelica_metatype _extrapolation, modelica_metatype _verboseRead)
{
  modelica_integer tmp1;
  modelica_integer tmp2;
  modelica_integer tmp3;
  modelica_complex _externalCombiTable1D;
  tmp1 = mmc_unbox_integer(_smoothness);
  tmp2 = mmc_unbox_integer(_extrapolation);
  tmp3 = mmc_unbox_integer(_verboseRead);
  _externalCombiTable1D = omc_Modelica_Blocks_Types_ExternalCombiTable1D_constructor(threadData, _tableName, _fileName, *((base_array_t*)_table), *((base_array_t*)_columns), tmp1, tmp2, tmp3);
  /* skip box _externalCombiTable1D; ExternalObject Modelica.Blocks.Types.ExternalCombiTable1D */
  return _externalCombiTable1D;
}

void omc_Modelica_Blocks_Types_ExternalCombiTable1D_destructor(threadData_t *threadData, modelica_complex _externalCombiTable1D)
{
  void * _externalCombiTable1D_ext;
  _externalCombiTable1D_ext = (void *)_externalCombiTable1D;
  ModelicaStandardTables_CombiTable1D_close(_externalCombiTable1D_ext);
  return;
}
void boxptr_Modelica_Blocks_Types_ExternalCombiTable1D_destructor(threadData_t *threadData, modelica_metatype _externalCombiTable1D)
{
  omc_Modelica_Blocks_Types_ExternalCombiTable1D_destructor(threadData, _externalCombiTable1D);
  return;
}

DLLExport
real_array omc_Modelica_Math_Matrices_inv(threadData_t *threadData, real_array _A)
{
  real_array _invA;
  modelica_integer tmp1;
  modelica_integer tmp2;
  modelica_integer _info;
  integer_array _pivots;
  modelica_integer tmp3;
  real_array _LU;
  modelica_integer tmp4;
  modelica_integer tmp5;
  static int tmp6 = 0;
  _tailrecursive: OMC_LABEL_UNUSED
  tmp1 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  tmp2 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  alloc_real_array(&(_invA), 2, (_index_t)tmp1, (_index_t)tmp2); // _invA has no default value.
  // _info has no default value.
  tmp3 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  alloc_integer_array(&(_pivots), 1, (_index_t)tmp3); // _pivots has no default value.
  tmp4 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  tmp5 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  alloc_real_array(&(_LU), 2, (_index_t)tmp4, (_index_t)tmp5); // _LU has no default value.
  real_array_copy_data(omc_Modelica_Math_Matrices_LAPACK_dgetrf(threadData, _A ,&_pivots ,&_info), _LU);

  {
    if(!(_info == ((modelica_integer) 0)))
    {
      {
        FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Math/package.mo",2603,5,2604,64,0};
        omc_assert(threadData, info, MMC_STRINGDATA(_OMC_LIT5));
      }
    }
  }

  real_array_copy_data(omc_Modelica_Math_Matrices_LAPACK_dgetri(threadData, _LU, _pivots, NULL), _invA);
  _return: OMC_LABEL_UNUSED
  return _invA;
}
modelica_metatype boxptr_Modelica_Math_Matrices_inv(threadData_t *threadData, modelica_metatype _A)
{
  real_array _invA;
  modelica_integer tmp1;
  modelica_integer tmp2;
  modelica_metatype out_invA;
  _invA = omc_Modelica_Math_Matrices_inv(threadData, *((base_array_t*)_A));
  out_invA = mmc_mk_modelica_array(_invA);
  return out_invA;
}

real_array omc_Modelica_Math_Matrices_LAPACK_dgetrf(threadData_t *threadData, real_array _A, integer_array *out_pivots, modelica_integer *out_info)
{
  /* extFunCallF77: varDecs */
  real_array _LU_ext;
  integer_array _pivots_ext;
  int _info_ext = 0;
  /* extFunCallF77: biVarDecs */
  modelica_integer _m;
  modelica_integer _m_ext;
  modelica_integer tmp1;
  modelica_integer _n;
  modelica_integer _n_ext;
  modelica_integer tmp2;
  modelica_integer _lda;
  modelica_integer _lda_ext;
  modelica_integer tmp3;
  /* extFunCallF77: args */
  real_array _LU;
  modelica_integer tmp4;
  modelica_integer tmp5;
  integer_array _pivots;
  modelica_integer tmp6;
  modelica_integer tmp7;
  modelica_integer _info;
  tmp1 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  _m = tmp1;
  tmp2 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  _n = tmp2;
  tmp3 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  _lda = modelica_integer_max((modelica_integer)(((modelica_integer) 1)),(modelica_integer)(tmp3));
  tmp4 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  tmp5 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  alloc_real_array(&(_LU), 2, (_index_t)tmp4, (_index_t)tmp5);
  real_array_copy_data(_A, _LU);
  
  tmp6 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  tmp7 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  alloc_integer_array(&(_pivots), 1, (_index_t)modelica_integer_min((modelica_integer)(tmp6),(modelica_integer)(tmp7))); // _pivots has no default value.
  // _info has no default value.
  /* extFunCallF77: biVarDecs */
  /* extFunCallF77: args */
  /* extFunCallF77: end args */
  convert_alloc_real_array_to_f77(&_LU, &_LU_ext);
  convert_alloc_integer_array_to_f77(&_pivots, &_pivots_ext);
  /* extFunCallF77: extReturn */
  /* extFunCallF77: CALL */
  dgetrf_((int*) &_m, (int*) &_n, data_of_real_f77_array(_LU_ext), (int*) &_lda, data_of_integer_f77_array(_pivots_ext), (int*) &_info_ext);
  /* extFunCallF77: copy args */
  convert_alloc_real_array_from_f77(&_LU_ext, &_LU);
  convert_alloc_integer_array_from_f77(&_pivots_ext, &_pivots);
  _info = (modelica_integer)_info_ext;
  /* extFunCallF77: copy return */
  if (out_pivots) { if (out_pivots->dim_size == NULL) {copy_integer_array(_pivots, out_pivots);} else {integer_array_copy_data(_pivots, *out_pivots);} }
  if (out_info) { *out_info = _info; }
  return _LU;
}
modelica_metatype boxptr_Modelica_Math_Matrices_LAPACK_dgetrf(threadData_t *threadData, modelica_metatype _A, modelica_metatype *out_pivots, modelica_metatype *out_info)
{
  integer_array _pivots;
  modelica_integer tmp1;
  modelica_integer tmp2;
  modelica_integer _info;
  real_array _LU;
  modelica_integer tmp3;
  modelica_integer tmp4;
  modelica_metatype out_LU;
  _LU = omc_Modelica_Math_Matrices_LAPACK_dgetrf(threadData, *((base_array_t*)_A), &_pivots, &_info);
  out_LU = mmc_mk_modelica_array(_LU);
  if (out_pivots) { *out_pivots = mmc_mk_modelica_array(_pivots); }
  if (out_info) { *out_info = mmc_mk_icon(_info); }
  return out_LU;
}

real_array omc_Modelica_Math_Matrices_LAPACK_dgetri(threadData_t *threadData, real_array _LU, integer_array _pivots, modelica_integer *out_info)
{
  /* extFunCallF77: varDecs */
  real_array _inv_ext;
  integer_array _pivots_ext;
  int _info_ext = 0;
  /* extFunCallF77: biVarDecs */
  modelica_integer _n;
  modelica_integer _n_ext;
  modelica_integer tmp1;
  modelica_integer _lda;
  modelica_integer _lda_ext;
  modelica_integer tmp2;
  modelica_integer _lwork;
  modelica_integer _lwork_ext;
  modelica_integer tmp3;
  modelica_integer tmp4;
  real_array _work;
  real_array _work_ext;
  modelica_integer tmp5;
  modelica_integer tmp6;
  /* extFunCallF77: args */
  real_array _inv;
  modelica_integer tmp7;
  modelica_integer tmp8;
  modelica_integer _info;
  tmp1 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  _n = tmp1;
  tmp2 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  _lda = modelica_integer_max((modelica_integer)(((modelica_integer) 1)),(modelica_integer)(tmp2));
  tmp3 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  tmp4 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  _lwork = modelica_integer_max((modelica_integer)(((modelica_integer) 1)),(modelica_integer)((modelica_integer_min((modelica_integer)(((modelica_integer) 10)),(modelica_integer)(tmp3))) * (tmp4)));
  tmp5 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  tmp6 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  alloc_real_array(&_work, 1, (_index_t)modelica_integer_max((modelica_integer)(((modelica_integer) 1)),(modelica_integer)((modelica_integer_min((modelica_integer)(((modelica_integer) 10)),(modelica_integer)(tmp5))) * (tmp6))));
  convert_alloc_real_array_to_f77(&_work, &_work_ext);
  tmp7 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  tmp8 = size_of_dimension_base_array(_LU, ((modelica_integer) 2));
  alloc_real_array(&(_inv), 2, (_index_t)tmp7, (_index_t)tmp8);
  real_array_copy_data(_LU, _inv);
  
  // _info has no default value.
  /* extFunCallF77: biVarDecs */
  /* extFunCallF77: args */
  /* extFunCallF77: end args */
  convert_alloc_real_array_to_f77(&_inv, &_inv_ext);
  convert_alloc_integer_array_to_f77(&_pivots, &_pivots_ext);
  /* extFunCallF77: extReturn */
  /* extFunCallF77: CALL */
  dgetri_((int*) &_n, data_of_real_f77_array(_inv_ext), (int*) &_lda, data_of_integer_f77_array(_pivots_ext), data_of_real_f77_array(_work_ext), (int*) &_lwork, (int*) &_info_ext);
  /* extFunCallF77: copy args */
  convert_alloc_real_array_from_f77(&_inv_ext, &_inv);
  _info = (modelica_integer)_info_ext;
  /* extFunCallF77: copy return */
  if (out_info) { *out_info = _info; }
  return _inv;
}
modelica_metatype boxptr_Modelica_Math_Matrices_LAPACK_dgetri(threadData_t *threadData, modelica_metatype _LU, modelica_metatype _pivots, modelica_metatype *out_info)
{
  modelica_integer _info;
  real_array _inv;
  modelica_integer tmp1;
  modelica_integer tmp2;
  modelica_metatype out_inv;
  _inv = omc_Modelica_Math_Matrices_LAPACK_dgetri(threadData, *((base_array_t*)_LU), *((base_array_t*)_pivots), &_info);
  out_inv = mmc_mk_modelica_array(_inv);
  if (out_info) { *out_info = mmc_mk_icon(_info); }
  return out_inv;
}

DLLExport
modelica_real omc_OpenHPL_Functions_DarcyFriction_Friction(threadData_t *threadData, modelica_real _v, modelica_real _D, modelica_real _L, modelica_real _rho, modelica_real _mu, modelica_real _p_eps)
{
  modelica_real _F_f;
  modelica_real _N_Re;
  modelica_real _f;
  modelica_real tmp1;
  modelica_real tmp2;
  _tailrecursive: OMC_LABEL_UNUSED
  // _F_f has no default value.
  // _N_Re has no default value.
  // _f has no default value.
  tmp1 = _mu;
  if (tmp1 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "rho * abs(v) * D / mu");}
  _N_Re = (((_rho) * (fabs(_v))) * (_D)) / tmp1;

  _f = omc_OpenHPL_Functions_DarcyFriction_fDarcy(threadData, _N_Re, _D, _p_eps);

  tmp2 = 4.0;
  if (tmp2 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "1.570796326794897 * f * rho * L * v * abs(v) * D / 4.0");}
  _F_f = (((((((1.570796326794897) * (_f)) * (_rho)) * (_L)) * (_v)) * (fabs(_v))) * (_D)) / tmp2;
  _return: OMC_LABEL_UNUSED
  return _F_f;
}
modelica_metatype boxptr_OpenHPL_Functions_DarcyFriction_Friction(threadData_t *threadData, modelica_metatype _v, modelica_metatype _D, modelica_metatype _L, modelica_metatype _rho, modelica_metatype _mu, modelica_metatype _p_eps)
{
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  modelica_real tmp5;
  modelica_real tmp6;
  modelica_real _F_f;
  modelica_metatype out_F_f;
  tmp1 = mmc_unbox_real(_v);
  tmp2 = mmc_unbox_real(_D);
  tmp3 = mmc_unbox_real(_L);
  tmp4 = mmc_unbox_real(_rho);
  tmp5 = mmc_unbox_real(_mu);
  tmp6 = mmc_unbox_real(_p_eps);
  _F_f = omc_OpenHPL_Functions_DarcyFriction_Friction(threadData, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6);
  out_F_f = mmc_mk_rcon(_F_f);
  return out_F_f;
}

DLLExport
modelica_real omc_OpenHPL_Functions_DarcyFriction_fDarcy(threadData_t *threadData, modelica_real _N_Re, modelica_real _D, modelica_real _p_eps)
{
  modelica_real _fD;
  modelica_real _arg;
  modelica_real _N_Re_lam;
  modelica_real _N_Re_tur;
  real_array _X;
  real_array _Y;
  real_array _K;
  real_array tmp1;
  real_array tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  real_array tmp5;
  modelica_real tmp6;
  modelica_real tmp7;
  real_array tmp8;
  modelica_real tmp9;
  real_array tmp10;
  modelica_real tmp11;
  real_array tmp12;
  modelica_real tmp13;
  modelica_real tmp14;
  modelica_real tmp15;
  modelica_real tmp16;
  modelica_real tmp17;
  modelica_real tmp18;
  modelica_real tmp19;
  modelica_real tmp20;
  modelica_real tmp21;
  modelica_real tmp22;
  modelica_real tmp23;
  modelica_real tmp24;
  modelica_real tmp25;
  modelica_real tmp26;
  modelica_real tmp27;
  modelica_real tmp28;
  modelica_real tmp29;
  modelica_real tmp30;
  modelica_real tmp31;
  modelica_real tmp32;
  modelica_real tmp33;
  modelica_real tmp34;
  modelica_real tmp35;
  modelica_real tmp36;
  modelica_real tmp37;
  modelica_real tmp38;
  modelica_real tmp39;
  modelica_real tmp40;
  modelica_real tmp41;
  modelica_real tmp42;
  modelica_real tmp43;
  modelica_real tmp44;
  modelica_real tmp45;
  modelica_real tmp46;
  modelica_real tmp47;
  modelica_real tmp48;
  modelica_real tmp49;
  modelica_real tmp50;
  modelica_real tmp51;
  modelica_real tmp52;
  _tailrecursive: OMC_LABEL_UNUSED
  // _fD has no default value.
  // _arg has no default value.
  _N_Re_lam = 2100.0;
  _N_Re_tur = 2300.0;
  alloc_real_array(&(_X), 2, (_index_t)4, (_index_t)4); // _X has no default value.
  alloc_real_array(&(_Y), 1, (_index_t)4); // _Y has no default value.
  alloc_real_array(&(_K), 1, (_index_t)4); // _K has no default value.
  tmp3 = _N_Re_lam;
  tmp4 = _N_Re_lam;
  array_alloc_scalar_real_array(&tmp2, 4, (modelica_real)(tmp3 * tmp3 * tmp3), (modelica_real)(tmp4 * tmp4), (modelica_real)_N_Re_lam, (modelica_real)1.0);
  tmp6 = _N_Re_tur;
  tmp7 = _N_Re_tur;
  array_alloc_scalar_real_array(&tmp5, 4, (modelica_real)(tmp6 * tmp6 * tmp6), (modelica_real)(tmp7 * tmp7), (modelica_real)_N_Re_tur, (modelica_real)1.0);
  tmp9 = _N_Re_lam;
  array_alloc_scalar_real_array(&tmp8, 4, (modelica_real)(3.0) * ((tmp9 * tmp9)), (modelica_real)(2.0) * (_N_Re_lam), (modelica_real)1.0, (modelica_real)0.0);
  tmp11 = _N_Re_tur;
  array_alloc_scalar_real_array(&tmp10, 4, (modelica_real)(3.0) * ((tmp11 * tmp11)), (modelica_real)(2.0) * (_N_Re_tur), (modelica_real)1.0, (modelica_real)0.0);
  array_alloc_real_array(&tmp1, 4, tmp2, tmp5, tmp8, tmp10);
  real_array_copy_data(tmp1, _X);

  tmp13 = _N_Re_lam;
  if (tmp13 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "64.0 / N_Re_lam");}
  tmp14 = 3.7;
  if (tmp14 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "p_eps / 3.7");}
  tmp15 = _D;
  if (tmp15 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "p_eps / 3.7 / D");}
  tmp16 = _N_Re_tur;
  tmp17 = 0.9;
  if(tmp16 < 0.0 && tmp17 != 0.0)
  {
    tmp19 = modf(tmp17, &tmp20);
    
    if(tmp19 > 0.5)
    {
      tmp19 -= 1.0;
      tmp20 += 1.0;
    }
    else if(tmp19 < -0.5)
    {
      tmp19 += 1.0;
      tmp20 -= 1.0;
    }
    
    if(fabs(tmp19) < 1e-10)
      tmp18 = pow(tmp16, tmp20);
    else
    {
      tmp22 = modf(1.0/tmp17, &tmp21);
      if(tmp22 > 0.5)
      {
        tmp22 -= 1.0;
        tmp21 += 1.0;
      }
      else if(tmp22 < -0.5)
      {
        tmp22 += 1.0;
        tmp21 -= 1.0;
      }
      if(fabs(tmp22) < 1e-10 && ((unsigned long)tmp21 & 1))
      {
        tmp18 = -pow(-tmp16, tmp19)*pow(tmp16, tmp20);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp16, tmp17);
      }
    }
  }
  else
  {
    tmp18 = pow(tmp16, tmp17);
  }
  if(isnan(tmp18) || isinf(tmp18))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp16, tmp17);
  }tmp23 = tmp18;
  if (tmp23 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "5.74 / N_Re_tur ^ 0.9");}
  tmp24 = ((_p_eps) / tmp14) / tmp15 + (5.74) / tmp23;
  if(!(tmp24 > 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert(threadData, info, "Model error: Argument of log10(p_eps / 3.7 / D + 5.74 / N_Re_tur ^ 0.9) was %g should be > 0", tmp24);
  }tmp25 = (2.0) * (log10(tmp24));
  tmp26 = (tmp25 * tmp25);
  if (tmp26 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "1.0 / (2.0 * log10(p_eps / 3.7 / D + 5.74 / N_Re_tur ^ 0.9)) ^ 2.0");}
  tmp27 = _N_Re_lam;
  tmp28 = (tmp27 * tmp27);
  if (tmp28 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "64.0 / N_Re_lam ^ 2.0");}
  tmp29 = _N_Re_tur;
  tmp30 = 1.25;
  if(tmp29 < 0.0 && tmp30 != 0.0)
  {
    tmp32 = modf(tmp30, &tmp33);
    
    if(tmp32 > 0.5)
    {
      tmp32 -= 1.0;
      tmp33 += 1.0;
    }
    else if(tmp32 < -0.5)
    {
      tmp32 += 1.0;
      tmp33 -= 1.0;
    }
    
    if(fabs(tmp32) < 1e-10)
      tmp31 = pow(tmp29, tmp33);
    else
    {
      tmp35 = modf(1.0/tmp30, &tmp34);
      if(tmp35 > 0.5)
      {
        tmp35 -= 1.0;
        tmp34 += 1.0;
      }
      else if(tmp35 < -0.5)
      {
        tmp35 += 1.0;
        tmp34 -= 1.0;
      }
      if(fabs(tmp35) < 1e-10 && ((unsigned long)tmp34 & 1))
      {
        tmp31 = -pow(-tmp29, tmp32)*pow(tmp29, tmp33);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp29, tmp30);
      }
    }
  }
  else
  {
    tmp31 = pow(tmp29, tmp30);
  }
  if(isnan(tmp31) || isinf(tmp31))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp29, tmp30);
  }tmp36 = tmp31;
  if (tmp36 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "0.079 / N_Re_tur ^ 1.25");}
  array_alloc_scalar_real_array(&tmp12, 4, (modelica_real)(64.0) / tmp13, (modelica_real)(1.0) / tmp26, (modelica_real)(-((64.0) / tmp28)), (modelica_real)(-((0.079) / tmp36)));
  real_array_copy_data(tmp12, _Y);

  real_array_copy_data(mul_alloc_real_matrix_product_smart(omc_Modelica_Math_Matrices_inv(threadData, _X), _Y), _K);

  tmp37 = 3.7;
  if (tmp37 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "p_eps / 3.7");}
  tmp38 = _D;
  if (tmp38 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "p_eps / 3.7 / D");}
  tmp39 = _N_Re + 1e-15;
  tmp40 = 0.9;
  if(tmp39 < 0.0 && tmp40 != 0.0)
  {
    tmp42 = modf(tmp40, &tmp43);
    
    if(tmp42 > 0.5)
    {
      tmp42 -= 1.0;
      tmp43 += 1.0;
    }
    else if(tmp42 < -0.5)
    {
      tmp42 += 1.0;
      tmp43 -= 1.0;
    }
    
    if(fabs(tmp42) < 1e-10)
      tmp41 = pow(tmp39, tmp43);
    else
    {
      tmp45 = modf(1.0/tmp40, &tmp44);
      if(tmp45 > 0.5)
      {
        tmp45 -= 1.0;
        tmp44 += 1.0;
      }
      else if(tmp45 < -0.5)
      {
        tmp45 += 1.0;
        tmp44 -= 1.0;
      }
      if(fabs(tmp45) < 1e-10 && ((unsigned long)tmp44 & 1))
      {
        tmp41 = -pow(-tmp39, tmp42)*pow(tmp39, tmp43);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp39, tmp40);
      }
    }
  }
  else
  {
    tmp41 = pow(tmp39, tmp40);
  }
  if(isnan(tmp41) || isinf(tmp41))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp39, tmp40);
  }tmp46 = tmp41;
  if (tmp46 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "5.74 / (N_Re + 1e-15) ^ 0.9");}
  _arg = ((_p_eps) / tmp37) / tmp38 + (5.74) / tmp46;

  if((_N_Re <= 0.0))
  {
    _fD = 0.0;
  }
  else
  {
    if((_N_Re <= 2100.0))
    {
      tmp47 = _N_Re;
      if (tmp47 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "64.0 / N_Re");}
      _fD = (64.0) / tmp47;
    }
    else
    {
      if((_N_Re < 2300.0))
      {
        tmp48 = _N_Re;
        tmp49 = _N_Re;
        _fD = (real_array_get(_K, 1, ((modelica_integer) 1))) * ((tmp48 * tmp48 * tmp48)) + (real_array_get(_K, 1, ((modelica_integer) 2))) * ((tmp49 * tmp49)) + (real_array_get(_K, 1, ((modelica_integer) 3))) * (_N_Re) + real_array_get(_K, 1, ((modelica_integer) 4));
      }
      else
      {
        tmp50 = _arg;
        if(!(tmp50 > 0.0))
        {
          FILE_INFO info = {"",0,0,0,0,0};
          omc_assert(threadData, info, "Model error: Argument of log10(arg) was %g should be > 0", tmp50);
        }tmp51 = (2.0) * (log10(tmp50));
        tmp52 = (tmp51 * tmp51);
        if (tmp52 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "1.0 / (2.0 * log10(arg)) ^ 2.0");}
        _fD = (1.0) / tmp52;
      }
    }
  }
  _return: OMC_LABEL_UNUSED
  return _fD;
}
modelica_metatype boxptr_OpenHPL_Functions_DarcyFriction_fDarcy(threadData_t *threadData, modelica_metatype _N_Re, modelica_metatype _D, modelica_metatype _p_eps)
{
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real _fD;
  modelica_metatype out_fD;
  tmp1 = mmc_unbox_real(_N_Re);
  tmp2 = mmc_unbox_real(_D);
  tmp3 = mmc_unbox_real(_p_eps);
  _fD = omc_OpenHPL_Functions_DarcyFriction_fDarcy(threadData, tmp1, tmp2, tmp3);
  out_fD = mmc_mk_rcon(_fD);
  return out_fD;
}

#ifdef __cplusplus
}
#endif
