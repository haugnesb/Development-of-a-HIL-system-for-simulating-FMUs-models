/* spatialDistribution */
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_function_storeSpatialDistribution(DATA *data, threadData_t *threadData)
{
  int equationIndexes[2] = {1,-1};
  
  TRACE_POP
  return 0;
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_function_initSpatialDistribution(DATA *data, threadData_t *threadData)
{

  
  TRACE_POP
  return 0;
}

#if defined(__cplusplus)
}
#endif

