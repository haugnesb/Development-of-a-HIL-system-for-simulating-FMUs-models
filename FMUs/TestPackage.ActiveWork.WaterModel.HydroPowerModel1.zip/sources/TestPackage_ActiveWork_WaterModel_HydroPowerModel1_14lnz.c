/* Linearization */
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_model.h"
#if defined(__cplusplus)
extern "C" {
#endif
const char *TestPackage_ActiveWork_WaterModel_HydroPowerModel1_linear_model_frame()
{
  return "model linearized_model \"TestPackage_ActiveWork_WaterModel_HydroPowerModel1\" \n  parameter Integer n = 5 \"number of states\";\n  parameter Integer m = 2 \"number of inputs\";\n  parameter Integer p = 7 \"number of outputs\";\n"
  "  parameter Real x0[n] = %s;\n"
  "  parameter Real u0[m] = %s;\n"
  "\n"
  "  parameter Real A[n, n] =\n\t[%s];\n\n"
  "  parameter Real B[n, m] =\n\t[%s];\n\n"
  "  parameter Real C[p, n] =\n\t[%s];\n\n"
  "  parameter Real D[p, m] =\n\t[%s];\n\n"
  "\n"
  "  Real x[n](start=x0);\n"
  "  input Real u[m](start=u0);\n"
  "  output Real y[p];\n"
  "\n"
  "  Real 'x_intake.M' = x[1];\n""  Real 'x_penstock.M' = x[2];\n""  Real 'x_surgeTank.m' = x[3];\n""  Real 'x_turbine1.setSpeed.phi' = x[4];\n""  Real 'x_turbine1.setSpeed.w' = x[5];\n"
  "  Real 'u_SM_speed_in' = u[1];\n""  Real 'u_SM_torque_in' = u[2];\n"
  "  Real 'y_SM_Speed_Out' = y[1];\n""  Real 'y_SM_Start_Stop_Out' = y[2];\n""  Real 'y_SM_Start_Torque_out' = y[3];\n""  Real 'y_TM_Forward_Reverse_Out' = y[4];\n""  Real 'y_TM_Speed_Torque_Out' = y[5];\n""  Real 'y_TM_Start_Stop_Out' = y[6];\n""  Real 'y_TM_Torque_Out' = y[7];\n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\nend linearized_model;\n";
}
const char *TestPackage_ActiveWork_WaterModel_HydroPowerModel1_linear_model_datarecovery_frame()
{
  return "model linearized_model \"TestPackage_ActiveWork_WaterModel_HydroPowerModel1\" \n parameter Integer n = 5 \"number of states\";\n  parameter Integer m = 2 \"number of inputs\";\n  parameter Integer p = 7 \"number of outputs\";\n  parameter Integer nz = 183 \"data recovery variables\";\n"
  "  parameter Real x0[5] = %s;\n"
  "  parameter Real u0[2] = %s;\n"
  "  parameter Real z0[183] = %s;\n"
  "\n"
  "  parameter Real A[n, n] =\n\t[%s];\n\n"
  "  parameter Real B[n, m] =\n\t[%s];\n\n"
  "  parameter Real C[p, n] =\n\t[%s];\n\n"
  "  parameter Real D[p, m] =\n\t[%s];\n\n"
  "  parameter Real Cz[nz, n] =\n\t[%s];\n\n"
  "  parameter Real Dz[nz, m] =\n\t[%s];\n\n"
  "\n"
  "  Real x[n](start=x0);\n"
  "  input Real u[m](start=u0);\n"
  "  output Real y[p];\n"
  "  output Real z[nz];\n"
  "\n"
  "  Real 'x_intake.M' = x[1];\n""  Real 'x_penstock.M' = x[2];\n""  Real 'x_surgeTank.m' = x[3];\n""  Real 'x_turbine1.setSpeed.phi' = x[4];\n""  Real 'x_turbine1.setSpeed.w' = x[5];\n"
  "  Real 'u_SM_speed_in' = u[1];\n""  Real 'u_SM_torque_in' = u[2];\n"
  "  Real 'y_SM_Speed_Out' = y[1];\n""  Real 'y_SM_Start_Stop_Out' = y[2];\n""  Real 'y_SM_Start_Torque_out' = y[3];\n""  Real 'y_TM_Forward_Reverse_Out' = y[4];\n""  Real 'y_TM_Speed_Torque_Out' = y[5];\n""  Real 'y_TM_Start_Stop_Out' = y[6];\n""  Real 'y_TM_Torque_Out' = y[7];\n"
  "  Real 'z_der(der(discharge.M))' = z[1];\n""  Real 'z_der(der(discharge.Vdot))' = z[2];\n""  Real 'z_der(der(discharge.mdot))' = z[3];\n""  Real 'z_der(der(intake.M))' = z[4];\n""  Real 'z_der(der(intake.Vdot))' = z[5];\n""  Real 'z_der(der(intake.mdot))' = z[6];\n""  Real 'z_der(der(penstock.M))' = z[7];\n""  Real 'z_der(der(penstock.Vdot))' = z[8];\n""  Real 'z_der(der(surgeTank.M))' = z[9];\n""  Real 'z_der(der(surgeTank.Vdot))' = z[10];\n""  Real 'z_der(der(surgeTank.mdot))' = z[11];\n""  Real 'z_der(der(surgeTank.v))' = z[12];\n""  Real 'z_der($outputAlias_SM_Speed_Out)' = z[13];\n""  Real 'z_der($outputAlias_SM_Start_Torque_out)' = z[14];\n""  Real 'z_der($outputAlias_TM_Torque_Out)' = z[15];\n""  Real 'z_der(add.u1)' = z[16];\n""  Real 'z_der(add.y)' = z[17];\n""  Real 'z_der(booleanToReal.y)' = z[18];\n""  Real 'z_der(discharge.F_f)' = z[19];\n""  Real 'z_der(discharge.M)' = z[20];\n""  Real 'z_der(discharge.Vdot)' = z[21];\n""  Real 'z_der(discharge.mdot)' = z[22];\n""  Real 'z_der(discharge.p_i)' = z[23];\n""  Real 'z_der(discharge.v)' = z[24];\n""  Real 'z_der(division.y)' = z[25];\n""  Real 'z_der(division1.y)' = z[26];\n""  Real 'z_der(division2.y)' = z[27];\n""  Real 'z_der(intake.F_f)' = z[28];\n""  Real 'z_der(intake.Vdot)' = z[29];\n""  Real 'z_der(intake.mdot)' = z[30];\n""  Real 'z_der(intake.p_o)' = z[31];\n""  Real 'z_der(intake.v)' = z[32];\n""  Real 'z_der(penstock.F_f)' = z[33];\n""  Real 'z_der(penstock.Vdot)' = z[34];\n""  Real 'z_der(penstock.p_o)' = z[35];\n""  Real 'z_der(penstock.v)' = z[36];\n""  Real 'z_der(step.y)' = z[37];\n""  Real 'z_der(surgeTank.F)' = z[38];\n""  Real 'z_der(surgeTank.F_f)' = z[39];\n""  Real 'z_der(surgeTank.F_g)' = z[40];\n""  Real 'z_der(surgeTank.F_p)' = z[41];\n""  Real 'z_der(surgeTank.M)' = z[42];\n""  Real 'z_der(surgeTank.Mdot)' = z[43];\n""  Real 'z_der(surgeTank.Vdot)' = z[44];\n""  Real 'z_der(surgeTank.l)' = z[45];\n""  Real 'z_der(surgeTank.mdot)' = z[46];\n""  Real 'z_der(surgeTank.v)' = z[47];\n""  Real 'z_der(turbine1.Kdot_i_tr)' = z[48];\n""  Real 'z_der(turbine1.Vdot)' = z[49];\n""  Real 'z_der(turbine1.Wdot_s)' = z[50];\n""  Real 'z_der(turbine1.dp)' = z[51];\n""  Real 'z_der(turbine1.friction.phi)' = z[52];\n""  Real 'z_der(turbine1.inertia.w)' = z[53];\n""  Real 'z_der(turbine1.look_up_table.u[1])' = z[54];\n""  Real 'z_der(turbine1.speedSensor.flange.phi)' = z[55];\n""  Real 'z_$SM_Speed_Out_der' = z[56];\n""  Real 'z_$SM_Start_Torque_out_der' = z[57];\n""  Real 'z_$TM_Torque_Out_der' = z[58];\n""  Real 'z_$cse1' = z[59];\n""  Real 'z_$cse2' = z[60];\n""  Real 'z_$cse3' = z[61];\n""  Real 'z_$cse4' = z[62];\n""  Real 'z_$cse5' = z[63];\n""  Real 'z_$cse6' = z[64];\n""  Real 'z_$cse7' = z[65];\n""  Real 'z_$cse8' = z[66];\n""  Real 'z_$outputAlias_SM_Speed_Out' = z[67];\n""  Real 'z_$outputAlias_SM_Start_Torque_out' = z[68];\n""  Real 'z_$outputAlias_TM_Torque_Out' = z[69];\n""  Real 'z_Power.y' = z[70];\n""  Real 'z_SM_Speed_Out' = z[71];\n""  Real 'z_SM_Start_Torque_out' = z[72];\n""  Real 'z_SM_speed_in' = z[73];\n""  Real 'z_SM_torque_in' = z[74];\n""  Real 'z_TM_Torque_Out' = z[75];\n""  Real 'z_add.u1' = z[76];\n""  Real 'z_add.y' = z[77];\n""  Real 'z_booleanToReal.y' = z[78];\n""  Real 'z_discharge.A_' = z[79];\n""  Real 'z_discharge.A_i' = z[80];\n""  Real 'z_discharge.A_o' = z[81];\n""  Real 'z_discharge.D_' = z[82];\n""  Real 'z_discharge.F_f' = z[83];\n""  Real 'z_discharge.M' = z[84];\n""  Real 'z_discharge.Vdot' = z[85];\n""  Real 'z_discharge.cos_theta' = z[86];\n""  Real 'z_discharge.dp' = z[87];\n""  Real 'z_discharge.m' = z[88];\n""  Real 'z_discharge.mdot' = z[89];\n""  Real 'z_discharge.p_i' = z[90];\n""  Real 'z_discharge.p_o' = z[91];\n""  Real 'z_discharge.v' = z[92];\n""  Real 'z_division.y' = z[93];\n""  Real 'z_division1.y' = z[94];\n""  Real 'z_division2.y' = z[95];\n""  Real 'z_intake.A_' = z[96];\n""  Real 'z_intake.A_i' = z[97];\n""  Real 'z_intake.A_o' = z[98];\n""  Real 'z_intake.D_' = z[99];\n""  Real 'z_intake.F_f' = z[100];\n""  Real 'z_intake.Vdot' = z[101];\n""  Real 'z_intake.cos_theta' = z[102];\n""  Real 'z_intake.dp' = z[103];\n""  Real 'z_intake.m' = z[104];\n""  Real 'z_intake.mdot' = z[105];\n""  Real 'z_intake.p_i' = z[106];\n""  Real 'z_intake.p_o' = z[107];\n""  Real 'z_intake.v' = z[108];\n""  Real 'z_penstock.A_' = z[109];\n""  Real 'z_penstock.A_i' = z[110];\n""  Real 'z_penstock.A_o' = z[111];\n""  Real 'z_penstock.D_' = z[112];\n""  Real 'z_penstock.F_f' = z[113];\n""  Real 'z_penstock.Vdot' = z[114];\n""  Real 'z_penstock.cos_theta' = z[115];\n""  Real 'z_penstock.dp' = z[116];\n""  Real 'z_penstock.m' = z[117];\n""  Real 'z_penstock.p_o' = z[118];\n""  Real 'z_penstock.v' = z[119];\n""  Real 'z_reservoir.A' = z[120];\n""  Real 'z_reservoir.F_f' = z[121];\n""  Real 'z_reservoir.M' = z[122];\n""  Real 'z_reservoir.Vdot' = z[123];\n""  Real 'z_reservoir.Vdot_i' = z[124];\n""  Real 'z_reservoir.m' = z[125];\n""  Real 'z_reservoir.mdot' = z[126];\n""  Real 'z_reservoir.v' = z[127];\n""  Real 'z_step.y' = z[128];\n""  Real 'z_surgeTank.A' = z[129];\n""  Real 'z_surgeTank.A_t' = z[130];\n""  Real 'z_surgeTank.F' = z[131];\n""  Real 'z_surgeTank.F_f' = z[132];\n""  Real 'z_surgeTank.F_g' = z[133];\n""  Real 'z_surgeTank.F_p' = z[134];\n""  Real 'z_surgeTank.M' = z[135];\n""  Real 'z_surgeTank.Mdot' = z[136];\n""  Real 'z_surgeTank.Vdot' = z[137];\n""  Real 'z_surgeTank.cos_theta' = z[138];\n""  Real 'z_surgeTank.h' = z[139];\n""  Real 'z_surgeTank.l' = z[140];\n""  Real 'z_surgeTank.m_a' = z[141];\n""  Real 'z_surgeTank.mdot' = z[142];\n""  Real 'z_surgeTank.phiSO' = z[143];\n""  Real 'z_surgeTank.v' = z[144];\n""  Real 'z_tail.A' = z[145];\n""  Real 'z_tail.F_f' = z[146];\n""  Real 'z_tail.M' = z[147];\n""  Real 'z_tail.Vdot' = z[148];\n""  Real 'z_tail.Vdot_i' = z[149];\n""  Real 'z_tail.m' = z[150];\n""  Real 'z_tail.mdot' = z[151];\n""  Real 'z_tail.v' = z[152];\n""  Real 'z_turbine1.C_v_' = z[153];\n""  Real 'z_turbine1.Kdot_i_tr' = z[154];\n""  Real 'z_turbine1.Vdot' = z[155];\n""  Real 'z_turbine1.Wdot_s' = z[156];\n""  Real 'z_turbine1.div0protect.y' = z[157];\n""  Real 'z_turbine1.dp' = z[158];\n""  Real 'z_turbine1.fixed.flange.tau' = z[159];\n""  Real 'z_turbine1.flange.tau' = z[160];\n""  Real 'z_turbine1.friction.flange.tau' = z[161];\n""  Real 'z_turbine1.friction.lossPower' = z[162];\n""  Real 'z_turbine1.friction.phi' = z[163];\n""  Real 'z_turbine1.friction.tau' = z[164];\n""  Real 'z_turbine1.friction.w' = z[165];\n""  Real 'z_turbine1.frictionLoss.flange_a.tau' = z[166];\n""  Real 'z_turbine1.frictionLoss.power' = z[167];\n""  Real 'z_turbine1.inertia.a' = z[168];\n""  Real 'z_turbine1.inertia.w' = z[169];\n""  Real 'z_turbine1.look_up_table.u[1]' = z[170];\n""  Real 'z_turbine1.look_up_table.y[1]' = z[171];\n""  Real 'z_turbine1.setSpeed.a' = z[172];\n""  Real 'z_turbine1.setSpeed.phi_support' = z[173];\n""  Real 'z_turbine1.setSpeed.w_ref' = z[174];\n""  Real 'z_turbine1.speedSensor.flange.phi' = z[175];\n""  Real 'z_turbine1.speedSensor.flange.tau' = z[176];\n""  Real 'z_turbine1.toHz.y' = z[177];\n""  Real 'z_turbine1.toSysSpeed.flange_a.tau' = z[178];\n""  Real 'z_turbine1.toSysSpeed.flange_b.tau' = z[179];\n""  Real 'z_turbine1.toSysSpeed.phi_support' = z[180];\n""  Real 'z_turbine1.torque.phi_support' = z[181];\n""  Real 'z_turbine1.torque.tau' = z[182];\n""  Real 'z_turbine1.torqueLimit.u' = z[183];\n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\n  z = Cz * x + Dz * u;\nend linearized_model;\n";
}
#if defined(__cplusplus)
}
#endif

