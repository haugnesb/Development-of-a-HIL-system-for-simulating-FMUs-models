/* update bound parameters and variable attributes (start, nominal, min, max) */
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_model.h"
#if defined(__cplusplus)
extern "C" {
#endif


/*
equation index: 642
type: SIMPLE_ASSIGN
$START.discharge.Vdot = discharge.Vdot_0
*/
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_642(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,642};
  (data->modelData->realVarsData[94] /* discharge.Vdot DUMMY_STATE */).attribute .start = (data->simulationInfo->realParameter[52] /* discharge.Vdot_0 PARAM */);
    (data->localData[0]->realVars[94] /* discharge.Vdot DUMMY_STATE */) = (data->modelData->realVarsData[94] /* discharge.Vdot DUMMY_STATE */).attribute .start;
    infoStreamPrint(LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[94].info /* discharge.Vdot */.name, (modelica_real) (data->localData[0]->realVars[94] /* discharge.Vdot DUMMY_STATE */));
  TRACE_POP
}

/*
equation index: 643
type: SIMPLE_ASSIGN
$START.turbine1.friction.w = turbine1.w_0
*/
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_643(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,643};
  (data->modelData->realVarsData[174] /* turbine1.friction.w variable */).attribute .start = (data->simulationInfo->realParameter[152] /* turbine1.w_0 PARAM */);
    (data->localData[0]->realVars[174] /* turbine1.friction.w variable */) = (data->modelData->realVarsData[174] /* turbine1.friction.w variable */).attribute .start;
    infoStreamPrint(LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[174].info /* turbine1.friction.w */.name, (modelica_real) (data->localData[0]->realVars[174] /* turbine1.friction.w variable */));
  TRACE_POP
}

/*
equation index: 644
type: SIMPLE_ASSIGN
$START.intake.Vdot = intake.Vdot_0
*/
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_644(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,644};
  (data->modelData->realVarsData[110] /* intake.Vdot DUMMY_STATE */).attribute .start = (data->simulationInfo->realParameter[63] /* intake.Vdot_0 PARAM */);
    (data->localData[0]->realVars[110] /* intake.Vdot DUMMY_STATE */) = (data->modelData->realVarsData[110] /* intake.Vdot DUMMY_STATE */).attribute .start;
    infoStreamPrint(LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[110].info /* intake.Vdot */.name, (modelica_real) (data->localData[0]->realVars[110] /* intake.Vdot DUMMY_STATE */));
  TRACE_POP
}

/*
equation index: 645
type: SIMPLE_ASSIGN
$START.surgeTank.Vdot = surgeTank.Vdot_0
*/
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_645(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,645};
  (data->modelData->realVarsData[146] /* surgeTank.Vdot DUMMY_STATE */).attribute .start = (data->simulationInfo->realParameter[89] /* surgeTank.Vdot_0 PARAM */);
    (data->localData[0]->realVars[146] /* surgeTank.Vdot DUMMY_STATE */) = (data->modelData->realVarsData[146] /* surgeTank.Vdot DUMMY_STATE */).attribute .start;
    infoStreamPrint(LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[146].info /* surgeTank.Vdot */.name, (modelica_real) (data->localData[0]->realVars[146] /* surgeTank.Vdot DUMMY_STATE */));
  TRACE_POP
}

/*
equation index: 646
type: SIMPLE_ASSIGN
$START.surgeTank.h = surgeTank.h_0
*/
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_646(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,646};
  (data->modelData->realVarsData[148] /* surgeTank.h variable */).attribute .start = (data->simulationInfo->realParameter[90] /* surgeTank.h_0 PARAM */);
    (data->localData[0]->realVars[148] /* surgeTank.h variable */) = (data->modelData->realVarsData[148] /* surgeTank.h variable */).attribute .start;
    infoStreamPrint(LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[148].info /* surgeTank.h */.name, (modelica_real) (data->localData[0]->realVars[148] /* surgeTank.h variable */));
  TRACE_POP
}

/*
equation index: 647
type: SIMPLE_ASSIGN
$START.penstock.Vdot = penstock.Vdot_0
*/
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_647(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,647};
  (data->modelData->realVarsData[123] /* penstock.Vdot DUMMY_STATE */).attribute .start = (data->simulationInfo->realParameter[70] /* penstock.Vdot_0 PARAM */);
    (data->localData[0]->realVars[123] /* penstock.Vdot DUMMY_STATE */) = (data->modelData->realVarsData[123] /* penstock.Vdot DUMMY_STATE */).attribute .start;
    infoStreamPrint(LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[123].info /* penstock.Vdot */.name, (modelica_real) (data->localData[0]->realVars[123] /* penstock.Vdot DUMMY_STATE */));
  TRACE_POP
}

/*
equation index: 648
type: SIMPLE_ASSIGN
$START.turbine1.inertia.w = turbine1.w_0
*/
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_648(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,648};
  (data->modelData->realVarsData[178] /* turbine1.inertia.w DUMMY_STATE */).attribute .start = (data->simulationInfo->realParameter[152] /* turbine1.w_0 PARAM */);
    (data->localData[0]->realVars[178] /* turbine1.inertia.w DUMMY_STATE */) = (data->modelData->realVarsData[178] /* turbine1.inertia.w DUMMY_STATE */).attribute .start;
    infoStreamPrint(LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[178].info /* turbine1.inertia.w */.name, (modelica_real) (data->localData[0]->realVars[178] /* turbine1.inertia.w DUMMY_STATE */));
  TRACE_POP
}
OMC_DISABLE_OPT
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_updateBoundVariableAttributes(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  /* min ******************************************************** */
  infoStreamPrint(LOG_INIT, 1, "updating min-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* max ******************************************************** */
  infoStreamPrint(LOG_INIT, 1, "updating max-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* nominal **************************************************** */
  infoStreamPrint(LOG_INIT, 1, "updating nominal-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* start ****************************************************** */
  infoStreamPrint(LOG_INIT, 1, "updating primary start-values");
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_642(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_643(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_644(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_645(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_646(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_647(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_648(data, threadData);
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  TRACE_POP
  return 0;
}

void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_updateBoundParameters_0(DATA *data, threadData_t *threadData);

/*
equation index: 649
type: SIMPLE_ASSIGN
turbine1.look_up_table.table[1,1] = turbine1.lookup_table[1,1]
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_649(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,649};
  (data->simulationInfo->realParameter[122] /* turbine1.look_up_table.table[1,1] PARAM */) = (data->simulationInfo->realParameter[134] /* turbine1.lookup_table[1,1] PARAM */);
  TRACE_POP
}

/*
equation index: 650
type: SIMPLE_ASSIGN
turbine1.look_up_table.table[1,2] = turbine1.lookup_table[1,2]
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_650(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,650};
  (data->simulationInfo->realParameter[123] /* turbine1.look_up_table.table[1,2] PARAM */) = (data->simulationInfo->realParameter[135] /* turbine1.lookup_table[1,2] PARAM */);
  TRACE_POP
}

/*
equation index: 651
type: SIMPLE_ASSIGN
turbine1.look_up_table.table[2,1] = turbine1.lookup_table[2,1]
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_651(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,651};
  (data->simulationInfo->realParameter[124] /* turbine1.look_up_table.table[2,1] PARAM */) = (data->simulationInfo->realParameter[136] /* turbine1.lookup_table[2,1] PARAM */);
  TRACE_POP
}

/*
equation index: 652
type: SIMPLE_ASSIGN
turbine1.look_up_table.table[2,2] = turbine1.lookup_table[2,2]
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_652(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,652};
  (data->simulationInfo->realParameter[125] /* turbine1.look_up_table.table[2,2] PARAM */) = (data->simulationInfo->realParameter[137] /* turbine1.lookup_table[2,2] PARAM */);
  TRACE_POP
}

/*
equation index: 653
type: SIMPLE_ASSIGN
turbine1.look_up_table.table[3,1] = turbine1.lookup_table[3,1]
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_653(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,653};
  (data->simulationInfo->realParameter[126] /* turbine1.look_up_table.table[3,1] PARAM */) = (data->simulationInfo->realParameter[138] /* turbine1.lookup_table[3,1] PARAM */);
  TRACE_POP
}

/*
equation index: 654
type: SIMPLE_ASSIGN
turbine1.look_up_table.table[3,2] = turbine1.lookup_table[3,2]
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_654(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,654};
  (data->simulationInfo->realParameter[127] /* turbine1.look_up_table.table[3,2] PARAM */) = (data->simulationInfo->realParameter[139] /* turbine1.lookup_table[3,2] PARAM */);
  TRACE_POP
}

/*
equation index: 655
type: SIMPLE_ASSIGN
turbine1.look_up_table.table[4,1] = turbine1.lookup_table[4,1]
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_655(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,655};
  (data->simulationInfo->realParameter[128] /* turbine1.look_up_table.table[4,1] PARAM */) = (data->simulationInfo->realParameter[140] /* turbine1.lookup_table[4,1] PARAM */);
  TRACE_POP
}

/*
equation index: 656
type: SIMPLE_ASSIGN
turbine1.look_up_table.table[4,2] = turbine1.lookup_table[4,2]
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_656(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,656};
  (data->simulationInfo->realParameter[129] /* turbine1.look_up_table.table[4,2] PARAM */) = (data->simulationInfo->realParameter[141] /* turbine1.lookup_table[4,2] PARAM */);
  TRACE_POP
}

/*
equation index: 657
type: SIMPLE_ASSIGN
turbine1.look_up_table.table[5,1] = turbine1.lookup_table[5,1]
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_657(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,657};
  (data->simulationInfo->realParameter[130] /* turbine1.look_up_table.table[5,1] PARAM */) = (data->simulationInfo->realParameter[142] /* turbine1.lookup_table[5,1] PARAM */);
  TRACE_POP
}

/*
equation index: 658
type: SIMPLE_ASSIGN
turbine1.look_up_table.table[5,2] = turbine1.lookup_table[5,2]
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_658(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,658};
  (data->simulationInfo->realParameter[131] /* turbine1.look_up_table.table[5,2] PARAM */) = (data->simulationInfo->realParameter[143] /* turbine1.lookup_table[5,2] PARAM */);
  TRACE_POP
}

/*
equation index: 659
type: SIMPLE_ASSIGN
turbine1.look_up_table.tableID = Modelica.Blocks.Types.ExternalCombiTable1D.constructor("NoName", "NoName", turbine1.look_up_table.table, turbine1.look_up_table.columns, Modelica.Blocks.Types.Smoothness.LinearSegments, Modelica.Blocks.Types.Extrapolation.LastTwoPoints, false)
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_659(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,659};
  real_array tmp0;
  integer_array tmp1;
  real_array_create(&tmp0, ((modelica_real*)&((&data->simulationInfo->realParameter[122] /* turbine1.look_up_table.table[1,1] PARAM */)[(((modelica_integer) 1) - 1) * 2 + (((modelica_integer) 1)-1)])), 2, (_index_t)5, (_index_t)2);
  integer_array_create(&tmp1, ((modelica_integer*)&((&data->simulationInfo->integerParameter[7] /* turbine1.look_up_table.columns[1] PARAM */)[((modelica_integer) 1) - 1])), 1, (_index_t)1);
  (data->simulationInfo->extObjs[0]) = omc_Modelica_Blocks_Types_ExternalCombiTable1D_constructor(threadData, _OMC_LIT15, _OMC_LIT15, tmp0, tmp1, 1, 2, 0);
  TRACE_POP
}

/*
equation index: 660
type: SIMPLE_ASSIGN
division.u2 = constant1.k
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_660(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,660};
  (data->simulationInfo->realParameter[54] /* division.u2 PARAM */) = (data->simulationInfo->realParameter[23] /* constant1.k PARAM */);
  TRACE_POP
}

/*
equation index: 661
type: SIMPLE_ASSIGN
constant1.y = constant1.k
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_661(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,661};
  (data->simulationInfo->realParameter[24] /* constant1.y PARAM */) = (data->simulationInfo->realParameter[23] /* constant1.k PARAM */);
  TRACE_POP
}

/*
equation index: 662
type: SIMPLE_ASSIGN
surgeTank.p_t = data.p_a
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_662(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,662};
  (data->simulationInfo->realParameter[93] /* surgeTank.p_t PARAM */) = (data->simulationInfo->realParameter[45] /* data.p_a PARAM */);
  TRACE_POP
}

/*
equation index: 663
type: SIMPLE_ASSIGN
turbine1.friction.support.phi = turbine1.fixed.phi0
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_663(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,663};
  (data->simulationInfo->realParameter[120] /* turbine1.friction.support.phi PARAM */) = (data->simulationInfo->realParameter[112] /* turbine1.fixed.phi0 PARAM */);
  TRACE_POP
}

/*
equation index: 664
type: SIMPLE_ASSIGN
turbine1.fixed.flange.phi = turbine1.fixed.phi0
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_664(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,664};
  (data->simulationInfo->realParameter[111] /* turbine1.fixed.flange.phi PARAM */) = (data->simulationInfo->realParameter[112] /* turbine1.fixed.phi0 PARAM */);
  TRACE_POP
}

/*
equation index: 665
type: SIMPLE_ASSIGN
greaterEqual.u2 = constant3.k
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_665(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,665};
  (data->simulationInfo->realParameter[56] /* greaterEqual.u2 PARAM */) = (data->simulationInfo->realParameter[27] /* constant3.k PARAM */);
  TRACE_POP
}

/*
equation index: 666
type: SIMPLE_ASSIGN
constant3.y = constant3.k
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_666(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,666};
  (data->simulationInfo->realParameter[28] /* constant3.y PARAM */) = (data->simulationInfo->realParameter[27] /* constant3.k PARAM */);
  TRACE_POP
}

/*
equation index: 667
type: SIMPLE_ASSIGN
division2.u2 = constant4.k
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_667(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,667};
  (data->simulationInfo->realParameter[55] /* division2.u2 PARAM */) = (data->simulationInfo->realParameter[29] /* constant4.k PARAM */);
  TRACE_POP
}

/*
equation index: 668
type: SIMPLE_ASSIGN
constant4.y = constant4.k
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_668(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,668};
  (data->simulationInfo->realParameter[30] /* constant4.y PARAM */) = (data->simulationInfo->realParameter[29] /* constant4.k PARAM */);
  TRACE_POP
}

/*
equation index: 669
type: SIMPLE_ASSIGN
tail.h = constant2.k
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_669(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,669};
  (data->simulationInfo->realParameter[98] /* tail.h PARAM */) = (data->simulationInfo->realParameter[25] /* constant2.k PARAM */);
  TRACE_POP
}

/*
equation index: 670
type: SIMPLE_ASSIGN
tail.level = constant2.k
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_670(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,670};
  (data->simulationInfo->realParameter[100] /* tail.level PARAM */) = (data->simulationInfo->realParameter[25] /* constant2.k PARAM */);
  TRACE_POP
}

/*
equation index: 671
type: SIMPLE_ASSIGN
constant2.y = constant2.k
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_671(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,671};
  (data->simulationInfo->realParameter[26] /* constant2.y PARAM */) = (data->simulationInfo->realParameter[25] /* constant2.k PARAM */);
  TRACE_POP
}

/*
equation index: 672
type: SIMPLE_ASSIGN
reservoir.h = const.k
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_672(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,672};
  (data->simulationInfo->realParameter[76] /* reservoir.h PARAM */) = (data->simulationInfo->realParameter[21] /* const.k PARAM */);
  TRACE_POP
}

/*
equation index: 673
type: SIMPLE_ASSIGN
reservoir.level = const.k
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_673(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,673};
  (data->simulationInfo->realParameter[78] /* reservoir.level PARAM */) = (data->simulationInfo->realParameter[21] /* const.k PARAM */);
  TRACE_POP
}

/*
equation index: 674
type: SIMPLE_ASSIGN
const.y = const.k
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_674(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,674};
  (data->simulationInfo->realParameter[22] /* const.y PARAM */) = (data->simulationInfo->realParameter[21] /* const.k PARAM */);
  TRACE_POP
}

/*
equation index: 678
type: SIMPLE_ASSIGN
ServoMotorTorque.startTime = ServoMotorTorqueStartTime
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_678(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,678};
  (data->simulationInfo->realParameter[4] /* ServoMotorTorque.startTime PARAM */) = (data->simulationInfo->realParameter[8] /* ServoMotorTorqueStartTime PARAM */);
  TRACE_POP
}

/*
equation index: 679
type: SIMPLE_ASSIGN
ServoMotorTorque.offset = ServoMotorTorqueOffset
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_679(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,679};
  (data->simulationInfo->realParameter[3] /* ServoMotorTorque.offset PARAM */) = (data->simulationInfo->realParameter[7] /* ServoMotorTorqueOffset PARAM */);
  TRACE_POP
}

/*
equation index: 680
type: SIMPLE_ASSIGN
ServoMotorTorque.duration = ServoMotorTorqueDuration
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_680(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,680};
  (data->simulationInfo->realParameter[1] /* ServoMotorTorque.duration PARAM */) = (data->simulationInfo->realParameter[6] /* ServoMotorTorqueDuration PARAM */);
  TRACE_POP
}

/*
equation index: 681
type: SIMPLE_ASSIGN
ServoMotorTorque.height = ServoMotorTorqueAmplitude
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_681(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,681};
  (data->simulationInfo->realParameter[2] /* ServoMotorTorque.height PARAM */) = (data->simulationInfo->realParameter[5] /* ServoMotorTorqueAmplitude PARAM */);
  TRACE_POP
}

/*
equation index: 682
type: SIMPLE_ASSIGN
ServoMotorVoltage.startTime = ServoMotorVoltageStartTime
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_682(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,682};
  (data->simulationInfo->realParameter[12] /* ServoMotorVoltage.startTime PARAM */) = (data->simulationInfo->realParameter[16] /* ServoMotorVoltageStartTime PARAM */);
  TRACE_POP
}

/*
equation index: 683
type: SIMPLE_ASSIGN
ServoMotorVoltage.offset = ServoMotorVoltageOffset
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_683(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,683};
  (data->simulationInfo->realParameter[11] /* ServoMotorVoltage.offset PARAM */) = (data->simulationInfo->realParameter[15] /* ServoMotorVoltageOffset PARAM */);
  TRACE_POP
}

/*
equation index: 684
type: SIMPLE_ASSIGN
ServoMotorVoltage.duration = ServoMotorVoltageDuration
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_684(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,684};
  (data->simulationInfo->realParameter[9] /* ServoMotorVoltage.duration PARAM */) = (data->simulationInfo->realParameter[14] /* ServoMotorVoltageDuration PARAM */);
  TRACE_POP
}

/*
equation index: 685
type: SIMPLE_ASSIGN
ServoMotorVoltage.height = ServoMotorVoltageAmplitude
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_685(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,685};
  (data->simulationInfo->realParameter[10] /* ServoMotorVoltage.height PARAM */) = (data->simulationInfo->realParameter[13] /* ServoMotorVoltageAmplitude PARAM */);
  TRACE_POP
}

/*
equation index: 686
type: SIMPLE_ASSIGN
discharge.Vdot_0 = data.Vdot_0
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_686(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,686};
  (data->simulationInfo->realParameter[52] /* discharge.Vdot_0 PARAM */) = (data->simulationInfo->realParameter[37] /* data.Vdot_0 PARAM */);
  TRACE_POP
}

/*
equation index: 688
type: SIMPLE_ASSIGN
discharge.p_eps = data.p_eps
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_688(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,688};
  (data->simulationInfo->realParameter[53] /* discharge.p_eps PARAM */) = (data->simulationInfo->realParameter[46] /* data.p_eps PARAM */);
  TRACE_POP
}

/*
equation index: 689
type: SIMPLE_ASSIGN
discharge.D_o = discharge.D_i
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_689(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,689};
  (data->simulationInfo->realParameter[49] /* discharge.D_o PARAM */) = (data->simulationInfo->realParameter[48] /* discharge.D_i PARAM */);
  TRACE_POP
}

/*
equation index: 690
type: SIMPLE_ASSIGN
turbine1.look_up_table.u_max = Modelica.Blocks.Tables.Internal.getTable1DAbscissaUmax(turbine1.look_up_table.tableID)
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_690(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,690};
  (data->simulationInfo->realParameter[132] /* turbine1.look_up_table.u_max PARAM */) = omc_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmax(threadData, (data->simulationInfo->extObjs[0]));
  TRACE_POP
}

/*
equation index: 691
type: SIMPLE_ASSIGN
turbine1.look_up_table.u_min = Modelica.Blocks.Tables.Internal.getTable1DAbscissaUmin(turbine1.look_up_table.tableID)
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_691(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,691};
  (data->simulationInfo->realParameter[133] /* turbine1.look_up_table.u_min PARAM */) = omc_Modelica_Blocks_Tables_Internal_getTable1DAbscissaUmin(threadData, (data->simulationInfo->extObjs[0]));
  TRACE_POP
}

/*
equation index: 698
type: SIMPLE_ASSIGN
turbine1.pu2w.k = 12.56637061435917 * data.f_0 / (*Real*)(turbine1.p)
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_698(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,698};
  (data->simulationInfo->realParameter[144] /* turbine1.pu2w.k PARAM */) = (12.56637061435917) * (DIVISION_SIM((data->simulationInfo->realParameter[41] /* data.f_0 PARAM */),((modelica_real)(data->simulationInfo->integerParameter[11] /* turbine1.p PARAM */)),"/*Real*/(turbine1.p)",equationIndexes));
  TRACE_POP
}

/*
equation index: 699
type: SIMPLE_ASSIGN
turbine1.toSysSpeed.ratio = 2.0 / (*Real*)(turbine1.p)
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_699(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,699};
  (data->simulationInfo->realParameter[148] /* turbine1.toSysSpeed.ratio PARAM */) = DIVISION_SIM(2.0,((modelica_real)(data->simulationInfo->integerParameter[11] /* turbine1.p PARAM */)),"/*Real*/(turbine1.p)",equationIndexes);
  TRACE_POP
}

/*
equation index: 701
type: SIMPLE_ASSIGN
turbine1.setSpeed.w_crit = 6.283185307179586 * turbine1.setSpeed.f_crit
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_701(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,701};
  (data->simulationInfo->realParameter[146] /* turbine1.setSpeed.w_crit PARAM */) = (6.283185307179586) * ((data->simulationInfo->realParameter[145] /* turbine1.setSpeed.f_crit PARAM */));
  TRACE_POP
}

/*
equation index: 706
type: SIMPLE_ASSIGN
turbine1.w_0 = 12.56637061435917 * data.f_0 / (*Real*)(turbine1.p)
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_706(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,706};
  (data->simulationInfo->realParameter[152] /* turbine1.w_0 PARAM */) = (12.56637061435917) * (DIVISION_SIM((data->simulationInfo->realParameter[41] /* data.f_0 PARAM */),((modelica_real)(data->simulationInfo->integerParameter[11] /* turbine1.p PARAM */)),"/*Real*/(turbine1.p)",equationIndexes));
  TRACE_POP
}

/*
equation index: 707
type: SIMPLE_ASSIGN
turbine1.torqueLimit.uMax = turbine1.Pmax / turbine1.w_0
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_707(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,707};
  (data->simulationInfo->realParameter[149] /* turbine1.torqueLimit.uMax PARAM */) = DIVISION_SIM((data->simulationInfo->realParameter[106] /* turbine1.Pmax PARAM */),(data->simulationInfo->realParameter[152] /* turbine1.w_0 PARAM */),"turbine1.w_0",equationIndexes);
  TRACE_POP
}

/*
equation index: 708
type: SIMPLE_ASSIGN
turbine1.torqueLimit.uMin = -turbine1.torqueLimit.uMax
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_708(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,708};
  (data->simulationInfo->realParameter[150] /* turbine1.torqueLimit.uMin PARAM */) = (-(data->simulationInfo->realParameter[149] /* turbine1.torqueLimit.uMax PARAM */));
  TRACE_POP
}

/*
equation index: 709
type: SIMPLE_ASSIGN
turbine1.toHz.k = 0.07957747154594767 * (*Real*)(turbine1.p)
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_709(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,709};
  (data->simulationInfo->realParameter[147] /* turbine1.toHz.k PARAM */) = (0.07957747154594767) * (((modelica_real)(data->simulationInfo->integerParameter[11] /* turbine1.p PARAM */)));
  TRACE_POP
}

/*
equation index: 715
type: SIMPLE_ASSIGN
turbine1.friction.frictionParameters.wRef = 12.56637061435917 * data.f_0 / (*Real*)(turbine1.p)
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_715(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,715};
  (data->simulationInfo->realParameter[119] /* turbine1.friction.frictionParameters.wRef PARAM */) = (12.56637061435917) * (DIVISION_SIM((data->simulationInfo->realParameter[41] /* data.f_0 PARAM */),((modelica_real)(data->simulationInfo->integerParameter[11] /* turbine1.p PARAM */)),"/*Real*/(turbine1.p)",equationIndexes));
  TRACE_POP
}

/*
equation index: 716
type: SIMPLE_ASSIGN
turbine1.friction.frictionParameters.wLinear = 0.001 * turbine1.friction.frictionParameters.wRef
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_716(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,716};
  (data->simulationInfo->realParameter[118] /* turbine1.friction.frictionParameters.wLinear PARAM */) = (0.001) * ((data->simulationInfo->realParameter[119] /* turbine1.friction.frictionParameters.wRef PARAM */));
  TRACE_POP
}

/*
equation index: 721
type: SIMPLE_ASSIGN
turbine1.inertia.J = if turbine1.useH then 2.0 * turbine1.H * turbine1.Pmax / turbine1.w_0 ^ 2.0 else turbine1.J
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_721(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,721};
  modelica_real tmp2;
  modelica_boolean tmp3;
  modelica_real tmp4;
  tmp3 = (modelica_boolean)(data->simulationInfo->booleanParameter[31] /* turbine1.useH PARAM */);
  if(tmp3)
  {
    tmp2 = (data->simulationInfo->realParameter[152] /* turbine1.w_0 PARAM */);
    tmp4 = DIVISION_SIM(((2.0) * ((data->simulationInfo->realParameter[102] /* turbine1.H PARAM */))) * ((data->simulationInfo->realParameter[106] /* turbine1.Pmax PARAM */)),(tmp2 * tmp2),"turbine1.w_0 ^ 2.0",equationIndexes);
  }
  else
  {
    tmp4 = (data->simulationInfo->realParameter[104] /* turbine1.J PARAM */);
  }
  (data->simulationInfo->realParameter[121] /* turbine1.inertia.J PARAM */) = tmp4;
  TRACE_POP
}

/*
equation index: 729
type: SIMPLE_ASSIGN
intake.Vdot_0 = data.Vdot_0
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_729(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,729};
  (data->simulationInfo->realParameter[63] /* intake.Vdot_0 PARAM */) = (data->simulationInfo->realParameter[37] /* data.Vdot_0 PARAM */);
  TRACE_POP
}

/*
equation index: 731
type: SIMPLE_ASSIGN
intake.p_eps = data.p_eps
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_731(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,731};
  (data->simulationInfo->realParameter[64] /* intake.p_eps PARAM */) = (data->simulationInfo->realParameter[46] /* data.p_eps PARAM */);
  TRACE_POP
}

/*
equation index: 732
type: SIMPLE_ASSIGN
intake.D_o = intake.D_i
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_732(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,732};
  (data->simulationInfo->realParameter[60] /* intake.D_o PARAM */) = (data->simulationInfo->realParameter[59] /* intake.D_i PARAM */);
  TRACE_POP
}

/*
equation index: 733
type: SIMPLE_ASSIGN
surgeTank.p_ac = 4.0 * data.p_a
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_733(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,733};
  (data->simulationInfo->realParameter[91] /* surgeTank.p_ac PARAM */) = (4.0) * ((data->simulationInfo->realParameter[45] /* data.p_a PARAM */));
  TRACE_POP
}

/*
equation index: 735
type: SIMPLE_ASSIGN
surgeTank.p_eps = data.p_eps
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_735(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,735};
  (data->simulationInfo->realParameter[92] /* surgeTank.p_eps PARAM */) = (data->simulationInfo->realParameter[46] /* data.p_eps PARAM */);
  TRACE_POP
}

/*
equation index: 737
type: SIMPLE_ASSIGN
penstock.Vdot_0 = data.Vdot_0
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_737(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,737};
  (data->simulationInfo->realParameter[70] /* penstock.Vdot_0 PARAM */) = (data->simulationInfo->realParameter[37] /* data.Vdot_0 PARAM */);
  TRACE_POP
}

/*
equation index: 739
type: SIMPLE_ASSIGN
penstock.p_eps = data.p_eps
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_739(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,739};
  (data->simulationInfo->realParameter[71] /* penstock.p_eps PARAM */) = (data->simulationInfo->realParameter[46] /* data.p_eps PARAM */);
  TRACE_POP
}

/*
equation index: 743
type: SIMPLE_ASSIGN
data.beta_total = 1e-06 / data.rho
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_743(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,743};
  (data->simulationInfo->realParameter[39] /* data.beta_total PARAM */) = DIVISION_SIM(1e-06,(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes);
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_43(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_42(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_41(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_38(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_37(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_36(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_35(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_32(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_30(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_29(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_28(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_27(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_26(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_23(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_22(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_206(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_205(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_204(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_203(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_202(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_201(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_200(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_199(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_3(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_198(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_21(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_191(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_197(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_20(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_196(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_195(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_24(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_31(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_33(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_39(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_40(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_194(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_193(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_192(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_34(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_25(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_6(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_5(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_4(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_2(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_1(DATA *data, threadData_t *threadData);


/*
equation index: 790
type: ALGORITHM

  assert(tail.h >= 0.0, "Variable violating min constraint: 0.0 <= tail.h, has value: " + String(tail.h, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_790(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,790};
  modelica_boolean tmp5;
  static const MMC_DEFSTRINGLIT(tmp6,61,"Variable violating min constraint: 0.0 <= tail.h, has value: ");
  modelica_string tmp7;
  modelica_metatype tmpMeta8;
  static int tmp9 = 0;
  if(!tmp9)
  {
    tmp5 = GreaterEq((data->simulationInfo->realParameter[98] /* tail.h PARAM */),0.0);
    if(!tmp5)
    {
      tmp7 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[98] /* tail.h PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta8 = stringAppend(MMC_REFSTRINGLIT(tmp6),tmp7);
      {
        const char* assert_cond = "(tail.h >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Reservoir.mo",36,3,36,28,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta8));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Reservoir.mo",36,3,36,28,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta8));
        }
      }
      tmp9 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 791
type: ALGORITHM

  assert(reservoir.h >= 0.0, "Variable violating min constraint: 0.0 <= reservoir.h, has value: " + String(reservoir.h, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_791(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,791};
  modelica_boolean tmp10;
  static const MMC_DEFSTRINGLIT(tmp11,66,"Variable violating min constraint: 0.0 <= reservoir.h, has value: ");
  modelica_string tmp12;
  modelica_metatype tmpMeta13;
  static int tmp14 = 0;
  if(!tmp14)
  {
    tmp10 = GreaterEq((data->simulationInfo->realParameter[76] /* reservoir.h PARAM */),0.0);
    if(!tmp10)
    {
      tmp12 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[76] /* reservoir.h PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta13 = stringAppend(MMC_REFSTRINGLIT(tmp11),tmp12);
      {
        const char* assert_cond = "(reservoir.h >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Reservoir.mo",36,3,36,28,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta13));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Reservoir.mo",36,3,36,28,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta13));
        }
      }
      tmp14 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 792
type: ALGORITHM

  assert(ServoMotorTorque.duration >= 0.0, "Variable violating min constraint: 0.0 <= ServoMotorTorque.duration, has value: " + String(ServoMotorTorque.duration, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_792(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,792};
  modelica_boolean tmp15;
  static const MMC_DEFSTRINGLIT(tmp16,80,"Variable violating min constraint: 0.0 <= ServoMotorTorque.duration, has value: ");
  modelica_string tmp17;
  modelica_metatype tmpMeta18;
  static int tmp19 = 0;
  if(!tmp19)
  {
    tmp15 = GreaterEq((data->simulationInfo->realParameter[1] /* ServoMotorTorque.duration PARAM */),0.0);
    if(!tmp15)
    {
      tmp17 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[1] /* ServoMotorTorque.duration PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta18 = stringAppend(MMC_REFSTRINGLIT(tmp16),tmp17);
      {
        const char* assert_cond = "(ServoMotorTorque.duration >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Sources.mo",247,5,248,46,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta18));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Sources.mo",247,5,248,46,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta18));
        }
      }
      tmp19 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 793
type: ALGORITHM

  assert(ServoMotorVoltage.duration >= 0.0, "Variable violating min constraint: 0.0 <= ServoMotorVoltage.duration, has value: " + String(ServoMotorVoltage.duration, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_793(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,793};
  modelica_boolean tmp20;
  static const MMC_DEFSTRINGLIT(tmp21,81,"Variable violating min constraint: 0.0 <= ServoMotorVoltage.duration, has value: ");
  modelica_string tmp22;
  modelica_metatype tmpMeta23;
  static int tmp24 = 0;
  if(!tmp24)
  {
    tmp20 = GreaterEq((data->simulationInfo->realParameter[9] /* ServoMotorVoltage.duration PARAM */),0.0);
    if(!tmp20)
    {
      tmp22 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[9] /* ServoMotorVoltage.duration PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta23 = stringAppend(MMC_REFSTRINGLIT(tmp21),tmp22);
      {
        const char* assert_cond = "(ServoMotorVoltage.duration >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Sources.mo",247,5,248,46,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta23));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Sources.mo",247,5,248,46,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta23));
        }
      }
      tmp24 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 794
type: ALGORITHM

  assert(data.p_eps >= 0.0, "Variable violating min constraint: 0.0 <= data.p_eps, has value: " + String(data.p_eps, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_794(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,794};
  modelica_boolean tmp25;
  static const MMC_DEFSTRINGLIT(tmp26,65,"Variable violating min constraint: 0.0 <= data.p_eps, has value: ");
  modelica_string tmp27;
  modelica_metatype tmpMeta28;
  static int tmp29 = 0;
  if(!tmp29)
  {
    tmp25 = GreaterEq((data->simulationInfo->realParameter[46] /* data.p_eps PARAM */),0.0);
    if(!tmp25)
    {
      tmp27 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[46] /* data.p_eps PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta28 = stringAppend(MMC_REFSTRINGLIT(tmp26),tmp27);
      {
        const char* assert_cond = "(data.p_eps >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Data.mo",16,3,17,55,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta28));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Data.mo",16,3,17,55,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta28));
        }
      }
      tmp29 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 795
type: ALGORITHM

  assert(discharge.p_eps >= 0.0, "Variable violating min constraint: 0.0 <= discharge.p_eps, has value: " + String(discharge.p_eps, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_795(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,795};
  modelica_boolean tmp30;
  static const MMC_DEFSTRINGLIT(tmp31,70,"Variable violating min constraint: 0.0 <= discharge.p_eps, has value: ");
  modelica_string tmp32;
  modelica_metatype tmpMeta33;
  static int tmp34 = 0;
  if(!tmp34)
  {
    tmp30 = GreaterEq((data->simulationInfo->realParameter[53] /* discharge.p_eps PARAM */),0.0);
    if(!tmp30)
    {
      tmp32 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[53] /* discharge.p_eps PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta33 = stringAppend(MMC_REFSTRINGLIT(tmp31),tmp32);
      {
        const char* assert_cond = "(discharge.p_eps >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",15,3,16,32,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta33));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",15,3,16,32,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta33));
        }
      }
      tmp34 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 796
type: ALGORITHM

  assert(discharge.D_i >= 0.0, "Variable violating min constraint: 0.0 <= discharge.D_i, has value: " + String(discharge.D_i, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_796(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,796};
  modelica_boolean tmp35;
  static const MMC_DEFSTRINGLIT(tmp36,68,"Variable violating min constraint: 0.0 <= discharge.D_i, has value: ");
  modelica_string tmp37;
  modelica_metatype tmpMeta38;
  static int tmp39 = 0;
  if(!tmp39)
  {
    tmp35 = GreaterEq((data->simulationInfo->realParameter[48] /* discharge.D_i PARAM */),0.0);
    if(!tmp35)
    {
      tmp37 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[48] /* discharge.D_i PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta38 = stringAppend(MMC_REFSTRINGLIT(tmp36),tmp37);
      {
        const char* assert_cond = "(discharge.D_i >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",11,3,12,32,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta38));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",11,3,12,32,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta38));
        }
      }
      tmp39 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 797
type: ALGORITHM

  assert(discharge.D_o >= 0.0, "Variable violating min constraint: 0.0 <= discharge.D_o, has value: " + String(discharge.D_o, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_797(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,797};
  modelica_boolean tmp40;
  static const MMC_DEFSTRINGLIT(tmp41,68,"Variable violating min constraint: 0.0 <= discharge.D_o, has value: ");
  modelica_string tmp42;
  modelica_metatype tmpMeta43;
  static int tmp44 = 0;
  if(!tmp44)
  {
    tmp40 = GreaterEq((data->simulationInfo->realParameter[49] /* discharge.D_o PARAM */),0.0);
    if(!tmp40)
    {
      tmp42 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[49] /* discharge.D_o PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta43 = stringAppend(MMC_REFSTRINGLIT(tmp41),tmp42);
      {
        const char* assert_cond = "(discharge.D_o >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",13,3,14,32,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta43));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",13,3,14,32,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta43));
        }
      }
      tmp44 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 798
type: ALGORITHM

  assert(turbine1.look_up_table.extrapolation >= Modelica.Blocks.Types.Extrapolation.HoldLastPoint and turbine1.look_up_table.extrapolation <= Modelica.Blocks.Types.Extrapolation.NoExtrapolation, "Variable violating min/max constraint: Modelica.Blocks.Types.Extrapolation.HoldLastPoint <= turbine1.look_up_table.extrapolation <= Modelica.Blocks.Types.Extrapolation.NoExtrapolation, has value: " + String(turbine1.look_up_table.extrapolation, "d"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_798(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,798};
  modelica_boolean tmp45;
  modelica_boolean tmp46;
  static const MMC_DEFSTRINGLIT(tmp47,196,"Variable violating min/max constraint: Modelica.Blocks.Types.Extrapolation.HoldLastPoint <= turbine1.look_up_table.extrapolation <= Modelica.Blocks.Types.Extrapolation.NoExtrapolation, has value: ");
  modelica_string tmp48;
  modelica_metatype tmpMeta49;
  static int tmp50 = 0;
  if(!tmp50)
  {
    tmp45 = GreaterEq((data->simulationInfo->integerParameter[8] /* turbine1.look_up_table.extrapolation PARAM */),1);
    tmp46 = LessEq((data->simulationInfo->integerParameter[8] /* turbine1.look_up_table.extrapolation PARAM */),4);
    if(!(tmp45 && tmp46))
    {
      tmp48 = modelica_integer_to_modelica_string_format((data->simulationInfo->integerParameter[8] /* turbine1.look_up_table.extrapolation PARAM */), (modelica_string) mmc_strings_len1[100]);
      tmpMeta49 = stringAppend(MMC_REFSTRINGLIT(tmp47),tmp48);
      {
        const char* assert_cond = "(turbine1.look_up_table.extrapolation >= Modelica.Blocks.Types.Extrapolation.HoldLastPoint and turbine1.look_up_table.extrapolation <= Modelica.Blocks.Types.Extrapolation.NoExtrapolation)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Tables.mo",282,5,284,61,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta49));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Tables.mo",282,5,284,61,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta49));
        }
      }
      tmp50 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 799
type: ALGORITHM

  assert(turbine1.look_up_table.smoothness >= Modelica.Blocks.Types.Smoothness.LinearSegments and turbine1.look_up_table.smoothness <= Modelica.Blocks.Types.Smoothness.ModifiedContinuousDerivative, "Variable violating min/max constraint: Modelica.Blocks.Types.Smoothness.LinearSegments <= turbine1.look_up_table.smoothness <= Modelica.Blocks.Types.Smoothness.ModifiedContinuousDerivative, has value: " + String(turbine1.look_up_table.smoothness, "d"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_799(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,799};
  modelica_boolean tmp51;
  modelica_boolean tmp52;
  static const MMC_DEFSTRINGLIT(tmp53,201,"Variable violating min/max constraint: Modelica.Blocks.Types.Smoothness.LinearSegments <= turbine1.look_up_table.smoothness <= Modelica.Blocks.Types.Smoothness.ModifiedContinuousDerivative, has value: ");
  modelica_string tmp54;
  modelica_metatype tmpMeta55;
  static int tmp56 = 0;
  if(!tmp56)
  {
    tmp51 = GreaterEq((data->simulationInfo->integerParameter[10] /* turbine1.look_up_table.smoothness PARAM */),1);
    tmp52 = LessEq((data->simulationInfo->integerParameter[10] /* turbine1.look_up_table.smoothness PARAM */),6);
    if(!(tmp51 && tmp52))
    {
      tmp54 = modelica_integer_to_modelica_string_format((data->simulationInfo->integerParameter[10] /* turbine1.look_up_table.smoothness PARAM */), (modelica_string) mmc_strings_len1[100]);
      tmpMeta55 = stringAppend(MMC_REFSTRINGLIT(tmp53),tmp54);
      {
        const char* assert_cond = "(turbine1.look_up_table.smoothness >= Modelica.Blocks.Types.Smoothness.LinearSegments and turbine1.look_up_table.smoothness <= Modelica.Blocks.Types.Smoothness.ModifiedContinuousDerivative)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Tables.mo",279,5,281,61,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta55));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Tables.mo",279,5,281,61,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta55));
        }
      }
      tmp56 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 800
type: ALGORITHM

  assert(turbine1.p >= 2, "Variable violating min constraint: 2 <= turbine1.p, has value: " + String(turbine1.p, "d"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_800(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,800};
  modelica_boolean tmp57;
  static const MMC_DEFSTRINGLIT(tmp58,63,"Variable violating min constraint: 2 <= turbine1.p, has value: ");
  modelica_string tmp59;
  modelica_metatype tmpMeta60;
  static int tmp61 = 0;
  if(!tmp61)
  {
    tmp57 = GreaterEq((data->simulationInfo->integerParameter[11] /* turbine1.p PARAM */),((modelica_integer) 2));
    if(!tmp57)
    {
      tmp59 = modelica_integer_to_modelica_string_format((data->simulationInfo->integerParameter[11] /* turbine1.p PARAM */), (modelica_string) mmc_strings_len1[100]);
      tmpMeta60 = stringAppend(MMC_REFSTRINGLIT(tmp58),tmp59);
      {
        const char* assert_cond = "(turbine1.p >= 2)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/ElectroMech/BaseClasses/Power2Torque.mo",13,3,30,59,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta60));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/ElectroMech/BaseClasses/Power2Torque.mo",13,3,30,59,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta60));
        }
      }
      tmp61 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 801
type: ALGORITHM

  assert(turbine1.torqueLimit.homotopyType >= Modelica.Blocks.Types.LimiterHomotopy.NoHomotopy and turbine1.torqueLimit.homotopyType <= Modelica.Blocks.Types.LimiterHomotopy.LowerLimit, "Variable violating min/max constraint: Modelica.Blocks.Types.LimiterHomotopy.NoHomotopy <= turbine1.torqueLimit.homotopyType <= Modelica.Blocks.Types.LimiterHomotopy.LowerLimit, has value: " + String(turbine1.torqueLimit.homotopyType, "d"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_801(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,801};
  modelica_boolean tmp62;
  modelica_boolean tmp63;
  static const MMC_DEFSTRINGLIT(tmp64,189,"Variable violating min/max constraint: Modelica.Blocks.Types.LimiterHomotopy.NoHomotopy <= turbine1.torqueLimit.homotopyType <= Modelica.Blocks.Types.LimiterHomotopy.LowerLimit, has value: ");
  modelica_string tmp65;
  modelica_metatype tmpMeta66;
  static int tmp67 = 0;
  if(!tmp67)
  {
    tmp62 = GreaterEq((data->simulationInfo->integerParameter[12] /* turbine1.torqueLimit.homotopyType PARAM */),1);
    tmp63 = LessEq((data->simulationInfo->integerParameter[12] /* turbine1.torqueLimit.homotopyType PARAM */),4);
    if(!(tmp62 && tmp63))
    {
      tmp65 = modelica_integer_to_modelica_string_format((data->simulationInfo->integerParameter[12] /* turbine1.torqueLimit.homotopyType PARAM */), (modelica_string) mmc_strings_len1[100]);
      tmpMeta66 = stringAppend(MMC_REFSTRINGLIT(tmp64),tmp65);
      {
        const char* assert_cond = "(turbine1.torqueLimit.homotopyType >= Modelica.Blocks.Types.LimiterHomotopy.NoHomotopy and turbine1.torqueLimit.homotopyType <= Modelica.Blocks.Types.LimiterHomotopy.LowerLimit)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Nonlinear.mo",12,9,13,69,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta66));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Nonlinear.mo",12,9,13,69,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta66));
        }
      }
      tmp67 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 802
type: ALGORITHM

  assert(turbine1.div0protect.homotopyType >= Modelica.Blocks.Types.LimiterHomotopy.NoHomotopy and turbine1.div0protect.homotopyType <= Modelica.Blocks.Types.LimiterHomotopy.LowerLimit, "Variable violating min/max constraint: Modelica.Blocks.Types.LimiterHomotopy.NoHomotopy <= turbine1.div0protect.homotopyType <= Modelica.Blocks.Types.LimiterHomotopy.LowerLimit, has value: " + String(turbine1.div0protect.homotopyType, "d"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_802(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,802};
  modelica_boolean tmp68;
  modelica_boolean tmp69;
  static const MMC_DEFSTRINGLIT(tmp70,189,"Variable violating min/max constraint: Modelica.Blocks.Types.LimiterHomotopy.NoHomotopy <= turbine1.div0protect.homotopyType <= Modelica.Blocks.Types.LimiterHomotopy.LowerLimit, has value: ");
  modelica_string tmp71;
  modelica_metatype tmpMeta72;
  static int tmp73 = 0;
  if(!tmp73)
  {
    tmp68 = GreaterEq((data->simulationInfo->integerParameter[5] /* turbine1.div0protect.homotopyType PARAM */),1);
    tmp69 = LessEq((data->simulationInfo->integerParameter[5] /* turbine1.div0protect.homotopyType PARAM */),4);
    if(!(tmp68 && tmp69))
    {
      tmp71 = modelica_integer_to_modelica_string_format((data->simulationInfo->integerParameter[5] /* turbine1.div0protect.homotopyType PARAM */), (modelica_string) mmc_strings_len1[100]);
      tmpMeta72 = stringAppend(MMC_REFSTRINGLIT(tmp70),tmp71);
      {
        const char* assert_cond = "(turbine1.div0protect.homotopyType >= Modelica.Blocks.Types.LimiterHomotopy.NoHomotopy and turbine1.div0protect.homotopyType <= Modelica.Blocks.Types.LimiterHomotopy.LowerLimit)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Nonlinear.mo",12,9,13,69,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta72));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Nonlinear.mo",12,9,13,69,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta72));
        }
      }
      tmp73 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 803
type: ALGORITHM

  assert(turbine1.friction.frictionParameters.wRef >= 1e-60, "Variable violating min constraint: 1e-60 <= turbine1.friction.frictionParameters.wRef, has value: " + String(turbine1.friction.frictionParameters.wRef, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_803(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,803};
  modelica_boolean tmp74;
  static const MMC_DEFSTRINGLIT(tmp75,98,"Variable violating min constraint: 1e-60 <= turbine1.friction.frictionParameters.wRef, has value: ");
  modelica_string tmp76;
  modelica_metatype tmpMeta77;
  static int tmp78 = 0;
  if(!tmp78)
  {
    tmp74 = GreaterEq((data->simulationInfo->realParameter[119] /* turbine1.friction.frictionParameters.wRef PARAM */),1e-60);
    if(!tmp74)
    {
      tmp76 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[119] /* turbine1.friction.frictionParameters.wRef PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta77 = stringAppend(MMC_REFSTRINGLIT(tmp75),tmp76);
      {
        const char* assert_cond = "(turbine1.friction.frictionParameters.wRef >= 1e-60)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Electrical/Machines/Losses/FrictionParameters.mo",6,3,8,56,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta77));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Electrical/Machines/Losses/FrictionParameters.mo",6,3,8,56,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta77));
        }
      }
      tmp78 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 804
type: ALGORITHM

  assert(turbine1.friction.frictionParameters.power_w >= 1e-60, "Variable violating min constraint: 1e-60 <= turbine1.friction.frictionParameters.power_w, has value: " + String(turbine1.friction.frictionParameters.power_w, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_804(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,804};
  modelica_boolean tmp79;
  static const MMC_DEFSTRINGLIT(tmp80,101,"Variable violating min constraint: 1e-60 <= turbine1.friction.frictionParameters.power_w, has value: ");
  modelica_string tmp81;
  modelica_metatype tmpMeta82;
  static int tmp83 = 0;
  if(!tmp83)
  {
    tmp79 = GreaterEq((data->simulationInfo->realParameter[115] /* turbine1.friction.frictionParameters.power_w PARAM */),1e-60);
    if(!tmp79)
    {
      tmp81 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[115] /* turbine1.friction.frictionParameters.power_w PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta82 = stringAppend(MMC_REFSTRINGLIT(tmp80),tmp81);
      {
        const char* assert_cond = "(turbine1.friction.frictionParameters.power_w >= 1e-60)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Electrical/Machines/Losses/FrictionParameters.mo",9,3,10,58,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta82));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Electrical/Machines/Losses/FrictionParameters.mo",9,3,10,58,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta82));
        }
      }
      tmp83 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 805
type: ALGORITHM

  assert(turbine1.friction.frictionParameters.PRef >= 0.0, "Variable violating min constraint: 0.0 <= turbine1.friction.frictionParameters.PRef, has value: " + String(turbine1.friction.frictionParameters.PRef, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_805(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,805};
  modelica_boolean tmp84;
  static const MMC_DEFSTRINGLIT(tmp85,96,"Variable violating min constraint: 0.0 <= turbine1.friction.frictionParameters.PRef, has value: ");
  modelica_string tmp86;
  modelica_metatype tmpMeta87;
  static int tmp88 = 0;
  if(!tmp88)
  {
    tmp84 = GreaterEq((data->simulationInfo->realParameter[113] /* turbine1.friction.frictionParameters.PRef PARAM */),0.0);
    if(!tmp84)
    {
      tmp86 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[113] /* turbine1.friction.frictionParameters.PRef PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta87 = stringAppend(MMC_REFSTRINGLIT(tmp85),tmp86);
      {
        const char* assert_cond = "(turbine1.friction.frictionParameters.PRef >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Electrical/Machines/Losses/FrictionParameters.mo",4,3,5,40,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta87));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Electrical/Machines/Losses/FrictionParameters.mo",4,3,5,40,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta87));
        }
      }
      tmp88 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 806
type: ALGORITHM

  assert(turbine1.inertia.stateSelect >= StateSelect.never and turbine1.inertia.stateSelect <= StateSelect.always, "Variable violating min/max constraint: StateSelect.never <= turbine1.inertia.stateSelect <= StateSelect.always, has value: " + String(turbine1.inertia.stateSelect, "d"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_806(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,806};
  modelica_boolean tmp89;
  modelica_boolean tmp90;
  static const MMC_DEFSTRINGLIT(tmp91,123,"Variable violating min/max constraint: StateSelect.never <= turbine1.inertia.stateSelect <= StateSelect.always, has value: ");
  modelica_string tmp92;
  modelica_metatype tmpMeta93;
  static int tmp94 = 0;
  if(!tmp94)
  {
    tmp89 = GreaterEq((data->simulationInfo->integerParameter[6] /* turbine1.inertia.stateSelect PARAM */),1);
    tmp90 = LessEq((data->simulationInfo->integerParameter[6] /* turbine1.inertia.stateSelect PARAM */),5);
    if(!(tmp89 && tmp90))
    {
      tmp92 = modelica_integer_to_modelica_string_format((data->simulationInfo->integerParameter[6] /* turbine1.inertia.stateSelect PARAM */), (modelica_string) mmc_strings_len1[100]);
      tmpMeta93 = stringAppend(MMC_REFSTRINGLIT(tmp91),tmp92);
      {
        const char* assert_cond = "(turbine1.inertia.stateSelect >= StateSelect.never and turbine1.inertia.stateSelect <= StateSelect.always)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Mechanics/Rotational/Components/Inertia.mo",5,3,7,57,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta93));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Mechanics/Rotational/Components/Inertia.mo",5,3,7,57,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta93));
        }
      }
      tmp94 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 807
type: ALGORITHM

  assert(turbine1.inertia.J >= 0.0, "Variable violating min constraint: 0.0 <= turbine1.inertia.J, has value: " + String(turbine1.inertia.J, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_807(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,807};
  modelica_boolean tmp95;
  static const MMC_DEFSTRINGLIT(tmp96,73,"Variable violating min constraint: 0.0 <= turbine1.inertia.J, has value: ");
  modelica_string tmp97;
  modelica_metatype tmpMeta98;
  static int tmp99 = 0;
  if(!tmp99)
  {
    tmp95 = GreaterEq((data->simulationInfo->realParameter[121] /* turbine1.inertia.J PARAM */),0.0);
    if(!tmp95)
    {
      tmp97 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[121] /* turbine1.inertia.J PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta98 = stringAppend(MMC_REFSTRINGLIT(tmp96),tmp97);
      {
        const char* assert_cond = "(turbine1.inertia.J >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Mechanics/Rotational/Components/Inertia.mo",4,3,4,61,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta98));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Mechanics/Rotational/Components/Inertia.mo",4,3,4,61,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta98));
        }
      }
      tmp99 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 808
type: ALGORITHM

  assert(turbine1.eta_h >= 0.0, "Variable violating min constraint: 0.0 <= turbine1.eta_h, has value: " + String(turbine1.eta_h, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_808(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,808};
  modelica_boolean tmp100;
  static const MMC_DEFSTRINGLIT(tmp101,69,"Variable violating min constraint: 0.0 <= turbine1.eta_h, has value: ");
  modelica_string tmp102;
  modelica_metatype tmpMeta103;
  static int tmp104 = 0;
  if(!tmp104)
  {
    tmp100 = GreaterEq((data->simulationInfo->realParameter[110] /* turbine1.eta_h PARAM */),0.0);
    if(!tmp100)
    {
      tmp102 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[110] /* turbine1.eta_h PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta103 = stringAppend(MMC_REFSTRINGLIT(tmp101),tmp102);
      {
        const char* assert_cond = "(turbine1.eta_h >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/ElectroMech/Turbines/Turbine.mo",20,3,21,77,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta103));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/ElectroMech/Turbines/Turbine.mo",20,3,21,77,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta103));
        }
      }
      tmp104 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 809
type: ALGORITHM

  assert(turbine1.H_n >= 0.0, "Variable violating min constraint: 0.0 <= turbine1.H_n, has value: " + String(turbine1.H_n, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_809(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,809};
  modelica_boolean tmp105;
  static const MMC_DEFSTRINGLIT(tmp106,67,"Variable violating min constraint: 0.0 <= turbine1.H_n, has value: ");
  modelica_string tmp107;
  modelica_metatype tmpMeta108;
  static int tmp109 = 0;
  if(!tmp109)
  {
    tmp105 = GreaterEq((data->simulationInfo->realParameter[103] /* turbine1.H_n PARAM */),0.0);
    if(!tmp105)
    {
      tmp107 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[103] /* turbine1.H_n PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta108 = stringAppend(MMC_REFSTRINGLIT(tmp106),tmp107);
      {
        const char* assert_cond = "(turbine1.H_n >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/ElectroMech/Turbines/Turbine.mo",11,3,12,90,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta108));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/ElectroMech/Turbines/Turbine.mo",11,3,12,90,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta108));
        }
      }
      tmp109 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 810
type: ALGORITHM

  assert(reservoir.h_0 >= 0.0, "Variable violating min constraint: 0.0 <= reservoir.h_0, has value: " + String(reservoir.h_0, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_810(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,810};
  modelica_boolean tmp110;
  static const MMC_DEFSTRINGLIT(tmp111,68,"Variable violating min constraint: 0.0 <= reservoir.h_0, has value: ");
  modelica_string tmp112;
  modelica_metatype tmpMeta113;
  static int tmp114 = 0;
  if(!tmp114)
  {
    tmp110 = GreaterEq((data->simulationInfo->realParameter[77] /* reservoir.h_0 PARAM */),0.0);
    if(!tmp110)
    {
      tmp112 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[77] /* reservoir.h_0 PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta113 = stringAppend(MMC_REFSTRINGLIT(tmp111),tmp112);
      {
        const char* assert_cond = "(reservoir.h_0 >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Reservoir.mo",12,3,13,60,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta113));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Reservoir.mo",12,3,13,60,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta113));
        }
      }
      tmp114 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 811
type: ALGORITHM

  assert(intake.p_eps >= 0.0, "Variable violating min constraint: 0.0 <= intake.p_eps, has value: " + String(intake.p_eps, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_811(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,811};
  modelica_boolean tmp115;
  static const MMC_DEFSTRINGLIT(tmp116,67,"Variable violating min constraint: 0.0 <= intake.p_eps, has value: ");
  modelica_string tmp117;
  modelica_metatype tmpMeta118;
  static int tmp119 = 0;
  if(!tmp119)
  {
    tmp115 = GreaterEq((data->simulationInfo->realParameter[64] /* intake.p_eps PARAM */),0.0);
    if(!tmp115)
    {
      tmp117 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[64] /* intake.p_eps PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta118 = stringAppend(MMC_REFSTRINGLIT(tmp116),tmp117);
      {
        const char* assert_cond = "(intake.p_eps >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",15,3,16,32,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta118));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",15,3,16,32,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta118));
        }
      }
      tmp119 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 812
type: ALGORITHM

  assert(intake.D_i >= 0.0, "Variable violating min constraint: 0.0 <= intake.D_i, has value: " + String(intake.D_i, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_812(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,812};
  modelica_boolean tmp120;
  static const MMC_DEFSTRINGLIT(tmp121,65,"Variable violating min constraint: 0.0 <= intake.D_i, has value: ");
  modelica_string tmp122;
  modelica_metatype tmpMeta123;
  static int tmp124 = 0;
  if(!tmp124)
  {
    tmp120 = GreaterEq((data->simulationInfo->realParameter[59] /* intake.D_i PARAM */),0.0);
    if(!tmp120)
    {
      tmp122 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[59] /* intake.D_i PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta123 = stringAppend(MMC_REFSTRINGLIT(tmp121),tmp122);
      {
        const char* assert_cond = "(intake.D_i >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",11,3,12,32,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta123));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",11,3,12,32,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta123));
        }
      }
      tmp124 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 813
type: ALGORITHM

  assert(intake.D_o >= 0.0, "Variable violating min constraint: 0.0 <= intake.D_o, has value: " + String(intake.D_o, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_813(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,813};
  modelica_boolean tmp125;
  static const MMC_DEFSTRINGLIT(tmp126,65,"Variable violating min constraint: 0.0 <= intake.D_o, has value: ");
  modelica_string tmp127;
  modelica_metatype tmpMeta128;
  static int tmp129 = 0;
  if(!tmp129)
  {
    tmp125 = GreaterEq((data->simulationInfo->realParameter[60] /* intake.D_o PARAM */),0.0);
    if(!tmp125)
    {
      tmp127 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[60] /* intake.D_o PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta128 = stringAppend(MMC_REFSTRINGLIT(tmp126),tmp127);
      {
        const char* assert_cond = "(intake.D_o >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",13,3,14,32,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta128));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",13,3,14,32,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta128));
        }
      }
      tmp129 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 814
type: ALGORITHM

  assert(surgeTank.T_ac >= 0.0, "Variable violating min constraint: 0.0 <= surgeTank.T_ac, has value: " + String(surgeTank.T_ac, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_814(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,814};
  modelica_boolean tmp130;
  static const MMC_DEFSTRINGLIT(tmp131,69,"Variable violating min constraint: 0.0 <= surgeTank.T_ac, has value: ");
  modelica_string tmp132;
  modelica_metatype tmpMeta133;
  static int tmp134 = 0;
  if(!tmp134)
  {
    tmp130 = GreaterEq((data->simulationInfo->realParameter[88] /* surgeTank.T_ac PARAM */),0.0);
    if(!tmp130)
    {
      tmp132 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[88] /* surgeTank.T_ac PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta133 = stringAppend(MMC_REFSTRINGLIT(tmp131),tmp132);
      {
        const char* assert_cond = "(surgeTank.T_ac >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",34,3,35,112,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta133));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",34,3,35,112,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta133));
        }
      }
      tmp134 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 815
type: ALGORITHM

  assert(surgeTank.h_0 >= 0.0, "Variable violating min constraint: 0.0 <= surgeTank.h_0, has value: " + String(surgeTank.h_0, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_815(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,815};
  modelica_boolean tmp135;
  static const MMC_DEFSTRINGLIT(tmp136,68,"Variable violating min constraint: 0.0 <= surgeTank.h_0, has value: ");
  modelica_string tmp137;
  modelica_metatype tmpMeta138;
  static int tmp139 = 0;
  if(!tmp139)
  {
    tmp135 = GreaterEq((data->simulationInfo->realParameter[90] /* surgeTank.h_0 PARAM */),0.0);
    if(!tmp135)
    {
      tmp137 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[90] /* surgeTank.h_0 PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta138 = stringAppend(MMC_REFSTRINGLIT(tmp136),tmp137);
      {
        const char* assert_cond = "(surgeTank.h_0 >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",30,3,31,38,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta138));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",30,3,31,38,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta138));
        }
      }
      tmp139 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 816
type: ALGORITHM

  assert(surgeTank.D_t >= 0.0, "Variable violating min constraint: 0.0 <= surgeTank.D_t, has value: " + String(surgeTank.D_t, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_816(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,816};
  modelica_boolean tmp140;
  static const MMC_DEFSTRINGLIT(tmp141,68,"Variable violating min constraint: 0.0 <= surgeTank.D_t, has value: ");
  modelica_string tmp142;
  modelica_metatype tmpMeta143;
  static int tmp144 = 0;
  if(!tmp144)
  {
    tmp140 = GreaterEq((data->simulationInfo->realParameter[84] /* surgeTank.D_t PARAM */),0.0);
    if(!tmp140)
    {
      tmp142 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[84] /* surgeTank.D_t PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta143 = stringAppend(MMC_REFSTRINGLIT(tmp141),tmp142);
      {
        const char* assert_cond = "(surgeTank.D_t >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",20,3,21,96,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta143));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",20,3,21,96,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta143));
        }
      }
      tmp144 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 817
type: ALGORITHM

  assert(surgeTank.D_so >= 0.0, "Variable violating min constraint: 0.0 <= surgeTank.D_so, has value: " + String(surgeTank.D_so, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_817(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,817};
  modelica_boolean tmp145;
  static const MMC_DEFSTRINGLIT(tmp146,69,"Variable violating min constraint: 0.0 <= surgeTank.D_so, has value: ");
  modelica_string tmp147;
  modelica_metatype tmpMeta148;
  static int tmp149 = 0;
  if(!tmp149)
  {
    tmp145 = GreaterEq((data->simulationInfo->realParameter[83] /* surgeTank.D_so PARAM */),0.0);
    if(!tmp145)
    {
      tmp147 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[83] /* surgeTank.D_so PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta148 = stringAppend(MMC_REFSTRINGLIT(tmp146),tmp147);
      {
        const char* assert_cond = "(surgeTank.D_so >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",18,3,19,95,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta148));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",18,3,19,95,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta148));
        }
      }
      tmp149 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 818
type: ALGORITHM

  assert(surgeTank.p_eps >= 0.0, "Variable violating min constraint: 0.0 <= surgeTank.p_eps, has value: " + String(surgeTank.p_eps, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_818(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,818};
  modelica_boolean tmp150;
  static const MMC_DEFSTRINGLIT(tmp151,70,"Variable violating min constraint: 0.0 <= surgeTank.p_eps, has value: ");
  modelica_string tmp152;
  modelica_metatype tmpMeta153;
  static int tmp154 = 0;
  if(!tmp154)
  {
    tmp150 = GreaterEq((data->simulationInfo->realParameter[92] /* surgeTank.p_eps PARAM */),0.0);
    if(!tmp150)
    {
      tmp152 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[92] /* surgeTank.p_eps PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta153 = stringAppend(MMC_REFSTRINGLIT(tmp151),tmp152);
      {
        const char* assert_cond = "(surgeTank.p_eps >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",16,3,17,32,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta153));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",16,3,17,32,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta153));
        }
      }
      tmp154 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 819
type: ALGORITHM

  assert(surgeTank.D >= 0.0, "Variable violating min constraint: 0.0 <= surgeTank.D, has value: " + String(surgeTank.D, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_819(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,819};
  modelica_boolean tmp155;
  static const MMC_DEFSTRINGLIT(tmp156,66,"Variable violating min constraint: 0.0 <= surgeTank.D, has value: ");
  modelica_string tmp157;
  modelica_metatype tmpMeta158;
  static int tmp159 = 0;
  if(!tmp159)
  {
    tmp155 = GreaterEq((data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */),0.0);
    if(!tmp155)
    {
      tmp157 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta158 = stringAppend(MMC_REFSTRINGLIT(tmp156),tmp157);
      {
        const char* assert_cond = "(surgeTank.D >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",14,3,15,32,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta158));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",14,3,15,32,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta158));
        }
      }
      tmp159 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 820
type: ALGORITHM

  assert(surgeTank.H >= 0.0, "Variable violating min constraint: 0.0 <= surgeTank.H, has value: " + String(surgeTank.H, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_820(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,820};
  modelica_boolean tmp160;
  static const MMC_DEFSTRINGLIT(tmp161,66,"Variable violating min constraint: 0.0 <= surgeTank.H, has value: ");
  modelica_string tmp162;
  modelica_metatype tmpMeta163;
  static int tmp164 = 0;
  if(!tmp164)
  {
    tmp160 = GreaterEq((data->simulationInfo->realParameter[85] /* surgeTank.H PARAM */),0.0);
    if(!tmp160)
    {
      tmp162 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[85] /* surgeTank.H PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta163 = stringAppend(MMC_REFSTRINGLIT(tmp161),tmp162);
      {
        const char* assert_cond = "(surgeTank.H >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",10,3,11,32,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta163));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",10,3,11,32,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta163));
        }
      }
      tmp164 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 821
type: ALGORITHM

  assert(surgeTank.SurgeTankType >= OpenHPL.Types.SurgeTank.STSimple and surgeTank.SurgeTankType <= OpenHPL.Types.SurgeTank.STThrottleValve, "Variable violating min/max constraint: OpenHPL.Types.SurgeTank.STSimple <= surgeTank.SurgeTankType <= OpenHPL.Types.SurgeTank.STThrottleValve, has value: " + String(surgeTank.SurgeTankType, "d"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_821(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,821};
  modelica_boolean tmp165;
  modelica_boolean tmp166;
  static const MMC_DEFSTRINGLIT(tmp167,154,"Variable violating min/max constraint: OpenHPL.Types.SurgeTank.STSimple <= surgeTank.SurgeTankType <= OpenHPL.Types.SurgeTank.STThrottleValve, has value: ");
  modelica_string tmp168;
  modelica_metatype tmpMeta169;
  static int tmp170 = 0;
  if(!tmp170)
  {
    tmp165 = GreaterEq((data->simulationInfo->integerParameter[4] /* surgeTank.SurgeTankType PARAM */),1);
    tmp166 = LessEq((data->simulationInfo->integerParameter[4] /* surgeTank.SurgeTankType PARAM */),4);
    if(!(tmp165 && tmp166))
    {
      tmp168 = modelica_integer_to_modelica_string_format((data->simulationInfo->integerParameter[4] /* surgeTank.SurgeTankType PARAM */), (modelica_string) mmc_strings_len1[100]);
      tmpMeta169 = stringAppend(MMC_REFSTRINGLIT(tmp167),tmp168);
      {
        const char* assert_cond = "(surgeTank.SurgeTankType >= OpenHPL.Types.SurgeTank.STSimple and surgeTank.SurgeTankType <= OpenHPL.Types.SurgeTank.STThrottleValve)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",7,3,8,40,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta169));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",7,3,8,40,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta169));
        }
      }
      tmp170 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 822
type: ALGORITHM

  assert(penstock.p_eps >= 0.0, "Variable violating min constraint: 0.0 <= penstock.p_eps, has value: " + String(penstock.p_eps, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_822(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,822};
  modelica_boolean tmp171;
  static const MMC_DEFSTRINGLIT(tmp172,69,"Variable violating min constraint: 0.0 <= penstock.p_eps, has value: ");
  modelica_string tmp173;
  modelica_metatype tmpMeta174;
  static int tmp175 = 0;
  if(!tmp175)
  {
    tmp171 = GreaterEq((data->simulationInfo->realParameter[71] /* penstock.p_eps PARAM */),0.0);
    if(!tmp171)
    {
      tmp173 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[71] /* penstock.p_eps PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta174 = stringAppend(MMC_REFSTRINGLIT(tmp172),tmp173);
      {
        const char* assert_cond = "(penstock.p_eps >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",15,3,16,32,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta174));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",15,3,16,32,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta174));
        }
      }
      tmp175 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 823
type: ALGORITHM

  assert(penstock.D_o >= 0.0, "Variable violating min constraint: 0.0 <= penstock.D_o, has value: " + String(penstock.D_o, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_823(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,823};
  modelica_boolean tmp176;
  static const MMC_DEFSTRINGLIT(tmp177,67,"Variable violating min constraint: 0.0 <= penstock.D_o, has value: ");
  modelica_string tmp178;
  modelica_metatype tmpMeta179;
  static int tmp180 = 0;
  if(!tmp180)
  {
    tmp176 = GreaterEq((data->simulationInfo->realParameter[67] /* penstock.D_o PARAM */),0.0);
    if(!tmp176)
    {
      tmp178 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[67] /* penstock.D_o PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta179 = stringAppend(MMC_REFSTRINGLIT(tmp177),tmp178);
      {
        const char* assert_cond = "(penstock.D_o >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",13,3,14,32,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta179));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",13,3,14,32,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta179));
        }
      }
      tmp180 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 824
type: ALGORITHM

  assert(penstock.D_i >= 0.0, "Variable violating min constraint: 0.0 <= penstock.D_i, has value: " + String(penstock.D_i, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_824(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,824};
  modelica_boolean tmp181;
  static const MMC_DEFSTRINGLIT(tmp182,67,"Variable violating min constraint: 0.0 <= penstock.D_i, has value: ");
  modelica_string tmp183;
  modelica_metatype tmpMeta184;
  static int tmp185 = 0;
  if(!tmp185)
  {
    tmp181 = GreaterEq((data->simulationInfo->realParameter[66] /* penstock.D_i PARAM */),0.0);
    if(!tmp181)
    {
      tmp183 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[66] /* penstock.D_i PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta184 = stringAppend(MMC_REFSTRINGLIT(tmp182),tmp183);
      {
        const char* assert_cond = "(penstock.D_i >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",11,3,12,32,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta184));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",11,3,12,32,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta184));
        }
      }
      tmp185 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 825
type: ALGORITHM

  assert(tail.h_0 >= 0.0, "Variable violating min constraint: 0.0 <= tail.h_0, has value: " + String(tail.h_0, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_825(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,825};
  modelica_boolean tmp186;
  static const MMC_DEFSTRINGLIT(tmp187,63,"Variable violating min constraint: 0.0 <= tail.h_0, has value: ");
  modelica_string tmp188;
  modelica_metatype tmpMeta189;
  static int tmp190 = 0;
  if(!tmp190)
  {
    tmp186 = GreaterEq((data->simulationInfo->realParameter[99] /* tail.h_0 PARAM */),0.0);
    if(!tmp186)
    {
      tmp188 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[99] /* tail.h_0 PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta189 = stringAppend(MMC_REFSTRINGLIT(tmp187),tmp188);
      {
        const char* assert_cond = "(tail.h_0 >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Reservoir.mo",12,3,13,60,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta189));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Reservoir.mo",12,3,13,60,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta189));
        }
      }
      tmp190 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 826
type: ALGORITHM

  assert(data.T_0 >= 0.0, "Variable violating min constraint: 0.0 <= data.T_0, has value: " + String(data.T_0, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_826(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,826};
  modelica_boolean tmp191;
  static const MMC_DEFSTRINGLIT(tmp192,63,"Variable violating min constraint: 0.0 <= data.T_0, has value: ");
  modelica_string tmp193;
  modelica_metatype tmpMeta194;
  static int tmp195 = 0;
  if(!tmp195)
  {
    tmp191 = GreaterEq((data->simulationInfo->realParameter[36] /* data.T_0 PARAM */),0.0);
    if(!tmp191)
    {
      tmp193 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[36] /* data.T_0 PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta194 = stringAppend(MMC_REFSTRINGLIT(tmp192),tmp193);
      {
        const char* assert_cond = "(data.T_0 >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Data.mo",31,3,32,93,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta194));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Data.mo",31,3,32,93,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta194));
        }
      }
      tmp195 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 827
type: ALGORITHM

  assert(data.rho >= 0.0, "Variable violating min constraint: 0.0 <= data.rho, has value: " + String(data.rho, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_827(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,827};
  modelica_boolean tmp196;
  static const MMC_DEFSTRINGLIT(tmp197,63,"Variable violating min constraint: 0.0 <= data.rho, has value: ");
  modelica_string tmp198;
  modelica_metatype tmpMeta199;
  static int tmp200 = 0;
  if(!tmp200)
  {
    tmp196 = GreaterEq((data->simulationInfo->realParameter[47] /* data.rho PARAM */),0.0);
    if(!tmp196)
    {
      tmp198 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[47] /* data.rho PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta199 = stringAppend(MMC_REFSTRINGLIT(tmp197),tmp198);
      {
        const char* assert_cond = "(data.rho >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Data.mo",12,3,13,55,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta199));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Data.mo",12,3,13,55,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta199));
        }
      }
      tmp200 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 828
type: ALGORITHM

  assert(data.mu >= 0.0, "Variable violating min constraint: 0.0 <= data.mu, has value: " + String(data.mu, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_828(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,828};
  modelica_boolean tmp201;
  static const MMC_DEFSTRINGLIT(tmp202,62,"Variable violating min constraint: 0.0 <= data.mu, has value: ");
  modelica_string tmp203;
  modelica_metatype tmpMeta204;
  static int tmp205 = 0;
  if(!tmp205)
  {
    tmp201 = GreaterEq((data->simulationInfo->realParameter[44] /* data.mu PARAM */),0.0);
    if(!tmp201)
    {
      tmp203 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[44] /* data.mu PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta204 = stringAppend(MMC_REFSTRINGLIT(tmp202),tmp203);
      {
        const char* assert_cond = "(data.mu >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Data.mo",14,3,15,55,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta204));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Data.mo",14,3,15,55,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta204));
        }
      }
      tmp205 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 829
type: ALGORITHM

  assert(data.M_a >= 0.0, "Variable violating min constraint: 0.0 <= data.M_a, has value: " + String(data.M_a, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_829(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,829};
  modelica_boolean tmp206;
  static const MMC_DEFSTRINGLIT(tmp207,63,"Variable violating min constraint: 0.0 <= data.M_a, has value: ");
  modelica_string tmp208;
  modelica_metatype tmpMeta209;
  static int tmp210 = 0;
  if(!tmp210)
  {
    tmp206 = GreaterEq((data->simulationInfo->realParameter[35] /* data.M_a PARAM */),0.0);
    if(!tmp206)
    {
      tmp208 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[35] /* data.M_a PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta209 = stringAppend(MMC_REFSTRINGLIT(tmp207),tmp208);
      {
        const char* assert_cond = "(data.M_a >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Data.mo",10,3,11,45,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta209));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Data.mo",10,3,11,45,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta209));
        }
      }
      tmp210 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 830
type: ALGORITHM

  assert(control.duration >= 0.0, "Variable violating min constraint: 0.0 <= control.duration, has value: " + String(control.duration, "g"));
*/
OMC_DISABLE_OPT
static void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_830(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,830};
  modelica_boolean tmp211;
  static const MMC_DEFSTRINGLIT(tmp212,71,"Variable violating min constraint: 0.0 <= control.duration, has value: ");
  modelica_string tmp213;
  modelica_metatype tmpMeta214;
  static int tmp215 = 0;
  if(!tmp215)
  {
    tmp211 = GreaterEq((data->simulationInfo->realParameter[31] /* control.duration PARAM */),0.0);
    if(!tmp211)
    {
      tmp213 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[31] /* control.duration PARAM */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta214 = stringAppend(MMC_REFSTRINGLIT(tmp212),tmp213);
      {
        const char* assert_cond = "(control.duration >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Sources.mo",247,5,248,46,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta214));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Sources.mo",247,5,248,46,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta214));
        }
      }
      tmp215 = 1;
    }
  }
  TRACE_POP
}
OMC_DISABLE_OPT
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_updateBoundParameters_0(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_649(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_650(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_651(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_652(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_653(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_654(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_655(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_656(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_657(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_658(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_659(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_660(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_661(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_662(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_663(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_664(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_665(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_666(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_667(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_668(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_669(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_670(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_671(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_672(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_673(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_674(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_678(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_679(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_680(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_681(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_682(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_683(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_684(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_685(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_686(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_688(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_689(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_690(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_691(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_698(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_699(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_701(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_706(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_707(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_708(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_709(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_715(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_716(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_721(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_729(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_731(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_732(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_733(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_735(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_737(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_739(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_743(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_43(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_42(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_41(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_38(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_37(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_36(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_35(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_32(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_30(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_29(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_28(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_27(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_26(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_23(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_22(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_206(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_205(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_204(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_203(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_202(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_201(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_200(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_199(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_3(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_198(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_21(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_191(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_197(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_20(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_196(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_195(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_24(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_31(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_33(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_39(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_40(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_194(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_193(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_192(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_34(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_25(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_6(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_5(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_4(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_2(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_1(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_790(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_791(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_792(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_793(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_794(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_795(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_796(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_797(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_798(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_799(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_800(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_801(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_802(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_803(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_804(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_805(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_806(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_807(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_808(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_809(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_810(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_811(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_812(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_813(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_814(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_815(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_816(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_817(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_818(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_819(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_820(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_821(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_822(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_823(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_824(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_825(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_826(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_827(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_828(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_829(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_830(data, threadData);
  TRACE_POP
}
OMC_DISABLE_OPT
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_updateBoundParameters(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  (data->simulationInfo->integerParameter[9] /* turbine1.look_up_table.n PARAM */) = ((modelica_integer) 1);
  data->modelData->integerParameterData[9].time_unvarying = 1;
  (data->localData[0]->realVars[168] /* turbine1.fixed.flange.tau variable */) = -0.0;
  data->modelData->realVarsData[168].time_unvarying = 1;
  (data->localData[0]->realVars[170] /* turbine1.friction.flange.tau variable */) = -0.0;
  data->modelData->realVarsData[170].time_unvarying = 1;
  (data->localData[0]->realVars[175] /* turbine1.frictionLoss.flange_a.tau variable */) = -0.0;
  data->modelData->realVarsData[175].time_unvarying = 1;
  (data->simulationInfo->realParameter[113] /* turbine1.friction.frictionParameters.PRef PARAM */) = 0.0;
  data->modelData->realParameterData[113].time_unvarying = 1;
  (data->simulationInfo->realParameter[114] /* turbine1.friction.frictionParameters.linear PARAM */) = 0.001;
  data->modelData->realParameterData[114].time_unvarying = 1;
  (data->simulationInfo->realParameter[116] /* turbine1.friction.frictionParameters.tauLinear PARAM */) = 0.0;
  data->modelData->realParameterData[116].time_unvarying = 1;
  (data->simulationInfo->realParameter[117] /* turbine1.friction.frictionParameters.tauRef PARAM */) = 0.0;
  data->modelData->realParameterData[117].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[1] /* data.TempUse PARAM */) = 0;
  data->modelData->booleanParameterData[1].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[2] /* discharge.SteadyState PARAM */) = 0;
  data->modelData->booleanParameterData[2].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[4] /* intake.SteadyState PARAM */) = 0;
  data->modelData->booleanParameterData[4].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[6] /* penstock.SteadyState PARAM */) = 0;
  data->modelData->booleanParameterData[6].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[8] /* reservoir.useInflow PARAM */) = 0;
  data->modelData->booleanParameterData[8].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[9] /* reservoir.useLevel PARAM */) = 1;
  data->modelData->booleanParameterData[9].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[10] /* surgeTank.SteadyState PARAM */) = 0;
  data->modelData->booleanParameterData[10].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[11] /* tail.useInflow PARAM */) = 0;
  data->modelData->booleanParameterData[11].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[12] /* tail.useLevel PARAM */) = 1;
  data->modelData->booleanParameterData[12].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[13] /* turbine1.ConstEfficiency PARAM */) = 1;
  data->modelData->booleanParameterData[13].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[16] /* turbine1.div0protect.strict PARAM */) = 0;
  data->modelData->booleanParameterData[16].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[17] /* turbine1.enable_P_out PARAM */) = 1;
  data->modelData->booleanParameterData[17].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[18] /* turbine1.enable_f PARAM */) = 0;
  data->modelData->booleanParameterData[18].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[19] /* turbine1.enable_nomSpeed PARAM */) = 0;
  data->modelData->booleanParameterData[19].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[20] /* turbine1.enable_w PARAM */) = 0;
  data->modelData->booleanParameterData[20].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[21] /* turbine1.enable_w_in PARAM */) = 1;
  data->modelData->booleanParameterData[21].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[22] /* turbine1.friction.useHeatPort PARAM */) = 0;
  data->modelData->booleanParameterData[22].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[23] /* turbine1.look_up_table.tableOnFile PARAM */) = 0;
  data->modelData->booleanParameterData[23].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[24] /* turbine1.look_up_table.verboseExtrapolation PARAM */) = 0;
  data->modelData->booleanParameterData[24].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[26] /* turbine1.setSpeed.exact PARAM */) = 0;
  data->modelData->booleanParameterData[26].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[27] /* turbine1.setSpeed.useSupport PARAM */) = 0;
  data->modelData->booleanParameterData[27].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[28] /* turbine1.toSysSpeed.useSupport PARAM */) = 0;
  data->modelData->booleanParameterData[28].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[29] /* turbine1.torque.useSupport PARAM */) = 0;
  data->modelData->booleanParameterData[29].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[30] /* turbine1.torqueLimit.strict PARAM */) = 0;
  data->modelData->booleanParameterData[30].time_unvarying = 1;
  (data->simulationInfo->integerParameter[4] /* surgeTank.SurgeTankType PARAM */) = 1;
  data->modelData->integerParameterData[4].time_unvarying = 1;
  (data->simulationInfo->integerParameter[5] /* turbine1.div0protect.homotopyType PARAM */) = 2;
  data->modelData->integerParameterData[5].time_unvarying = 1;
  (data->simulationInfo->integerParameter[6] /* turbine1.inertia.stateSelect PARAM */) = 3;
  data->modelData->integerParameterData[6].time_unvarying = 1;
  (data->simulationInfo->integerParameter[8] /* turbine1.look_up_table.extrapolation PARAM */) = 2;
  data->modelData->integerParameterData[8].time_unvarying = 1;
  (data->simulationInfo->integerParameter[10] /* turbine1.look_up_table.smoothness PARAM */) = 1;
  data->modelData->integerParameterData[10].time_unvarying = 1;
  (data->simulationInfo->integerParameter[12] /* turbine1.torqueLimit.homotopyType PARAM */) = 2;
  data->modelData->integerParameterData[12].time_unvarying = 1;
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_updateBoundParameters_0(data, threadData);
  TRACE_POP
  return 0;
}

#if defined(__cplusplus)
}
#endif

