/* Inline equation file is empty */
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_symbolicInlineSystem(DATA *data, threadData_t *threadData){
  return -1;
}
#ifdef __cplusplus
}
#endif
