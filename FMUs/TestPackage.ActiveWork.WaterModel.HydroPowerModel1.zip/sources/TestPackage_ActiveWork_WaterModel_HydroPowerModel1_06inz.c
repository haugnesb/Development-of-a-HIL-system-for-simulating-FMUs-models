/* Initialization */
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_model.h"
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_11mix.h"
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionInitialEquations_0(DATA *data, threadData_t *threadData);

/*
equation index: 1
type: SIMPLE_ASSIGN
turbine1.torque.phi_support = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_1(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,1};
  (data->localData[0]->realVars[190] /* turbine1.torque.phi_support variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 2
type: SIMPLE_ASSIGN
surgeTank.A_t = 0.7853981633974483 * surgeTank.D_t ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_2(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,2};
  modelica_real tmp0;
  tmp0 = (data->simulationInfo->realParameter[84] /* surgeTank.D_t PARAM */);
  (data->localData[0]->realVars[139] /* surgeTank.A_t variable */) = (0.7853981633974483) * ((tmp0 * tmp0));
  TRACE_POP
}

/*
equation index: 3
type: SIMPLE_ASSIGN
tail.A = constant2.k * (tail.W + constant2.k * tan(tail.alpha))
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_3(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,3};
  (data->localData[0]->realVars[154] /* tail.A variable */) = ((data->simulationInfo->realParameter[25] /* constant2.k PARAM */)) * ((data->simulationInfo->realParameter[95] /* tail.W PARAM */) + ((data->simulationInfo->realParameter[25] /* constant2.k PARAM */)) * (tan((data->simulationInfo->realParameter[96] /* tail.alpha PARAM */))));
  TRACE_POP
}

/*
equation index: 4
type: SIMPLE_ASSIGN
tail.m = data.rho * tail.A * tail.L
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_4(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,4};
  (data->localData[0]->realVars[159] /* tail.m variable */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[154] /* tail.A variable */)) * ((data->simulationInfo->realParameter[94] /* tail.L PARAM */)));
  TRACE_POP
}

/*
equation index: 5
type: SIMPLE_ASSIGN
tail.v = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_5(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,5};
  (data->localData[0]->realVars[161] /* tail.v variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 6
type: SIMPLE_ASSIGN
tail.M = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_6(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,6};
  (data->localData[0]->realVars[156] /* tail.M variable */) = 0.0;
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_467(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_462(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_460(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_459(DATA *data, threadData_t *threadData);


/*
equation index: 11
type: SIMPLE_ASSIGN
$DER.add.y = add.k1 * $DER.add.u1 + add.k2 * $DER.step.y
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_11(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,11};
  (data->localData[0]->realVars[26] /* der(add.y) DUMMY_DER */) = ((data->simulationInfo->realParameter[17] /* add.k1 PARAM */)) * ((data->localData[0]->realVars[25] /* der(add.u1) DUMMY_DER */)) + ((data->simulationInfo->realParameter[18] /* add.k2 PARAM */)) * ((data->localData[0]->realVars[46] /* der(step.y) DUMMY_DER */));
  TRACE_POP
}

/*
equation index: 12
type: SIMPLE_ASSIGN
$DER.division2.y = $DER.add.y / constant4.k
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_12(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,12};
  (data->localData[0]->realVars[36] /* der(division2.y) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[26] /* der(add.y) DUMMY_DER */),(data->simulationInfo->realParameter[29] /* constant4.k PARAM */),"constant4.k",equationIndexes);
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_469(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_479(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_480(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_481(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_482(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_487(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_488(DATA *data, threadData_t *threadData);


/*
equation index: 20
type: SIMPLE_ASSIGN
intake.p_i = data.p_a + data.g * data.rho * const.k
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_20(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,20};
  (data->localData[0]->realVars[115] /* intake.p_i variable */) = (data->simulationInfo->realParameter[45] /* data.p_a PARAM */) + ((data->simulationInfo->realParameter[42] /* data.g PARAM */)) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->simulationInfo->realParameter[21] /* const.k PARAM */)));
  TRACE_POP
}

/*
equation index: 21
type: SIMPLE_ASSIGN
discharge.p_o = data.p_a + data.g * data.rho * constant2.k
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_21(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,21};
  (data->localData[0]->realVars[100] /* discharge.p_o variable */) = (data->simulationInfo->realParameter[45] /* data.p_a PARAM */) + ((data->simulationInfo->realParameter[42] /* data.g PARAM */)) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->simulationInfo->realParameter[25] /* constant2.k PARAM */)));
  TRACE_POP
}

/*
equation index: 22
type: SIMPLE_ASSIGN
turbine1.C_v_ = if turbine1.ValveCapacity then turbine1.C_v else turbine1.Vdot_n / (sqrt(turbine1.H_n * data.g * data.rho / data.p_a) * turbine1.u_n)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_22(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,22};
  modelica_real tmp1;
  modelica_boolean tmp2;
  modelica_real tmp3;
  tmp2 = (modelica_boolean)(data->simulationInfo->booleanParameter[14] /* turbine1.ValveCapacity PARAM */);
  if(tmp2)
  {
    tmp3 = (data->simulationInfo->realParameter[101] /* turbine1.C_v PARAM */);
  }
  else
  {
    tmp1 = DIVISION_SIM((((data->simulationInfo->realParameter[103] /* turbine1.H_n PARAM */)) * ((data->simulationInfo->realParameter[42] /* data.g PARAM */))) * ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)),(data->simulationInfo->realParameter[45] /* data.p_a PARAM */),"data.p_a",equationIndexes);
    if(!(tmp1 >= 0.0))
    {
      if (data->simulationInfo->noThrowAsserts) {
        FILE_INFO info = {"",0,0,0,0,0};
        infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        data->simulationInfo->needToReThrow = 1;
      } else {
        FILE_INFO info = {"",0,0,0,0,0};
        omc_assert_warning(info, "The following assertion has been violated %sat time %f", initial() ? "during initialization " : "", data->localData[0]->timeValue);
        throwStreamPrintWithEquationIndexes(threadData, info, equationIndexes, "Model error: Argument of sqrt(turbine1.H_n * data.g * data.rho / data.p_a) was %g should be >= 0", tmp1);
      }
    }
    tmp3 = DIVISION_SIM((data->simulationInfo->realParameter[107] /* turbine1.Vdot_n PARAM */),(sqrt(tmp1)) * ((data->simulationInfo->realParameter[151] /* turbine1.u_n PARAM */)),"sqrt(turbine1.H_n * data.g * data.rho / data.p_a) * turbine1.u_n",equationIndexes);
  }
  (data->localData[0]->realVars[162] /* turbine1.C_v_ variable */) = tmp3;
  TRACE_POP
}

/*
equation index: 23
type: SIMPLE_ASSIGN
penstock.D_ = 0.5 * (penstock.D_i + penstock.D_o)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_23(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,23};
  (data->localData[0]->realVars[121] /* penstock.D_ variable */) = (0.5) * ((data->simulationInfo->realParameter[66] /* penstock.D_i PARAM */) + (data->simulationInfo->realParameter[67] /* penstock.D_o PARAM */));
  TRACE_POP
}

/*
equation index: 24
type: SIMPLE_ASSIGN
penstock.A_ = 0.7853981633974483 * penstock.D_ ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_24(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,24};
  modelica_real tmp4;
  tmp4 = (data->localData[0]->realVars[121] /* penstock.D_ variable */);
  (data->localData[0]->realVars[118] /* penstock.A_ variable */) = (0.7853981633974483) * ((tmp4 * tmp4));
  TRACE_POP
}

/*
equation index: 25
type: SIMPLE_ASSIGN
penstock.m = data.rho * penstock.A_ * penstock.L
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_25(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,25};
  (data->localData[0]->realVars[126] /* penstock.m variable */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[118] /* penstock.A_ variable */)) * ((data->simulationInfo->realParameter[69] /* penstock.L PARAM */)));
  TRACE_POP
}

/*
equation index: 26
type: SIMPLE_ASSIGN
penstock.A_i = 0.7853981633974483 * penstock.D_i ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_26(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,26};
  modelica_real tmp5;
  tmp5 = (data->simulationInfo->realParameter[66] /* penstock.D_i PARAM */);
  (data->localData[0]->realVars[119] /* penstock.A_i variable */) = (0.7853981633974483) * ((tmp5 * tmp5));
  TRACE_POP
}

/*
equation index: 27
type: SIMPLE_ASSIGN
penstock.A_o = 0.7853981633974483 * penstock.D_o ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_27(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,27};
  modelica_real tmp6;
  tmp6 = (data->simulationInfo->realParameter[67] /* penstock.D_o PARAM */);
  (data->localData[0]->realVars[120] /* penstock.A_o variable */) = (0.7853981633974483) * ((tmp6 * tmp6));
  TRACE_POP
}

/*
equation index: 28
type: SIMPLE_ASSIGN
penstock.cos_theta = penstock.H / penstock.L
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_28(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,28};
  (data->localData[0]->realVars[124] /* penstock.cos_theta variable */) = DIVISION_SIM((data->simulationInfo->realParameter[68] /* penstock.H PARAM */),(data->simulationInfo->realParameter[69] /* penstock.L PARAM */),"penstock.L",equationIndexes);
  TRACE_POP
}

/*
equation index: 29
type: SIMPLE_ASSIGN
surgeTank.A = 0.7853981633974483 * surgeTank.D ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_29(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,29};
  modelica_real tmp7;
  tmp7 = (data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */);
  (data->localData[0]->realVars[138] /* surgeTank.A variable */) = (0.7853981633974483) * ((tmp7 * tmp7));
  TRACE_POP
}

/*
equation index: 30
type: SIMPLE_ASSIGN
surgeTank.cos_theta = surgeTank.H / surgeTank.L
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_30(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,30};
  (data->localData[0]->realVars[147] /* surgeTank.cos_theta variable */) = DIVISION_SIM((data->simulationInfo->realParameter[85] /* surgeTank.H PARAM */),(data->simulationInfo->realParameter[86] /* surgeTank.L PARAM */),"surgeTank.L",equationIndexes);
  TRACE_POP
}

/*
equation index: 31
type: SIMPLE_ASSIGN
surgeTank.m_a = surgeTank.p_ac * surgeTank.A * (surgeTank.L - surgeTank.h_0 / surgeTank.cos_theta) * data.M_a / (8.31446261815324 * surgeTank.T_ac)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_31(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,31};
  (data->localData[0]->realVars[150] /* surgeTank.m_a variable */) = DIVISION_SIM(((((data->simulationInfo->realParameter[91] /* surgeTank.p_ac PARAM */)) * ((data->localData[0]->realVars[138] /* surgeTank.A variable */))) * ((data->simulationInfo->realParameter[86] /* surgeTank.L PARAM */) - (DIVISION_SIM((data->simulationInfo->realParameter[90] /* surgeTank.h_0 PARAM */),(data->localData[0]->realVars[147] /* surgeTank.cos_theta variable */),"surgeTank.cos_theta",equationIndexes)))) * ((data->simulationInfo->realParameter[35] /* data.M_a PARAM */)),(8.31446261815324) * ((data->simulationInfo->realParameter[88] /* surgeTank.T_ac PARAM */)),"8.31446261815324 * surgeTank.T_ac",equationIndexes);
  TRACE_POP
}

/*
equation index: 32
type: SIMPLE_ASSIGN
intake.D_ = 0.5 * (intake.D_i + intake.D_o)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_32(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,32};
  (data->localData[0]->realVars[108] /* intake.D_ variable */) = (0.5) * ((data->simulationInfo->realParameter[59] /* intake.D_i PARAM */) + (data->simulationInfo->realParameter[60] /* intake.D_o PARAM */));
  TRACE_POP
}

/*
equation index: 33
type: SIMPLE_ASSIGN
intake.A_ = 0.7853981633974483 * intake.D_ ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_33(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,33};
  modelica_real tmp8;
  tmp8 = (data->localData[0]->realVars[108] /* intake.D_ variable */);
  (data->localData[0]->realVars[105] /* intake.A_ variable */) = (0.7853981633974483) * ((tmp8 * tmp8));
  TRACE_POP
}

/*
equation index: 34
type: SIMPLE_ASSIGN
intake.m = data.rho * intake.A_ * intake.L
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_34(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,34};
  (data->localData[0]->realVars[113] /* intake.m variable */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[105] /* intake.A_ variable */)) * ((data->simulationInfo->realParameter[62] /* intake.L PARAM */)));
  TRACE_POP
}

/*
equation index: 35
type: SIMPLE_ASSIGN
intake.A_i = 0.7853981633974483 * intake.D_i ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_35(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,35};
  modelica_real tmp9;
  tmp9 = (data->simulationInfo->realParameter[59] /* intake.D_i PARAM */);
  (data->localData[0]->realVars[106] /* intake.A_i variable */) = (0.7853981633974483) * ((tmp9 * tmp9));
  TRACE_POP
}

/*
equation index: 36
type: SIMPLE_ASSIGN
intake.A_o = 0.7853981633974483 * intake.D_o ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_36(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,36};
  modelica_real tmp10;
  tmp10 = (data->simulationInfo->realParameter[60] /* intake.D_o PARAM */);
  (data->localData[0]->realVars[107] /* intake.A_o variable */) = (0.7853981633974483) * ((tmp10 * tmp10));
  TRACE_POP
}

/*
equation index: 37
type: SIMPLE_ASSIGN
intake.cos_theta = intake.H / intake.L
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_37(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,37};
  (data->localData[0]->realVars[111] /* intake.cos_theta variable */) = DIVISION_SIM((data->simulationInfo->realParameter[61] /* intake.H PARAM */),(data->simulationInfo->realParameter[62] /* intake.L PARAM */),"intake.L",equationIndexes);
  TRACE_POP
}

/*
equation index: 38
type: SIMPLE_ASSIGN
discharge.D_ = 0.5 * (discharge.D_i + discharge.D_o)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_38(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,38};
  (data->localData[0]->realVars[91] /* discharge.D_ variable */) = (0.5) * ((data->simulationInfo->realParameter[48] /* discharge.D_i PARAM */) + (data->simulationInfo->realParameter[49] /* discharge.D_o PARAM */));
  TRACE_POP
}

/*
equation index: 39
type: SIMPLE_ASSIGN
discharge.A_ = 0.7853981633974483 * discharge.D_ ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_39(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,39};
  modelica_real tmp11;
  tmp11 = (data->localData[0]->realVars[91] /* discharge.D_ variable */);
  (data->localData[0]->realVars[88] /* discharge.A_ variable */) = (0.7853981633974483) * ((tmp11 * tmp11));
  TRACE_POP
}

/*
equation index: 40
type: SIMPLE_ASSIGN
discharge.m = data.rho * discharge.A_ * discharge.L
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_40(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,40};
  (data->localData[0]->realVars[97] /* discharge.m variable */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[88] /* discharge.A_ variable */)) * ((data->simulationInfo->realParameter[51] /* discharge.L PARAM */)));
  TRACE_POP
}

/*
equation index: 41
type: SIMPLE_ASSIGN
discharge.A_i = 0.7853981633974483 * discharge.D_i ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_41(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,41};
  modelica_real tmp12;
  tmp12 = (data->simulationInfo->realParameter[48] /* discharge.D_i PARAM */);
  (data->localData[0]->realVars[89] /* discharge.A_i variable */) = (0.7853981633974483) * ((tmp12 * tmp12));
  TRACE_POP
}

/*
equation index: 42
type: SIMPLE_ASSIGN
discharge.A_o = 0.7853981633974483 * discharge.D_o ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_42(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,42};
  modelica_real tmp13;
  tmp13 = (data->simulationInfo->realParameter[49] /* discharge.D_o PARAM */);
  (data->localData[0]->realVars[90] /* discharge.A_o variable */) = (0.7853981633974483) * ((tmp13 * tmp13));
  TRACE_POP
}

/*
equation index: 43
type: SIMPLE_ASSIGN
discharge.cos_theta = discharge.H / discharge.L
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_43(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,43};
  (data->localData[0]->realVars[95] /* discharge.cos_theta variable */) = DIVISION_SIM((data->simulationInfo->realParameter[50] /* discharge.H PARAM */),(data->simulationInfo->realParameter[51] /* discharge.L PARAM */),"discharge.L",equationIndexes);
  TRACE_POP
}

/*
equation index: 44
type: SIMPLE_ASSIGN
surgeTank.Vdot = surgeTank.Vdot_0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_44(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,44};
  (data->localData[0]->realVars[146] /* surgeTank.Vdot DUMMY_STATE */) = (data->simulationInfo->realParameter[89] /* surgeTank.Vdot_0 PARAM */);
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_501(DATA *data, threadData_t *threadData);


/*
equation index: 46
type: SIMPLE_ASSIGN
surgeTank.mdot = data.rho * surgeTank.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_46(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,46};
  (data->localData[0]->realVars[151] /* surgeTank.mdot DUMMY_STATE */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->localData[0]->realVars[146] /* surgeTank.Vdot DUMMY_STATE */));
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_505(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_506(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_507(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_508(DATA *data, threadData_t *threadData);


/*
equation index: 51
type: SIMPLE_ASSIGN
intake.Vdot = intake.Vdot_0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_51(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,51};
  (data->localData[0]->realVars[110] /* intake.Vdot DUMMY_STATE */) = (data->simulationInfo->realParameter[63] /* intake.Vdot_0 PARAM */);
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_492(DATA *data, threadData_t *threadData);


/*
equation index: 53
type: SIMPLE_ASSIGN
discharge.mdot = intake.mdot - surgeTank.mdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_53(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,53};
  (data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */) = (data->localData[0]->realVars[114] /* intake.mdot DUMMY_STATE */) - (data->localData[0]->realVars[151] /* surgeTank.mdot DUMMY_STATE */);
  TRACE_POP
}

/*
equation index: 54
type: SIMPLE_ASSIGN
penstock.Vdot = discharge.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_54(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,54};
  (data->localData[0]->realVars[123] /* penstock.Vdot DUMMY_STATE */) = DIVISION_SIM((data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes);
  TRACE_POP
}

/*
equation index: 55
type: SIMPLE_ASSIGN
penstock.M = data.rho * penstock.L * penstock.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_55(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,55};
  (data->localData[0]->realVars[1] /* penstock.M STATE(1) */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[69] /* penstock.L PARAM */)) * ((data->localData[0]->realVars[123] /* penstock.Vdot DUMMY_STATE */)));
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_516(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_517(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_509(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_510(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_511(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_512(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_515(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_493(DATA *data, threadData_t *threadData);


/*
equation index: 64
type: SIMPLE_ASSIGN
intake.M = data.rho * intake.L * intake.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_64(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,64};
  (data->localData[0]->realVars[0] /* intake.M STATE(1) */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[62] /* intake.L PARAM */)) * ((data->localData[0]->realVars[110] /* intake.Vdot DUMMY_STATE */)));
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_494(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_495(DATA *data, threadData_t *threadData);


/*
equation index: 67
type: SIMPLE_ASSIGN
turbine1.setSpeed.w = turbine1.setSpeed.w_ref
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_67(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,67};
  (data->localData[0]->realVars[4] /* turbine1.setSpeed.w STATE(1,turbine1.setSpeed.a) */) = (data->localData[0]->realVars[183] /* turbine1.setSpeed.w_ref variable */);
  TRACE_POP
}

/*
equation index: 68
type: SIMPLE_ASSIGN
turbine1.inertia.w = turbine1.toSysSpeed.ratio * turbine1.setSpeed.w
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_68(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,68};
  (data->localData[0]->realVars[178] /* turbine1.inertia.w DUMMY_STATE */) = ((data->simulationInfo->realParameter[148] /* turbine1.toSysSpeed.ratio PARAM */)) * ((data->localData[0]->realVars[4] /* turbine1.setSpeed.w STATE(1,turbine1.setSpeed.a) */));
  TRACE_POP
}

/*
equation index: 69
type: SIMPLE_ASSIGN
turbine1.toHz.y = turbine1.toHz.k * turbine1.inertia.w
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_69(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,69};
  (data->localData[0]->realVars[186] /* turbine1.toHz.y variable */) = ((data->simulationInfo->realParameter[147] /* turbine1.toHz.k PARAM */)) * ((data->localData[0]->realVars[178] /* turbine1.inertia.w DUMMY_STATE */));
  TRACE_POP
}

/*
equation index: 70
type: SIMPLE_ASSIGN
turbine1.div0protect.y = homotopy(smooth(0, if turbine1.inertia.w > turbine1.div0protect.uMax then turbine1.div0protect.uMax else if turbine1.inertia.w < turbine1.div0protect.uMin then turbine1.div0protect.uMin else turbine1.inertia.w), turbine1.inertia.w)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_70(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,70};
  modelica_boolean tmp14;
  modelica_boolean tmp15;
  modelica_boolean tmp16;
  modelica_real tmp17;
  tmp14 = Greater((data->localData[0]->realVars[178] /* turbine1.inertia.w DUMMY_STATE */),(data->simulationInfo->realParameter[108] /* turbine1.div0protect.uMax PARAM */));
  tmp16 = (modelica_boolean)tmp14;
  if(tmp16)
  {
    tmp17 = (data->simulationInfo->realParameter[108] /* turbine1.div0protect.uMax PARAM */);
  }
  else
  {
    tmp15 = Less((data->localData[0]->realVars[178] /* turbine1.inertia.w DUMMY_STATE */),(data->simulationInfo->realParameter[109] /* turbine1.div0protect.uMin PARAM */));
    tmp17 = (tmp15?(data->simulationInfo->realParameter[109] /* turbine1.div0protect.uMin PARAM */):(data->localData[0]->realVars[178] /* turbine1.inertia.w DUMMY_STATE */));
  }
  (data->localData[0]->realVars[166] /* turbine1.div0protect.y variable */) = homotopy(tmp17, (data->localData[0]->realVars[178] /* turbine1.inertia.w DUMMY_STATE */));
  TRACE_POP
}

/*
equation index: 71
type: SIMPLE_ASSIGN
turbine1.friction.w = turbine1.inertia.w
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_71(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,71};
  (data->localData[0]->realVars[174] /* turbine1.friction.w variable */) = (data->localData[0]->realVars[178] /* turbine1.inertia.w DUMMY_STATE */);
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_474(DATA *data, threadData_t *threadData);


/*
equation index: 73
type: SIMPLE_ASSIGN
$DER.turbine1.speedSensor.flange.phi = turbine1.inertia.w
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_73(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,73};
  (data->localData[0]->realVars[64] /* der(turbine1.speedSensor.flange.phi) DUMMY_DER */) = (data->localData[0]->realVars[178] /* turbine1.inertia.w DUMMY_STATE */);
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_483(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_484(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_485(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_486(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_468(DATA *data, threadData_t *threadData);


/*
equation index: 79
type: SIMPLE_ASSIGN
surgeTank.h = surgeTank.h_0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_79(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,79};
  (data->localData[0]->realVars[148] /* surgeTank.h variable */) = (data->simulationInfo->realParameter[90] /* surgeTank.h_0 PARAM */);
  TRACE_POP
}

/*
equation index: 80
type: SIMPLE_ASSIGN
surgeTank.l = surgeTank.h / surgeTank.cos_theta
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_80(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,80};
  (data->localData[0]->realVars[149] /* surgeTank.l DUMMY_STATE */) = DIVISION_SIM((data->localData[0]->realVars[148] /* surgeTank.h variable */),(data->localData[0]->realVars[147] /* surgeTank.cos_theta variable */),"surgeTank.cos_theta",equationIndexes);
  TRACE_POP
}

/*
equation index: 81
type: SIMPLE_ASSIGN
surgeTank.m = data.rho * surgeTank.A * surgeTank.l
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_81(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,81};
  (data->localData[0]->realVars[2] /* surgeTank.m STATE(1,surgeTank.mdot) */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[138] /* surgeTank.A variable */)) * ((data->localData[0]->realVars[149] /* surgeTank.l DUMMY_STATE */)));
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_502(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_476(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_504(DATA *data, threadData_t *threadData);


void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_85(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_86(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_87(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_88(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_89(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_90(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_91(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_92(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_93(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_94(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_95(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_96(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_97(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_98(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_99(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_100(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_101(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_102(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_103(DATA*, threadData_t*);
/*
equation index: 120
indexNonlinear: 0
type: NONLINEAR

vars: {$DER.surgeTank.v}
eqns: {85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103}
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_120(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,120};
  int retValue;
  if(ACTIVE_STREAM(LOG_DT))
  {
    infoStreamPrint(LOG_DT, 1, "Solving nonlinear system 120 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);
    messageClose(LOG_DT);
  }
  /* get old value */
  data->simulationInfo->nonlinearSystemData[0].nlsxOld[0] = (data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */);
  retValue = solve_nonlinear_system(data, threadData, 0);
  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,120};
    throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, indexes, "Solving non-linear system 120 failed at time=%.15g.\nFor more information please use -lv LOG_NLS.", data->localData[0]->timeValue);
  }
  /* write solution */
  (data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */) = data->simulationInfo->nonlinearSystemData[0].nlsx[0];
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_561(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_562(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_563(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_564(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_565(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_566(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_567(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_571(DATA *data, threadData_t *threadData);


/*
equation index: 129
type: SIMPLE_ASSIGN
$outputAlias_TM_Torque_Out = division.y * booleanToReal.y
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_129(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,129};
  (data->localData[0]->realVars[78] /* $outputAlias_TM_Torque_Out DUMMY_STATE */) = ((data->localData[0]->realVars[102] /* division.y DUMMY_STATE */)) * ((data->localData[0]->realVars[87] /* booleanToReal.y DUMMY_STATE */));
  TRACE_POP
}

/*
equation index: 130
type: SIMPLE_ASSIGN
TM_Torque_Out = $outputAlias_TM_Torque_Out
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_130(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,130};
  (data->localData[0]->realVars[84] /* TM_Torque_Out variable */) = (data->localData[0]->realVars[78] /* $outputAlias_TM_Torque_Out DUMMY_STATE */);
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_568(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_570(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_569(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_574(DATA *data, threadData_t *threadData);


/*
equation index: 135
type: SIMPLE_ASSIGN
turbine1.torque.tau = homotopy(smooth(0, if turbine1.torqueLimit.u > turbine1.torqueLimit.uMax then turbine1.torqueLimit.uMax else if turbine1.torqueLimit.u < turbine1.torqueLimit.uMin then turbine1.torqueLimit.uMin else turbine1.torqueLimit.u), turbine1.torqueLimit.u)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_135(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,135};
  modelica_boolean tmp0;
  modelica_boolean tmp1;
  modelica_boolean tmp2;
  modelica_real tmp3;
  tmp0 = Greater((data->localData[0]->realVars[192] /* turbine1.torqueLimit.u variable */),(data->simulationInfo->realParameter[149] /* turbine1.torqueLimit.uMax PARAM */));
  tmp2 = (modelica_boolean)tmp0;
  if(tmp2)
  {
    tmp3 = (data->simulationInfo->realParameter[149] /* turbine1.torqueLimit.uMax PARAM */);
  }
  else
  {
    tmp1 = Less((data->localData[0]->realVars[192] /* turbine1.torqueLimit.u variable */),(data->simulationInfo->realParameter[150] /* turbine1.torqueLimit.uMin PARAM */));
    tmp3 = (tmp1?(data->simulationInfo->realParameter[150] /* turbine1.torqueLimit.uMin PARAM */):(data->localData[0]->realVars[192] /* turbine1.torqueLimit.u variable */));
  }
  (data->localData[0]->realVars[191] /* turbine1.torque.tau variable */) = homotopy(tmp3, (data->localData[0]->realVars[192] /* turbine1.torqueLimit.u variable */));
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_576(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_577(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_558(DATA *data, threadData_t *threadData);


/*
equation index: 139
type: SIMPLE_ASSIGN
$DER.penstock.F_f = 0.3926990816987241 * data.rho * penstock.L * (OpenHPL.Functions.DarcyFriction.fDarcy(data.rho * abs(penstock.v) * penstock.D_ / data.mu, penstock.D_, penstock.p_eps) * (penstock.v * sign(penstock.v) * $DER.penstock.v * penstock.D_ + $DER.penstock.v * abs(penstock.v) * penstock.D_) + $DER$OpenHPL$PFunctions$PDarcyFriction$PfDarcy(data.rho * abs(penstock.v) * penstock.D_ / data.mu, penstock.D_, penstock.p_eps, data.rho * sign(penstock.v) * $DER.penstock.v * penstock.D_ * data.mu / data.mu ^ 2.0, 0.0, 0.0) * penstock.v * abs(penstock.v) * penstock.D_)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_139(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,139};
  modelica_real tmp4;
  tmp4 = (data->simulationInfo->realParameter[44] /* data.mu PARAM */);
  (data->localData[0]->realVars[42] /* der(penstock.F_f) DUMMY_DER */) = (0.3926990816987241) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[69] /* penstock.L PARAM */)) * ((omc_OpenHPL_Functions_DarcyFriction_fDarcy(threadData, DIVISION_SIM((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (fabs((data->localData[0]->realVars[128] /* penstock.v DUMMY_STATE */)))) * ((data->localData[0]->realVars[121] /* penstock.D_ variable */)),(data->simulationInfo->realParameter[44] /* data.mu PARAM */),"data.mu",equationIndexes), (data->localData[0]->realVars[121] /* penstock.D_ variable */), (data->simulationInfo->realParameter[71] /* penstock.p_eps PARAM */))) * (((data->localData[0]->realVars[128] /* penstock.v DUMMY_STATE */)) * ((sign((data->localData[0]->realVars[128] /* penstock.v DUMMY_STATE */))) * (((data->localData[0]->realVars[45] /* der(penstock.v) DUMMY_DER */)) * ((data->localData[0]->realVars[121] /* penstock.D_ variable */)))) + ((data->localData[0]->realVars[45] /* der(penstock.v) DUMMY_DER */)) * ((fabs((data->localData[0]->realVars[128] /* penstock.v DUMMY_STATE */))) * ((data->localData[0]->realVars[121] /* penstock.D_ variable */)))) + (omc__omcQ_24DER_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy(threadData, DIVISION_SIM((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (fabs((data->localData[0]->realVars[128] /* penstock.v DUMMY_STATE */)))) * ((data->localData[0]->realVars[121] /* penstock.D_ variable */)),(data->simulationInfo->realParameter[44] /* data.mu PARAM */),"data.mu",equationIndexes), (data->localData[0]->realVars[121] /* penstock.D_ variable */), (data->simulationInfo->realParameter[71] /* penstock.p_eps PARAM */), DIVISION_SIM(((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((sign((data->localData[0]->realVars[128] /* penstock.v DUMMY_STATE */))) * ((data->localData[0]->realVars[45] /* der(penstock.v) DUMMY_DER */)))) * ((data->localData[0]->realVars[121] /* penstock.D_ variable */))) * ((data->simulationInfo->realParameter[44] /* data.mu PARAM */)),(tmp4 * tmp4),"data.mu ^ 2.0",equationIndexes), 0.0, 0.0)) * (((data->localData[0]->realVars[128] /* penstock.v DUMMY_STATE */)) * ((fabs((data->localData[0]->realVars[128] /* penstock.v DUMMY_STATE */))) * ((data->localData[0]->realVars[121] /* penstock.D_ variable */)))))));
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_579(DATA *data, threadData_t *threadData);


/*
equation index: 141
type: SIMPLE_ASSIGN
$DER.discharge.F_f = 0.3926990816987241 * data.rho * discharge.L * (OpenHPL.Functions.DarcyFriction.fDarcy(data.rho * abs(discharge.v) * discharge.D_ / data.mu, discharge.D_, discharge.p_eps) * (discharge.v * sign(discharge.v) * $DER.discharge.v * discharge.D_ + $DER.discharge.v * abs(discharge.v) * discharge.D_) + data.rho * sign(discharge.v) * $DER.discharge.v * discharge.D_ ^ 2.0 * $DER$OpenHPL$PFunctions$PDarcyFriction$PfDarcy(data.rho * abs(discharge.v) * discharge.D_ / data.mu, discharge.D_, discharge.p_eps, 1.0, 0.0, 0.0) * discharge.v * abs(discharge.v) / data.mu)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_141(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,141};
  modelica_real tmp5;
  tmp5 = (data->localData[0]->realVars[91] /* discharge.D_ variable */);
  (data->localData[0]->realVars[28] /* der(discharge.F_f) DUMMY_DER */) = (0.3926990816987241) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[51] /* discharge.L PARAM */)) * ((omc_OpenHPL_Functions_DarcyFriction_fDarcy(threadData, DIVISION_SIM((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (fabs((data->localData[0]->realVars[101] /* discharge.v DUMMY_STATE */)))) * ((data->localData[0]->realVars[91] /* discharge.D_ variable */)),(data->simulationInfo->realParameter[44] /* data.mu PARAM */),"data.mu",equationIndexes), (data->localData[0]->realVars[91] /* discharge.D_ variable */), (data->simulationInfo->realParameter[53] /* discharge.p_eps PARAM */))) * (((data->localData[0]->realVars[101] /* discharge.v DUMMY_STATE */)) * ((sign((data->localData[0]->realVars[101] /* discharge.v DUMMY_STATE */))) * (((data->localData[0]->realVars[33] /* der(discharge.v) DUMMY_DER */)) * ((data->localData[0]->realVars[91] /* discharge.D_ variable */)))) + ((data->localData[0]->realVars[33] /* der(discharge.v) DUMMY_DER */)) * ((fabs((data->localData[0]->realVars[101] /* discharge.v DUMMY_STATE */))) * ((data->localData[0]->realVars[91] /* discharge.D_ variable */)))) + ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((sign((data->localData[0]->realVars[101] /* discharge.v DUMMY_STATE */))) * (((data->localData[0]->realVars[33] /* der(discharge.v) DUMMY_DER */)) * (((tmp5 * tmp5)) * (DIVISION_SIM((omc__omcQ_24DER_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy(threadData, DIVISION_SIM((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (fabs((data->localData[0]->realVars[101] /* discharge.v DUMMY_STATE */)))) * ((data->localData[0]->realVars[91] /* discharge.D_ variable */)),(data->simulationInfo->realParameter[44] /* data.mu PARAM */),"data.mu",equationIndexes), (data->localData[0]->realVars[91] /* discharge.D_ variable */), (data->simulationInfo->realParameter[53] /* discharge.p_eps PARAM */), 1.0, 0.0, 0.0)) * (((data->localData[0]->realVars[101] /* discharge.v DUMMY_STATE */)) * (fabs((data->localData[0]->realVars[101] /* discharge.v DUMMY_STATE */)))),(data->simulationInfo->realParameter[44] /* data.mu PARAM */),"data.mu",equationIndexes))))))));
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_578(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_584(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_585(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_581(DATA *data, threadData_t *threadData);


/*
equation index: 146
type: SIMPLE_ASSIGN
$DER.intake.F_f = 0.3926990816987241 * data.rho * intake.L * (OpenHPL.Functions.DarcyFriction.fDarcy(data.rho * abs(intake.v) * intake.D_ / data.mu, intake.D_, intake.p_eps) * (intake.v * sign(intake.v) * $DER.intake.v * intake.D_ + $DER.intake.v * abs(intake.v) * intake.D_) + $DER$OpenHPL$PFunctions$PDarcyFriction$PfDarcy(data.rho * abs(intake.v) * intake.D_ / data.mu, intake.D_, intake.p_eps, data.rho * sign(intake.v) * $DER.intake.v * intake.D_ * data.mu / data.mu ^ 2.0, 0.0, 0.0) * intake.v * abs(intake.v) * intake.D_)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_146(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,146};
  modelica_real tmp6;
  tmp6 = (data->simulationInfo->realParameter[44] /* data.mu PARAM */);
  (data->localData[0]->realVars[37] /* der(intake.F_f) DUMMY_DER */) = (0.3926990816987241) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[62] /* intake.L PARAM */)) * ((omc_OpenHPL_Functions_DarcyFriction_fDarcy(threadData, DIVISION_SIM((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (fabs((data->localData[0]->realVars[117] /* intake.v DUMMY_STATE */)))) * ((data->localData[0]->realVars[108] /* intake.D_ variable */)),(data->simulationInfo->realParameter[44] /* data.mu PARAM */),"data.mu",equationIndexes), (data->localData[0]->realVars[108] /* intake.D_ variable */), (data->simulationInfo->realParameter[64] /* intake.p_eps PARAM */))) * (((data->localData[0]->realVars[117] /* intake.v DUMMY_STATE */)) * ((sign((data->localData[0]->realVars[117] /* intake.v DUMMY_STATE */))) * (((data->localData[0]->realVars[41] /* der(intake.v) DUMMY_DER */)) * ((data->localData[0]->realVars[108] /* intake.D_ variable */)))) + ((data->localData[0]->realVars[41] /* der(intake.v) DUMMY_DER */)) * ((fabs((data->localData[0]->realVars[117] /* intake.v DUMMY_STATE */))) * ((data->localData[0]->realVars[108] /* intake.D_ variable */)))) + (omc__omcQ_24DER_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy(threadData, DIVISION_SIM((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (fabs((data->localData[0]->realVars[117] /* intake.v DUMMY_STATE */)))) * ((data->localData[0]->realVars[108] /* intake.D_ variable */)),(data->simulationInfo->realParameter[44] /* data.mu PARAM */),"data.mu",equationIndexes), (data->localData[0]->realVars[108] /* intake.D_ variable */), (data->simulationInfo->realParameter[64] /* intake.p_eps PARAM */), DIVISION_SIM(((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((sign((data->localData[0]->realVars[117] /* intake.v DUMMY_STATE */))) * ((data->localData[0]->realVars[41] /* der(intake.v) DUMMY_DER */)))) * ((data->localData[0]->realVars[108] /* intake.D_ variable */))) * ((data->simulationInfo->realParameter[44] /* data.mu PARAM */)),(tmp6 * tmp6),"data.mu ^ 2.0",equationIndexes), 0.0, 0.0)) * (((data->localData[0]->realVars[117] /* intake.v DUMMY_STATE */)) * ((fabs((data->localData[0]->realVars[117] /* intake.v DUMMY_STATE */))) * ((data->localData[0]->realVars[108] /* intake.D_ variable */)))))));
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_556(DATA *data, threadData_t *threadData);


/*
equation index: 148
type: SIMPLE_ASSIGN
$DER.surgeTank.F_f = 0.3926990816987241 * data.rho * (OpenHPL.Functions.DarcyFriction.fDarcy(data.rho * abs(surgeTank.v) * surgeTank.D / data.mu, surgeTank.D, surgeTank.p_eps) * (surgeTank.l * (surgeTank.v * sign(surgeTank.v) * $DER.surgeTank.v * surgeTank.D + $DER.surgeTank.v * abs(surgeTank.v) * surgeTank.D) + $DER.surgeTank.l * surgeTank.v * abs(surgeTank.v) * surgeTank.D) + $DER$OpenHPL$PFunctions$PDarcyFriction$PfDarcy(data.rho * abs(surgeTank.v) * surgeTank.D / data.mu, surgeTank.D, surgeTank.p_eps, data.rho * sign(surgeTank.v) * $DER.surgeTank.v * surgeTank.D * data.mu / data.mu ^ 2.0, 0.0, 0.0) * surgeTank.l * surgeTank.v * abs(surgeTank.v) * surgeTank.D)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_148(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,148};
  modelica_real tmp7;
  tmp7 = (data->simulationInfo->realParameter[44] /* data.mu PARAM */);
  (data->localData[0]->realVars[48] /* der(surgeTank.F_f) DUMMY_DER */) = (0.3926990816987241) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((omc_OpenHPL_Functions_DarcyFriction_fDarcy(threadData, DIVISION_SIM((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (fabs((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */)))) * ((data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */)),(data->simulationInfo->realParameter[44] /* data.mu PARAM */),"data.mu",equationIndexes), (data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */), (data->simulationInfo->realParameter[92] /* surgeTank.p_eps PARAM */))) * (((data->localData[0]->realVars[149] /* surgeTank.l DUMMY_STATE */)) * (((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */)) * ((sign((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */))) * (((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)) * ((data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */)))) + ((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)) * ((fabs((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */))) * ((data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */)))) + ((data->localData[0]->realVars[54] /* der(surgeTank.l) DUMMY_DER */)) * (((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */)) * ((fabs((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */))) * ((data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */))))) + (omc__omcQ_24DER_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy(threadData, DIVISION_SIM((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (fabs((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */)))) * ((data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */)),(data->simulationInfo->realParameter[44] /* data.mu PARAM */),"data.mu",equationIndexes), (data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */), (data->simulationInfo->realParameter[92] /* surgeTank.p_eps PARAM */), DIVISION_SIM(((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((sign((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */))) * ((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)))) * ((data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */))) * ((data->simulationInfo->realParameter[44] /* data.mu PARAM */)),(tmp7 * tmp7),"data.mu ^ 2.0",equationIndexes), 0.0, 0.0)) * (((data->localData[0]->realVars[149] /* surgeTank.l DUMMY_STATE */)) * (((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */)) * ((fabs((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */))) * ((data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */)))))));
  TRACE_POP
}

/*
equation index: 184
type: LINEAR

<var>$DER.$DER.surgeTank.v</var>
<row>

</row>
<matrix>
</matrix>
*/
OMC_DISABLE_OPT
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_184(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,184};
  /* Linear equation system */
  int retValue;
  double aux_x[1] = { (data->localData[1]->realVars[21] /* der(der(surgeTank.v)) DUMMY_DER */) };
  if(ACTIVE_STREAM(LOG_DT))
  {
    infoStreamPrint(LOG_DT, 1, "Solving linear system 184 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);
    messageClose(LOG_DT);
  }
  
  retValue = solve_linear_system(data, threadData, 0, &aux_x[0]);
  
  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,184};
    throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, indexes, "Solving linear system 184 failed at time=%.15g.\nFor more information please use -lv LOG_LS.", data->localData[0]->timeValue);
  }
  /* write solution */
  (data->localData[0]->realVars[21] /* der(der(surgeTank.v)) DUMMY_DER */) = aux_x[0];

  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_622(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_623(DATA *data, threadData_t *threadData);


/*
equation index: 187
type: SIMPLE_ASSIGN
$DER.division1.y = ($DER.turbine1.Wdot_s * division2.y - turbine1.Wdot_s * $DER.division2.y) / division2.y ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_187(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,187};
  modelica_real tmp8;
  tmp8 = (data->localData[0]->realVars[104] /* division2.y DUMMY_STATE */);
  (data->localData[0]->realVars[35] /* der(division1.y) DUMMY_DER */) = DIVISION_SIM(((data->localData[0]->realVars[59] /* der(turbine1.Wdot_s) DUMMY_DER */)) * ((data->localData[0]->realVars[104] /* division2.y DUMMY_STATE */)) - (((data->localData[0]->realVars[165] /* turbine1.Wdot_s DUMMY_STATE */)) * ((data->localData[0]->realVars[36] /* der(division2.y) DUMMY_DER */))),(tmp8 * tmp8),"division2.y ^ 2.0",equationIndexes);
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_625(DATA *data, threadData_t *threadData);


/*
equation index: 189
type: SIMPLE_ASSIGN
$TM_Torque_Out_der = division.y * $DER.booleanToReal.y + $DER.division.y * booleanToReal.y
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_189(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,189};
  (data->localData[0]->realVars[67] /* $TM_Torque_Out_der variable */) = ((data->localData[0]->realVars[102] /* division.y DUMMY_STATE */)) * ((data->localData[0]->realVars[27] /* der(booleanToReal.y) DUMMY_DER */)) + ((data->localData[0]->realVars[34] /* der(division.y) DUMMY_DER */)) * ((data->localData[0]->realVars[87] /* booleanToReal.y DUMMY_STATE */));
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_627(DATA *data, threadData_t *threadData);


/*
equation index: 191
type: SIMPLE_ASSIGN
reservoir.A = const.k * (reservoir.W + const.k * tan(reservoir.alpha))
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_191(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,191};
  (data->localData[0]->realVars[129] /* reservoir.A variable */) = ((data->simulationInfo->realParameter[21] /* const.k PARAM */)) * ((data->simulationInfo->realParameter[73] /* reservoir.W PARAM */) + ((data->simulationInfo->realParameter[21] /* const.k PARAM */)) * (tan((data->simulationInfo->realParameter[74] /* reservoir.alpha PARAM */))));
  TRACE_POP
}

/*
equation index: 192
type: SIMPLE_ASSIGN
reservoir.m = data.rho * reservoir.A * reservoir.L
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_192(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,192};
  (data->localData[0]->realVars[134] /* reservoir.m variable */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[129] /* reservoir.A variable */)) * ((data->simulationInfo->realParameter[72] /* reservoir.L PARAM */)));
  TRACE_POP
}

/*
equation index: 193
type: SIMPLE_ASSIGN
reservoir.v = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_193(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,193};
  (data->localData[0]->realVars[136] /* reservoir.v variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 194
type: SIMPLE_ASSIGN
reservoir.M = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_194(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,194};
  (data->localData[0]->realVars[131] /* reservoir.M variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 195
type: SIMPLE_ASSIGN
turbine1.frictionLoss.power = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_195(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,195};
  (data->localData[0]->realVars[176] /* turbine1.frictionLoss.power variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 196
type: SIMPLE_ASSIGN
turbine1.friction.lossPower = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_196(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,196};
  (data->localData[0]->realVars[171] /* turbine1.friction.lossPower variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 197
type: SIMPLE_ASSIGN
reservoir.mdot = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_197(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,197};
  (data->localData[0]->realVars[135] /* reservoir.mdot variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 198
type: SIMPLE_ASSIGN
tail.mdot = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_198(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,198};
  (data->localData[0]->realVars[160] /* tail.mdot variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 199
type: SIMPLE_ASSIGN
turbine1.flange.tau = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_199(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,199};
  (data->localData[0]->realVars[169] /* turbine1.flange.tau variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 200
type: SIMPLE_ASSIGN
tail.Vdot = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_200(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,200};
  (data->localData[0]->realVars[157] /* tail.Vdot variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 201
type: SIMPLE_ASSIGN
surgeTank.phiSO = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_201(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,201};
  (data->localData[0]->realVars[152] /* surgeTank.phiSO variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 202
type: SIMPLE_ASSIGN
reservoir.Vdot = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_202(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,202};
  (data->localData[0]->realVars[132] /* reservoir.Vdot variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 203
type: SIMPLE_ASSIGN
turbine1.speedSensor.flange.tau = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_203(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,203};
  (data->localData[0]->realVars[185] /* turbine1.speedSensor.flange.tau variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 204
type: SIMPLE_ASSIGN
turbine1.friction.tau = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_204(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,204};
  (data->localData[0]->realVars[173] /* turbine1.friction.tau variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 205
type: SIMPLE_ASSIGN
turbine1.setSpeed.phi_support = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_205(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,205};
  (data->localData[0]->realVars[182] /* turbine1.setSpeed.phi_support variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 206
type: SIMPLE_ASSIGN
turbine1.toSysSpeed.phi_support = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_206(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,206};
  (data->localData[0]->realVars[189] /* turbine1.toSysSpeed.phi_support variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 207
type: SIMPLE_ASSIGN
turbine1.fixed.flange.tau = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_207(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,207};
  (data->localData[0]->realVars[168] /* turbine1.fixed.flange.tau variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 208
type: SIMPLE_ASSIGN
turbine1.friction.flange.tau = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_208(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,208};
  (data->localData[0]->realVars[170] /* turbine1.friction.flange.tau variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 209
type: SIMPLE_ASSIGN
turbine1.frictionLoss.flange_a.tau = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_209(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,209};
  (data->localData[0]->realVars[175] /* turbine1.frictionLoss.flange_a.tau variable */) = 0.0;
  TRACE_POP
}

/*
equation index: 210
type: SIMPLE_ASSIGN
$outputAlias_SM_Start_Torque_out = ServoMotorTorque.offset + (if time < ServoMotorTorque.startTime then 0.0 else if time < ServoMotorTorque.startTime + ServoMotorTorque.duration then (time - ServoMotorTorque.startTime) * ServoMotorTorque.height / ServoMotorTorque.duration else ServoMotorTorque.height)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_210(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,210};
  modelica_boolean tmp9;
  modelica_boolean tmp10;
  modelica_boolean tmp11;
  modelica_real tmp12;
  tmp9 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[4] /* ServoMotorTorque.startTime PARAM */));
  tmp11 = (modelica_boolean)tmp9;
  if(tmp11)
  {
    tmp12 = 0.0;
  }
  else
  {
    tmp10 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[4] /* ServoMotorTorque.startTime PARAM */) + (data->simulationInfo->realParameter[1] /* ServoMotorTorque.duration PARAM */));
    tmp12 = (tmp10?DIVISION_SIM((data->localData[0]->timeValue - (data->simulationInfo->realParameter[4] /* ServoMotorTorque.startTime PARAM */)) * ((data->simulationInfo->realParameter[2] /* ServoMotorTorque.height PARAM */)),(data->simulationInfo->realParameter[1] /* ServoMotorTorque.duration PARAM */),"ServoMotorTorque.duration",equationIndexes):(data->simulationInfo->realParameter[2] /* ServoMotorTorque.height PARAM */));
  }
  (data->localData[0]->realVars[77] /* $outputAlias_SM_Start_Torque_out DUMMY_STATE */) = (data->simulationInfo->realParameter[3] /* ServoMotorTorque.offset PARAM */) + tmp12;
  TRACE_POP
}

/*
equation index: 211
type: SIMPLE_ASSIGN
SM_Start_Torque_out = $outputAlias_SM_Start_Torque_out
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_211(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,211};
  (data->localData[0]->realVars[81] /* SM_Start_Torque_out variable */) = (data->localData[0]->realVars[77] /* $outputAlias_SM_Start_Torque_out DUMMY_STATE */);
  TRACE_POP
}

/*
equation index: 212
type: SIMPLE_ASSIGN
and2.u2 = $outputAlias_SM_Start_Torque_out > greaterThreshold2.threshold
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_212(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,212};
  modelica_boolean tmp13;
  tmp13 = Greater((data->localData[0]->realVars[77] /* $outputAlias_SM_Start_Torque_out DUMMY_STATE */),(data->simulationInfo->realParameter[58] /* greaterThreshold2.threshold PARAM */));
  (data->localData[0]->booleanVars[2] /* and2.u2 DISCRETE */) = tmp13;
  TRACE_POP
}

/*
equation index: 213
type: SIMPLE_ASSIGN
$outputAlias_SM_Speed_Out = ServoMotorVoltage.offset + (if time < ServoMotorVoltage.startTime then 0.0 else if time < ServoMotorVoltage.startTime + ServoMotorVoltage.duration then (time - ServoMotorVoltage.startTime) * ServoMotorVoltage.height / ServoMotorVoltage.duration else ServoMotorVoltage.height)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_213(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,213};
  modelica_boolean tmp14;
  modelica_boolean tmp15;
  modelica_boolean tmp16;
  modelica_real tmp17;
  tmp14 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[12] /* ServoMotorVoltage.startTime PARAM */));
  tmp16 = (modelica_boolean)tmp14;
  if(tmp16)
  {
    tmp17 = 0.0;
  }
  else
  {
    tmp15 = Less(data->localData[0]->timeValue,(data->simulationInfo->realParameter[12] /* ServoMotorVoltage.startTime PARAM */) + (data->simulationInfo->realParameter[9] /* ServoMotorVoltage.duration PARAM */));
    tmp17 = (tmp15?DIVISION_SIM((data->localData[0]->timeValue - (data->simulationInfo->realParameter[12] /* ServoMotorVoltage.startTime PARAM */)) * ((data->simulationInfo->realParameter[10] /* ServoMotorVoltage.height PARAM */)),(data->simulationInfo->realParameter[9] /* ServoMotorVoltage.duration PARAM */),"ServoMotorVoltage.duration",equationIndexes):(data->simulationInfo->realParameter[10] /* ServoMotorVoltage.height PARAM */));
  }
  (data->localData[0]->realVars[76] /* $outputAlias_SM_Speed_Out DUMMY_STATE */) = (data->simulationInfo->realParameter[11] /* ServoMotorVoltage.offset PARAM */) + tmp17;
  TRACE_POP
}

/*
equation index: 214
type: SIMPLE_ASSIGN
SM_Speed_Out = $outputAlias_SM_Speed_Out
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_214(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,214};
  (data->localData[0]->realVars[80] /* SM_Speed_Out variable */) = (data->localData[0]->realVars[76] /* $outputAlias_SM_Speed_Out DUMMY_STATE */);
  TRACE_POP
}

/*
equation index: 215
type: SIMPLE_ASSIGN
and2.u1 = $outputAlias_SM_Speed_Out > greaterThreshold1.threshold
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_215(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,215};
  modelica_boolean tmp18;
  tmp18 = Greater((data->localData[0]->realVars[76] /* $outputAlias_SM_Speed_Out DUMMY_STATE */),(data->simulationInfo->realParameter[57] /* greaterThreshold1.threshold PARAM */));
  (data->localData[0]->booleanVars[1] /* and2.u1 DISCRETE */) = tmp18;
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_637(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_638(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_628(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_629(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_630(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_631(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_466(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_465(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_461(DATA *data, threadData_t *threadData);


/*
equation index: 225
type: SIMPLE_ASSIGN
turbine1.setSpeed.phi = $START.turbine1.setSpeed.phi
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_225(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,225};
  (data->localData[0]->realVars[3] /* turbine1.setSpeed.phi STATE(1,turbine1.setSpeed.w) */) = (data->modelData->realVarsData[3] /* turbine1.setSpeed.phi STATE(1,turbine1.setSpeed.w) */).attribute .start;
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_489(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_490(DATA *data, threadData_t *threadData);


/*
equation index: 229
type: ALGORITHM

  assert(turbine1.div0protect.uMax >= turbine1.div0protect.uMin, "Limiter: Limits must be consistent. However, uMax (=" + String(turbine1.div0protect.uMax, 6, 0, true) + ") < uMin (=" + String(turbine1.div0protect.uMin, 6, 0, true) + ")");
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_229(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,229};
  modelica_boolean tmp19;
  static const MMC_DEFSTRINGLIT(tmp20,52,"Limiter: Limits must be consistent. However, uMax (=");
  modelica_string tmp21;
  modelica_metatype tmpMeta22;
  static const MMC_DEFSTRINGLIT(tmp23,11,") < uMin (=");
  modelica_metatype tmpMeta24;
  modelica_string tmp25;
  modelica_metatype tmpMeta26;
  modelica_metatype tmpMeta27;
  static int tmp28 = 0;
  {
    tmp19 = GreaterEq((data->simulationInfo->realParameter[108] /* turbine1.div0protect.uMax PARAM */),(data->simulationInfo->realParameter[109] /* turbine1.div0protect.uMin PARAM */));
    if(!tmp19)
    {
      tmp21 = modelica_real_to_modelica_string((data->simulationInfo->realParameter[108] /* turbine1.div0protect.uMax PARAM */), ((modelica_integer) 6), ((modelica_integer) 0), 1);
      tmpMeta22 = stringAppend(MMC_REFSTRINGLIT(tmp20),tmp21);
      tmpMeta24 = stringAppend(tmpMeta22,MMC_REFSTRINGLIT(tmp23));
      tmp25 = modelica_real_to_modelica_string((data->simulationInfo->realParameter[109] /* turbine1.div0protect.uMin PARAM */), ((modelica_integer) 6), ((modelica_integer) 0), 1);
      tmpMeta26 = stringAppend(tmpMeta24,tmp25);
      tmpMeta27 = stringAppend(tmpMeta26,(modelica_string) mmc_strings_len1[41]);
      {
        const char* assert_cond = "(turbine1.div0protect.uMax >= turbine1.div0protect.uMin)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Nonlinear.mo",19,9,20,65,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta27));
          data->simulationInfo->needToReThrow = 1;
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Nonlinear.mo",19,9,20,65,0};
          omc_assert_withEquationIndexes(threadData, info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta27));
        }
      }
    }
  }
  TRACE_POP
}

/*
equation index: 228
type: ALGORITHM

  assert(turbine1.torqueLimit.uMax >= turbine1.torqueLimit.uMin, "Limiter: Limits must be consistent. However, uMax (=" + String(turbine1.torqueLimit.uMax, 6, 0, true) + ") < uMin (=" + String(turbine1.torqueLimit.uMin, 6, 0, true) + ")");
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_228(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,228};
  modelica_boolean tmp29;
  static const MMC_DEFSTRINGLIT(tmp30,52,"Limiter: Limits must be consistent. However, uMax (=");
  modelica_string tmp31;
  modelica_metatype tmpMeta32;
  static const MMC_DEFSTRINGLIT(tmp33,11,") < uMin (=");
  modelica_metatype tmpMeta34;
  modelica_string tmp35;
  modelica_metatype tmpMeta36;
  modelica_metatype tmpMeta37;
  static int tmp38 = 0;
  {
    tmp29 = GreaterEq((data->simulationInfo->realParameter[149] /* turbine1.torqueLimit.uMax PARAM */),(data->simulationInfo->realParameter[150] /* turbine1.torqueLimit.uMin PARAM */));
    if(!tmp29)
    {
      tmp31 = modelica_real_to_modelica_string((data->simulationInfo->realParameter[149] /* turbine1.torqueLimit.uMax PARAM */), ((modelica_integer) 6), ((modelica_integer) 0), 1);
      tmpMeta32 = stringAppend(MMC_REFSTRINGLIT(tmp30),tmp31);
      tmpMeta34 = stringAppend(tmpMeta32,MMC_REFSTRINGLIT(tmp33));
      tmp35 = modelica_real_to_modelica_string((data->simulationInfo->realParameter[150] /* turbine1.torqueLimit.uMin PARAM */), ((modelica_integer) 6), ((modelica_integer) 0), 1);
      tmpMeta36 = stringAppend(tmpMeta34,tmp35);
      tmpMeta37 = stringAppend(tmpMeta36,(modelica_string) mmc_strings_len1[41]);
      {
        const char* assert_cond = "(turbine1.torqueLimit.uMax >= turbine1.torqueLimit.uMin)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Nonlinear.mo",19,9,20,65,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta37));
          data->simulationInfo->needToReThrow = 1;
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Nonlinear.mo",19,9,20,65,0};
          omc_assert_withEquationIndexes(threadData, info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta37));
        }
      }
    }
  }
  TRACE_POP
}
OMC_DISABLE_OPT
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionInitialEquations_0(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_1(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_2(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_3(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_4(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_5(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_6(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_467(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_462(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_460(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_459(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_11(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_12(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_469(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_479(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_480(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_481(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_482(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_487(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_488(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_20(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_21(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_22(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_23(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_24(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_25(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_26(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_27(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_28(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_29(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_30(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_31(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_32(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_33(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_34(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_35(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_36(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_37(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_38(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_39(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_40(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_41(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_42(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_43(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_44(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_501(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_46(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_505(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_506(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_507(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_508(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_51(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_492(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_53(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_54(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_55(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_516(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_517(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_509(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_510(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_511(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_512(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_515(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_493(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_64(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_494(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_495(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_67(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_68(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_69(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_70(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_71(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_474(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_73(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_483(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_484(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_485(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_486(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_468(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_79(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_80(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_81(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_502(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_476(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_504(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_120(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_561(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_562(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_563(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_564(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_565(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_566(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_567(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_571(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_129(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_130(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_568(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_570(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_569(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_574(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_135(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_576(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_577(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_558(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_139(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_579(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_141(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_578(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_584(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_585(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_581(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_146(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_556(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_148(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_184(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_622(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_623(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_187(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_625(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_189(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_627(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_191(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_192(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_193(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_194(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_195(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_196(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_197(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_198(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_199(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_200(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_201(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_202(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_203(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_204(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_205(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_206(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_207(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_208(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_209(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_210(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_211(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_212(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_213(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_214(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_215(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_637(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_638(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_628(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_629(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_630(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_631(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_466(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_465(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_461(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_225(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_489(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_490(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_229(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_228(data, threadData);
  TRACE_POP
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->discreteCall = 1;
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionInitialEquations_0(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_1(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_2(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_3(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_4(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_5(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_6(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_467(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_462(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_460(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_459(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_11(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_12(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_469(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_479(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_480(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_481(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_482(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_487(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_488(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_20(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_21(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_22(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_23(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_24(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_25(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_26(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_27(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_28(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_29(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_30(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_31(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_32(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_33(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_34(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_35(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_36(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_37(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_38(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_39(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_40(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_41(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_42(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_43(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_44(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_501(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_46(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_505(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_506(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_507(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_508(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_51(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_492(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_53(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_54(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_55(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_516(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_517(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_509(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_510(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_511(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_512(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_515(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_493(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_64(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_494(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_495(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_67(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_68(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_69(DATA *data, threadData_t *threadData);


/*
equation index: 299
type: SIMPLE_ASSIGN
turbine1.div0protect.y = turbine1.inertia.w
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_299(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,299};
  (data->localData[0]->realVars[166] /* turbine1.div0protect.y variable */) = (data->localData[0]->realVars[178] /* turbine1.inertia.w DUMMY_STATE */);
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_71(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_474(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_73(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_483(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_484(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_485(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_486(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_468(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_79(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_80(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_81(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_502(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_476(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_504(DATA *data, threadData_t *threadData);


void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_314(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_315(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_316(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_317(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_318(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_319(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_320(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_321(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_322(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_323(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_324(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_325(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_326(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_327(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_328(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_329(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_330(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_331(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_332(DATA*, threadData_t*);
/*
equation index: 349
indexNonlinear: 1
type: NONLINEAR

vars: {$DER.surgeTank.v}
eqns: {314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 324, 325, 326, 327, 328, 329, 330, 331, 332}
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_349(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,349};
  int retValue;
  if(ACTIVE_STREAM(LOG_DT))
  {
    infoStreamPrint(LOG_DT, 1, "Solving nonlinear system 349 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);
    messageClose(LOG_DT);
  }
  /* get old value */
  data->simulationInfo->nonlinearSystemData[1].nlsxOld[0] = (data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */);
  retValue = solve_nonlinear_system(data, threadData, 1);
  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,349};
    throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, indexes, "Solving non-linear system 349 failed at time=%.15g.\nFor more information please use -lv LOG_NLS.", data->localData[0]->timeValue);
  }
  /* write solution */
  (data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */) = data->simulationInfo->nonlinearSystemData[1].nlsx[0];
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_561(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_562(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_563(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_564(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_565(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_566(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_567(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_571(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_129(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_130(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_568(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_570(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_569(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_574(DATA *data, threadData_t *threadData);


/*
equation index: 364
type: SIMPLE_ASSIGN
turbine1.torque.tau = turbine1.torqueLimit.u
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_364(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,364};
  (data->localData[0]->realVars[191] /* turbine1.torque.tau variable */) = (data->localData[0]->realVars[192] /* turbine1.torqueLimit.u variable */);
  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_576(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_577(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_558(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_139(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_579(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_141(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_578(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_584(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_585(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_581(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_146(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_556(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_148(DATA *data, threadData_t *threadData);


/*
equation index: 413
type: LINEAR

<var>$DER.$DER.surgeTank.v</var>
<row>

</row>
<matrix>
</matrix>
*/
OMC_DISABLE_OPT
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_413(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,413};
  /* Linear equation system */
  int retValue;
  double aux_x[1] = { (data->localData[1]->realVars[21] /* der(der(surgeTank.v)) DUMMY_DER */) };
  if(ACTIVE_STREAM(LOG_DT))
  {
    infoStreamPrint(LOG_DT, 1, "Solving linear system 413 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);
    messageClose(LOG_DT);
  }
  
  retValue = solve_linear_system(data, threadData, 1, &aux_x[0]);
  
  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,413};
    throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, indexes, "Solving linear system 413 failed at time=%.15g.\nFor more information please use -lv LOG_LS.", data->localData[0]->timeValue);
  }
  /* write solution */
  (data->localData[0]->realVars[21] /* der(der(surgeTank.v)) DUMMY_DER */) = aux_x[0];

  TRACE_POP
}
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_622(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_623(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_187(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_625(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_189(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_627(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_191(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_192(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_193(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_194(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_195(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_196(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_197(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_198(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_199(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_200(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_201(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_202(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_203(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_204(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_205(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_206(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_207(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_208(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_209(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_210(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_211(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_212(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_213(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_214(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_215(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_637(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_638(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_628(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_629(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_630(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_631(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_466(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_465(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_461(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_225(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_489(DATA *data, threadData_t *threadData);

extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_490(DATA *data, threadData_t *threadData);

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionInitialEquations_lambda0(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->discreteCall = 1;
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_1(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_2(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_3(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_4(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_5(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_6(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_467(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_462(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_460(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_459(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_11(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_12(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_469(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_479(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_480(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_481(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_482(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_487(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_488(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_20(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_21(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_22(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_23(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_24(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_25(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_26(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_27(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_28(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_29(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_30(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_31(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_32(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_33(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_34(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_35(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_36(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_37(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_38(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_39(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_40(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_41(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_42(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_43(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_44(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_501(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_46(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_505(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_506(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_507(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_508(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_51(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_492(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_53(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_54(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_55(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_516(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_517(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_509(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_510(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_511(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_512(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_515(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_493(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_64(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_494(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_495(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_67(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_68(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_69(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_299(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_71(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_474(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_73(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_483(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_484(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_485(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_486(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_468(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_79(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_80(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_81(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_502(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_476(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_504(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_349(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_561(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_562(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_563(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_564(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_565(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_566(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_567(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_571(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_129(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_130(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_568(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_570(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_569(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_574(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_364(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_576(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_577(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_558(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_139(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_579(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_141(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_578(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_584(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_585(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_581(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_146(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_556(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_148(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_413(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_622(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_623(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_187(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_625(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_189(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_627(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_191(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_192(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_193(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_194(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_195(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_196(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_197(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_198(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_199(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_200(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_201(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_202(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_203(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_204(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_205(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_206(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_207(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_208(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_209(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_210(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_211(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_212(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_213(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_214(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_215(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_637(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_638(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_628(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_629(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_630(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_631(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_466(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_465(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_461(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_225(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_489(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_490(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionRemovedInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int *equationIndexes = NULL;
  double res = 0.0;

  res = (data->simulationInfo->realParameter[152] /* turbine1.w_0 PARAM */) - (data->localData[0]->realVars[178] /* turbine1.inertia.w DUMMY_STATE */);
  if(fabs(res) > 1e-5)
  {
    errorStreamPrint(LOG_INIT, 0, "The initialization problem is inconsistent due to the following equation: 0 != %g = turbine1.w_0 - turbine1.inertia.w", res);
    return 1;
  }
  res = (data->simulationInfo->realParameter[152] /* turbine1.w_0 PARAM */) - (data->localData[0]->realVars[178] /* turbine1.inertia.w DUMMY_STATE */);
  if(fabs(res) > 1e-5)
  {
    errorStreamPrint(LOG_INIT, 0, "The initialization problem is inconsistent due to the following equation: 0 != %g = turbine1.w_0 - turbine1.inertia.w", res);
    return 1;
  }
  
  TRACE_POP
  return 0;
}


#if defined(__cplusplus)
}
#endif

