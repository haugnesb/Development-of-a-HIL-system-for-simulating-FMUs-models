/* Asserts */
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_model.h"
#if defined(__cplusplus)
extern "C" {
#endif


/*
equation index: 831
type: ALGORITHM

  assert(surgeTank.m >= 0.0, "Variable violating min constraint: 0.0 <= surgeTank.m, has value: " + String(surgeTank.m, "g"));
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_831(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,831};
  modelica_boolean tmp0;
  static const MMC_DEFSTRINGLIT(tmp1,66,"Variable violating min constraint: 0.0 <= surgeTank.m, has value: ");
  modelica_string tmp2;
  modelica_metatype tmpMeta3;
  static int tmp4 = 0;
  if(!tmp4)
  {
    tmp0 = GreaterEq((data->localData[0]->realVars[2] /* surgeTank.m STATE(1,surgeTank.mdot) */),0.0);
    if(!tmp0)
    {
      tmp2 = modelica_real_to_modelica_string_format((data->localData[0]->realVars[2] /* surgeTank.m STATE(1,surgeTank.mdot) */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta3 = stringAppend(MMC_REFSTRINGLIT(tmp1),tmp2);
      {
        const char* assert_cond = "(surgeTank.m >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",40,3,40,25,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta3));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",40,3,40,25,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta3));
        }
      }
      tmp4 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 832
type: ALGORITHM

  assert(surgeTank.h >= 0.0, "Variable violating min constraint: 0.0 <= surgeTank.h, has value: " + String(surgeTank.h, "g"));
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_832(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,832};
  modelica_boolean tmp5;
  static const MMC_DEFSTRINGLIT(tmp6,66,"Variable violating min constraint: 0.0 <= surgeTank.h, has value: ");
  modelica_string tmp7;
  modelica_metatype tmpMeta8;
  static int tmp9 = 0;
  if(!tmp9)
  {
    tmp5 = GreaterEq((data->localData[0]->realVars[148] /* surgeTank.h variable */),0.0);
    if(!tmp5)
    {
      tmp7 = modelica_real_to_modelica_string_format((data->localData[0]->realVars[148] /* surgeTank.h variable */), (modelica_string) mmc_strings_len1[103]);
      tmpMeta8 = stringAppend(MMC_REFSTRINGLIT(tmp6),tmp7);
      {
        const char* assert_cond = "(surgeTank.h >= 0.0)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",57,3,57,60,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta8));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/SurgeTank.mo",57,3,57,60,0};
          omc_assert_warning_withEquationIndexes(info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta8));
        }
      }
      tmp9 = 1;
    }
  }
  TRACE_POP
}
/* function to check assert after a step is done */
OMC_DISABLE_OPT
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_checkForAsserts(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_831(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_832(data, threadData);
  
  TRACE_POP
  return 0;
}

#if defined(__cplusplus)
}
#endif

