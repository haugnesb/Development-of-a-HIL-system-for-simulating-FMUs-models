/* Non Linear Systems */
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_model.h"
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_12jac.h"
#include "simulation/jacobian_util.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* inner equations */

/*
equation index: 85
type: SIMPLE_ASSIGN
$DER.surgeTank.M = surgeTank.m * $DER.surgeTank.v + surgeTank.mdot * surgeTank.v
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_85(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,85};
  (data->localData[0]->realVars[51] /* der(surgeTank.M) DUMMY_DER */) = ((data->localData[0]->realVars[2] /* surgeTank.m STATE(1,surgeTank.mdot) */)) * ((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)) + ((data->localData[0]->realVars[151] /* surgeTank.mdot DUMMY_STATE */)) * ((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 86
type: SIMPLE_ASSIGN
surgeTank.F = $DER.surgeTank.M - surgeTank.Mdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_86(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,86};
  (data->localData[0]->realVars[140] /* surgeTank.F DUMMY_STATE */) = (data->localData[0]->realVars[51] /* der(surgeTank.M) DUMMY_DER */) - (data->localData[0]->realVars[145] /* surgeTank.Mdot DUMMY_STATE */);
  TRACE_POP
}
/*
equation index: 87
type: SIMPLE_ASSIGN
surgeTank.F_p = surgeTank.F - ((-surgeTank.F_f) - surgeTank.F_g)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_87(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,87};
  (data->localData[0]->realVars[143] /* surgeTank.F_p DUMMY_STATE */) = (data->localData[0]->realVars[140] /* surgeTank.F DUMMY_STATE */) - ((-(data->localData[0]->realVars[141] /* surgeTank.F_f DUMMY_STATE */)) - (data->localData[0]->realVars[142] /* surgeTank.F_g DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 88
type: SIMPLE_ASSIGN
intake.p_o = data.p_a + surgeTank.F_p / surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_88(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,88};
  (data->localData[0]->realVars[116] /* intake.p_o DUMMY_STATE */) = (data->simulationInfo->realParameter[45] /* data.p_a PARAM */) + DIVISION_SIM((data->localData[0]->realVars[143] /* surgeTank.F_p DUMMY_STATE */),(data->localData[0]->realVars[138] /* surgeTank.A variable */),"surgeTank.A",equationIndexes);
  TRACE_POP
}
/*
equation index: 89
type: SIMPLE_ASSIGN
$DER.intake.M = data.rho * intake.Vdot ^ 2.0 * (1.0 / intake.A_i + (-1.0) / intake.A_o) + intake.p_i * intake.A_i + intake.m * data.g * intake.cos_theta - intake.F_f - intake.p_o * intake.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_89(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,89};
  modelica_real tmp0;
  tmp0 = (data->localData[0]->realVars[110] /* intake.Vdot DUMMY_STATE */);
  (data->localData[0]->realVars[5] /* der(intake.M) STATE_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((tmp0 * tmp0)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[106] /* intake.A_i variable */),"intake.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[107] /* intake.A_o variable */),"intake.A_o",equationIndexes))) + ((data->localData[0]->realVars[115] /* intake.p_i variable */)) * ((data->localData[0]->realVars[106] /* intake.A_i variable */)) + ((data->localData[0]->realVars[113] /* intake.m variable */)) * (((data->simulationInfo->realParameter[42] /* data.g PARAM */)) * ((data->localData[0]->realVars[111] /* intake.cos_theta variable */))) - (data->localData[0]->realVars[109] /* intake.F_f DUMMY_STATE */) - (((data->localData[0]->realVars[116] /* intake.p_o DUMMY_STATE */)) * ((data->localData[0]->realVars[107] /* intake.A_o variable */)));
  TRACE_POP
}
/*
equation index: 90
type: SIMPLE_ASSIGN
$DER.intake.Vdot = $DER.intake.M / (data.rho * intake.L)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_90(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,90};
  (data->localData[0]->realVars[38] /* der(intake.Vdot) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[5] /* der(intake.M) STATE_DER */),((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->simulationInfo->realParameter[62] /* intake.L PARAM */)),"data.rho * intake.L",equationIndexes);
  TRACE_POP
}
/*
equation index: 91
type: SIMPLE_ASSIGN
$DER.surgeTank.Vdot = $DER.surgeTank.v * surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_91(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,91};
  (data->localData[0]->realVars[53] /* der(surgeTank.Vdot) DUMMY_DER */) = ((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)) * ((data->localData[0]->realVars[138] /* surgeTank.A variable */));
  TRACE_POP
}
/*
equation index: 92
type: SIMPLE_ASSIGN
$DER.surgeTank.mdot = data.rho * $DER.surgeTank.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_92(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,92};
  (data->localData[0]->realVars[55] /* der(surgeTank.mdot) DUMMY_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->localData[0]->realVars[53] /* der(surgeTank.Vdot) DUMMY_DER */));
  TRACE_POP
}
/*
equation index: 93
type: SIMPLE_ASSIGN
$DER.intake.mdot = $DER.intake.Vdot * data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_93(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,93};
  (data->localData[0]->realVars[39] /* der(intake.mdot) DUMMY_DER */) = ((data->localData[0]->realVars[38] /* der(intake.Vdot) DUMMY_DER */)) * ((data->simulationInfo->realParameter[47] /* data.rho PARAM */));
  TRACE_POP
}
/*
equation index: 94
type: SIMPLE_ASSIGN
$DER.discharge.mdot = $DER.intake.mdot - $DER.surgeTank.mdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_94(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,94};
  (data->localData[0]->realVars[31] /* der(discharge.mdot) DUMMY_DER */) = (data->localData[0]->realVars[39] /* der(intake.mdot) DUMMY_DER */) - (data->localData[0]->realVars[55] /* der(surgeTank.mdot) DUMMY_DER */);
  TRACE_POP
}
/*
equation index: 95
type: SIMPLE_ASSIGN
$DER.discharge.Vdot = $DER.discharge.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_95(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,95};
  (data->localData[0]->realVars[30] /* der(discharge.Vdot) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[31] /* der(discharge.mdot) DUMMY_DER */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes);
  TRACE_POP
}
/*
equation index: 96
type: SIMPLE_ASSIGN
$DER.discharge.M = data.rho * discharge.L * $DER.discharge.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_96(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,96};
  (data->localData[0]->realVars[29] /* der(discharge.M) DUMMY_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[51] /* discharge.L PARAM */)) * ((data->localData[0]->realVars[30] /* der(discharge.Vdot) DUMMY_DER */)));
  TRACE_POP
}
/*
equation index: 97
type: SIMPLE_ASSIGN
discharge.p_i = ($DER.discharge.M - (data.rho * discharge.Vdot ^ 2.0 * (1.0 / discharge.A_i + (-1.0) / discharge.A_o) + discharge.m * data.g * discharge.cos_theta - discharge.F_f - discharge.p_o * discharge.A_o)) / discharge.A_i
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_97(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,97};
  modelica_real tmp0;
  tmp0 = (data->localData[0]->realVars[94] /* discharge.Vdot DUMMY_STATE */);
  (data->localData[0]->realVars[99] /* discharge.p_i DUMMY_STATE */) = DIVISION_SIM((data->localData[0]->realVars[29] /* der(discharge.M) DUMMY_DER */) - (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((tmp0 * tmp0)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[89] /* discharge.A_i variable */),"discharge.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[90] /* discharge.A_o variable */),"discharge.A_o",equationIndexes))) + ((data->localData[0]->realVars[97] /* discharge.m variable */)) * (((data->simulationInfo->realParameter[42] /* data.g PARAM */)) * ((data->localData[0]->realVars[95] /* discharge.cos_theta variable */))) - (data->localData[0]->realVars[92] /* discharge.F_f DUMMY_STATE */) - (((data->localData[0]->realVars[100] /* discharge.p_o variable */)) * ((data->localData[0]->realVars[90] /* discharge.A_o variable */)))),(data->localData[0]->realVars[89] /* discharge.A_i variable */),"discharge.A_i",equationIndexes);
  TRACE_POP
}
/*
equation index: 98
type: SIMPLE_ASSIGN
$DER.penstock.Vdot = $DER.discharge.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_98(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,98};
  (data->localData[0]->realVars[43] /* der(penstock.Vdot) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[31] /* der(discharge.mdot) DUMMY_DER */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes);
  TRACE_POP
}
/*
equation index: 99
type: SIMPLE_ASSIGN
$DER.penstock.M = data.rho * penstock.L * $DER.penstock.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_99(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,99};
  (data->localData[0]->realVars[6] /* der(penstock.M) STATE_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[69] /* penstock.L PARAM */)) * ((data->localData[0]->realVars[43] /* der(penstock.Vdot) DUMMY_DER */)));
  TRACE_POP
}
/*
equation index: 100
type: SIMPLE_ASSIGN
penstock.p_o = (data.rho * penstock.Vdot ^ 2.0 * (1.0 / penstock.A_i + (-1.0) / penstock.A_o) + intake.p_o * penstock.A_i + penstock.m * data.g * penstock.cos_theta - penstock.F_f - $DER.penstock.M) / penstock.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_100(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,100};
  modelica_real tmp0;
  tmp0 = (data->localData[0]->realVars[123] /* penstock.Vdot DUMMY_STATE */);
  (data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) = DIVISION_SIM(((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((tmp0 * tmp0)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[119] /* penstock.A_i variable */),"penstock.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[120] /* penstock.A_o variable */),"penstock.A_o",equationIndexes))) + ((data->localData[0]->realVars[116] /* intake.p_o DUMMY_STATE */)) * ((data->localData[0]->realVars[119] /* penstock.A_i variable */)) + ((data->localData[0]->realVars[126] /* penstock.m variable */)) * (((data->simulationInfo->realParameter[42] /* data.g PARAM */)) * ((data->localData[0]->realVars[124] /* penstock.cos_theta variable */))) - (data->localData[0]->realVars[122] /* penstock.F_f DUMMY_STATE */) - (data->localData[0]->realVars[6] /* der(penstock.M) STATE_DER */),(data->localData[0]->realVars[120] /* penstock.A_o variable */),"penstock.A_o",equationIndexes);
  TRACE_POP
}
/*
equation index: 101
type: SIMPLE_ASSIGN
turbine1.Vdot = if turbine1.WaterCompress then discharge.mdot / (data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) else discharge.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_101(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,101};
  (data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */) = ((data->simulationInfo->booleanParameter[15] /* turbine1.WaterCompress PARAM */)?DIVISION_SIM((data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */),((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (1.0 + ((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->simulationInfo->realParameter[45] /* data.p_a PARAM */))),"data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))",equationIndexes):DIVISION_SIM((data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes));
  TRACE_POP
}
/*
equation index: 102
type: SIMPLE_ASSIGN
turbine1.dp = turbine1.Vdot ^ 2.0 * data.p_a / (turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_102(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,102};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = (data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */);
  tmp1 = ((data->localData[0]->realVars[162] /* turbine1.C_v_ variable */)) * ((data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */));
  (data->localData[0]->realVars[167] /* turbine1.dp DUMMY_STATE */) = ((tmp0 * tmp0)) * (DIVISION_SIM((data->simulationInfo->realParameter[45] /* data.p_a PARAM */),(tmp1 * tmp1),"(turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0",equationIndexes));
  TRACE_POP
}

void residualFunc120(RESIDUAL_USERDATA* userData, const double* xloc, double* res, const int* iflag)
{
  TRACE_PUSH
  DATA *data = userData->data;
  threadData_t *threadData = userData->threadData;
  const int equationIndexes[2] = {1,120};
  int i,j;
  /* iteration variables */
  for (i=0; i<1; i++) {
    if (isinf(xloc[i]) || isnan(xloc[i])) {
      errorStreamPrint(LOG_NLS, 0, "residualFunc120: Iteration variable xloc[%i] is nan.", i);
      for (j=0; j<1; j++) {
        res[j] = NAN;
      }
      throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, equationIndexes, "residualFunc120 failed at time=%.15g.\nFor more information please use -lv LOG_NLS.", data->localData[0]->timeValue);
      return;
    }
  }
  (data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */) = xloc[0];
  /* backup outputs */
  /* pre body */
  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_85(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_86(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_87(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_88(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_89(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_90(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_91(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_92(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_93(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_94(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_95(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_96(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_97(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_98(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_99(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_100(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_101(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_102(data, threadData);
  /* body */
  res[0] = (data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) + (-(data->localData[0]->realVars[99] /* discharge.p_i DUMMY_STATE */)) - (data->localData[0]->realVars[167] /* turbine1.dp DUMMY_STATE */);
  /* restore known outputs */
  TRACE_POP
}

OMC_DISABLE_OPT
void initializeSparsePatternNLS120(NONLINEAR_SYSTEM_DATA* inSysData)
{
  int i=0;
  const int colPtrIndex[1+1] = {0,1};
  const int rowIndex[1] = {0};
  /* sparsity pattern available */
  inSysData->isPatternAvailable = TRUE;
  inSysData->sparsePattern = allocSparsePattern(1, 1, 1);
  
  /* write lead index of compressed sparse column */
  memcpy(inSysData->sparsePattern->leadindex, colPtrIndex, (1+1)*sizeof(unsigned int));
  
  for(i=2;i<1+1;++i)
    inSysData->sparsePattern->leadindex[i] += inSysData->sparsePattern->leadindex[i-1];
  
  /* call sparse index */
  memcpy(inSysData->sparsePattern->index, rowIndex, 1*sizeof(unsigned int));
  
  /* write color array */
  /* color 1 with 1 columns */
  const int indices_1[1] = {0};
  for(i=0; i<1; i++)
    inSysData->sparsePattern->colorCols[indices_1[i]] = 1;
}
OMC_DISABLE_OPT
void initializeNonlinearPatternNLS120(NONLINEAR_SYSTEM_DATA* inSysData)
{
  int i=0;
  inSysData->nonlinearPattern = (NONLINEAR_PATTERN*) malloc(sizeof(NONLINEAR_PATTERN));
  inSysData->nonlinearPattern->numberOfVars = 1;
  inSysData->nonlinearPattern->numberOfEqns = 1;
  inSysData->nonlinearPattern->numberOfNonlinear = 0;
  inSysData->nonlinearPattern->indexVar = (unsigned int*) malloc((1+1)*sizeof(unsigned int));
  inSysData->nonlinearPattern->indexEqn = (unsigned int*) malloc((1+1)*sizeof(unsigned int));
  inSysData->nonlinearPattern->columns = (unsigned int*) malloc(0*sizeof(unsigned int));
  inSysData->nonlinearPattern->rows = (unsigned int*) malloc(0*sizeof(unsigned int));
  /* initialize and accumulate index vectors */
  const int index_var[1+1] = {0,0};
  const int index_eqn[1+1] = {0,0};
  memcpy(inSysData->nonlinearPattern->indexVar, index_var, (1+1)*sizeof(unsigned int));
  memcpy(inSysData->nonlinearPattern->indexEqn, index_eqn, (1+1)*sizeof(unsigned int));
  for(i=2;i<1+1;++i)
    inSysData->nonlinearPattern->indexVar[i] += inSysData->nonlinearPattern->indexVar[i-1];
  for(i=2;i<1+1;++i)
    inSysData->nonlinearPattern->indexEqn[i] += inSysData->nonlinearPattern->indexEqn[i-1];
  /* initialize columns and rows */
  const int columns[0] = {};
  const int rows[0] = {};
  memcpy(inSysData->nonlinearPattern->columns, columns, 0*sizeof(unsigned int));
  memcpy(inSysData->nonlinearPattern->rows, rows, 0*sizeof(unsigned int));
}

OMC_DISABLE_OPT
void initializeStaticDataNLS120(DATA* data, threadData_t *threadData, NONLINEAR_SYSTEM_DATA *sysData, modelica_boolean initSparsePattern, modelica_boolean initNonlinearPattern)
{
  int i=0;
  /* static nls data for der(surgeTank.v) */
  sysData->nominal[i] = data->modelData->realVarsData[56].attribute /* der(surgeTank.v) */.nominal;
  sysData->min[i]     = data->modelData->realVarsData[56].attribute /* der(surgeTank.v) */.min;
  sysData->max[i++]   = data->modelData->realVarsData[56].attribute /* der(surgeTank.v) */.max;
  /* initial sparse pattern */
  if (initSparsePattern) {
    initializeSparsePatternNLS120(sysData);
  }
  if (initNonlinearPattern) {
    initializeNonlinearPatternNLS120(sysData);
  }
}

OMC_DISABLE_OPT
void getIterationVarsNLS120(DATA* data, double *array)
{
  array[0] = (data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */);
}


/* inner equations */

/*
equation index: 314
type: SIMPLE_ASSIGN
$DER.surgeTank.M = surgeTank.m * $DER.surgeTank.v + surgeTank.mdot * surgeTank.v
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_314(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,314};
  (data->localData[0]->realVars[51] /* der(surgeTank.M) DUMMY_DER */) = ((data->localData[0]->realVars[2] /* surgeTank.m STATE(1,surgeTank.mdot) */)) * ((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)) + ((data->localData[0]->realVars[151] /* surgeTank.mdot DUMMY_STATE */)) * ((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 315
type: SIMPLE_ASSIGN
surgeTank.F = $DER.surgeTank.M - surgeTank.Mdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_315(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,315};
  (data->localData[0]->realVars[140] /* surgeTank.F DUMMY_STATE */) = (data->localData[0]->realVars[51] /* der(surgeTank.M) DUMMY_DER */) - (data->localData[0]->realVars[145] /* surgeTank.Mdot DUMMY_STATE */);
  TRACE_POP
}
/*
equation index: 316
type: SIMPLE_ASSIGN
surgeTank.F_p = surgeTank.F - ((-surgeTank.F_f) - surgeTank.F_g)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_316(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,316};
  (data->localData[0]->realVars[143] /* surgeTank.F_p DUMMY_STATE */) = (data->localData[0]->realVars[140] /* surgeTank.F DUMMY_STATE */) - ((-(data->localData[0]->realVars[141] /* surgeTank.F_f DUMMY_STATE */)) - (data->localData[0]->realVars[142] /* surgeTank.F_g DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 317
type: SIMPLE_ASSIGN
intake.p_o = data.p_a + surgeTank.F_p / surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_317(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,317};
  (data->localData[0]->realVars[116] /* intake.p_o DUMMY_STATE */) = (data->simulationInfo->realParameter[45] /* data.p_a PARAM */) + DIVISION_SIM((data->localData[0]->realVars[143] /* surgeTank.F_p DUMMY_STATE */),(data->localData[0]->realVars[138] /* surgeTank.A variable */),"surgeTank.A",equationIndexes);
  TRACE_POP
}
/*
equation index: 318
type: SIMPLE_ASSIGN
$DER.intake.M = data.rho * intake.Vdot ^ 2.0 * (1.0 / intake.A_i + (-1.0) / intake.A_o) + intake.p_i * intake.A_i + intake.m * data.g * intake.cos_theta - intake.F_f - intake.p_o * intake.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_318(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,318};
  modelica_real tmp0;
  tmp0 = (data->localData[0]->realVars[110] /* intake.Vdot DUMMY_STATE */);
  (data->localData[0]->realVars[5] /* der(intake.M) STATE_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((tmp0 * tmp0)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[106] /* intake.A_i variable */),"intake.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[107] /* intake.A_o variable */),"intake.A_o",equationIndexes))) + ((data->localData[0]->realVars[115] /* intake.p_i variable */)) * ((data->localData[0]->realVars[106] /* intake.A_i variable */)) + ((data->localData[0]->realVars[113] /* intake.m variable */)) * (((data->simulationInfo->realParameter[42] /* data.g PARAM */)) * ((data->localData[0]->realVars[111] /* intake.cos_theta variable */))) - (data->localData[0]->realVars[109] /* intake.F_f DUMMY_STATE */) - (((data->localData[0]->realVars[116] /* intake.p_o DUMMY_STATE */)) * ((data->localData[0]->realVars[107] /* intake.A_o variable */)));
  TRACE_POP
}
/*
equation index: 319
type: SIMPLE_ASSIGN
$DER.intake.Vdot = $DER.intake.M / (data.rho * intake.L)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_319(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,319};
  (data->localData[0]->realVars[38] /* der(intake.Vdot) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[5] /* der(intake.M) STATE_DER */),((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->simulationInfo->realParameter[62] /* intake.L PARAM */)),"data.rho * intake.L",equationIndexes);
  TRACE_POP
}
/*
equation index: 320
type: SIMPLE_ASSIGN
$DER.surgeTank.Vdot = $DER.surgeTank.v * surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_320(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,320};
  (data->localData[0]->realVars[53] /* der(surgeTank.Vdot) DUMMY_DER */) = ((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)) * ((data->localData[0]->realVars[138] /* surgeTank.A variable */));
  TRACE_POP
}
/*
equation index: 321
type: SIMPLE_ASSIGN
$DER.surgeTank.mdot = data.rho * $DER.surgeTank.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_321(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,321};
  (data->localData[0]->realVars[55] /* der(surgeTank.mdot) DUMMY_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->localData[0]->realVars[53] /* der(surgeTank.Vdot) DUMMY_DER */));
  TRACE_POP
}
/*
equation index: 322
type: SIMPLE_ASSIGN
$DER.intake.mdot = $DER.intake.Vdot * data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_322(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,322};
  (data->localData[0]->realVars[39] /* der(intake.mdot) DUMMY_DER */) = ((data->localData[0]->realVars[38] /* der(intake.Vdot) DUMMY_DER */)) * ((data->simulationInfo->realParameter[47] /* data.rho PARAM */));
  TRACE_POP
}
/*
equation index: 323
type: SIMPLE_ASSIGN
$DER.discharge.mdot = $DER.intake.mdot - $DER.surgeTank.mdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_323(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,323};
  (data->localData[0]->realVars[31] /* der(discharge.mdot) DUMMY_DER */) = (data->localData[0]->realVars[39] /* der(intake.mdot) DUMMY_DER */) - (data->localData[0]->realVars[55] /* der(surgeTank.mdot) DUMMY_DER */);
  TRACE_POP
}
/*
equation index: 324
type: SIMPLE_ASSIGN
$DER.discharge.Vdot = $DER.discharge.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_324(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,324};
  (data->localData[0]->realVars[30] /* der(discharge.Vdot) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[31] /* der(discharge.mdot) DUMMY_DER */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes);
  TRACE_POP
}
/*
equation index: 325
type: SIMPLE_ASSIGN
$DER.discharge.M = data.rho * discharge.L * $DER.discharge.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_325(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,325};
  (data->localData[0]->realVars[29] /* der(discharge.M) DUMMY_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[51] /* discharge.L PARAM */)) * ((data->localData[0]->realVars[30] /* der(discharge.Vdot) DUMMY_DER */)));
  TRACE_POP
}
/*
equation index: 326
type: SIMPLE_ASSIGN
discharge.p_i = ($DER.discharge.M - (data.rho * discharge.Vdot ^ 2.0 * (1.0 / discharge.A_i + (-1.0) / discharge.A_o) + discharge.m * data.g * discharge.cos_theta - discharge.F_f - discharge.p_o * discharge.A_o)) / discharge.A_i
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_326(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,326};
  modelica_real tmp0;
  tmp0 = (data->localData[0]->realVars[94] /* discharge.Vdot DUMMY_STATE */);
  (data->localData[0]->realVars[99] /* discharge.p_i DUMMY_STATE */) = DIVISION_SIM((data->localData[0]->realVars[29] /* der(discharge.M) DUMMY_DER */) - (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((tmp0 * tmp0)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[89] /* discharge.A_i variable */),"discharge.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[90] /* discharge.A_o variable */),"discharge.A_o",equationIndexes))) + ((data->localData[0]->realVars[97] /* discharge.m variable */)) * (((data->simulationInfo->realParameter[42] /* data.g PARAM */)) * ((data->localData[0]->realVars[95] /* discharge.cos_theta variable */))) - (data->localData[0]->realVars[92] /* discharge.F_f DUMMY_STATE */) - (((data->localData[0]->realVars[100] /* discharge.p_o variable */)) * ((data->localData[0]->realVars[90] /* discharge.A_o variable */)))),(data->localData[0]->realVars[89] /* discharge.A_i variable */),"discharge.A_i",equationIndexes);
  TRACE_POP
}
/*
equation index: 327
type: SIMPLE_ASSIGN
$DER.penstock.Vdot = $DER.discharge.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_327(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,327};
  (data->localData[0]->realVars[43] /* der(penstock.Vdot) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[31] /* der(discharge.mdot) DUMMY_DER */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes);
  TRACE_POP
}
/*
equation index: 328
type: SIMPLE_ASSIGN
$DER.penstock.M = data.rho * penstock.L * $DER.penstock.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_328(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,328};
  (data->localData[0]->realVars[6] /* der(penstock.M) STATE_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[69] /* penstock.L PARAM */)) * ((data->localData[0]->realVars[43] /* der(penstock.Vdot) DUMMY_DER */)));
  TRACE_POP
}
/*
equation index: 329
type: SIMPLE_ASSIGN
penstock.p_o = (data.rho * penstock.Vdot ^ 2.0 * (1.0 / penstock.A_i + (-1.0) / penstock.A_o) + intake.p_o * penstock.A_i + penstock.m * data.g * penstock.cos_theta - penstock.F_f - $DER.penstock.M) / penstock.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_329(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,329};
  modelica_real tmp0;
  tmp0 = (data->localData[0]->realVars[123] /* penstock.Vdot DUMMY_STATE */);
  (data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) = DIVISION_SIM(((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((tmp0 * tmp0)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[119] /* penstock.A_i variable */),"penstock.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[120] /* penstock.A_o variable */),"penstock.A_o",equationIndexes))) + ((data->localData[0]->realVars[116] /* intake.p_o DUMMY_STATE */)) * ((data->localData[0]->realVars[119] /* penstock.A_i variable */)) + ((data->localData[0]->realVars[126] /* penstock.m variable */)) * (((data->simulationInfo->realParameter[42] /* data.g PARAM */)) * ((data->localData[0]->realVars[124] /* penstock.cos_theta variable */))) - (data->localData[0]->realVars[122] /* penstock.F_f DUMMY_STATE */) - (data->localData[0]->realVars[6] /* der(penstock.M) STATE_DER */),(data->localData[0]->realVars[120] /* penstock.A_o variable */),"penstock.A_o",equationIndexes);
  TRACE_POP
}
/*
equation index: 330
type: SIMPLE_ASSIGN
turbine1.Vdot = if turbine1.WaterCompress then discharge.mdot / (data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) else discharge.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_330(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,330};
  (data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */) = ((data->simulationInfo->booleanParameter[15] /* turbine1.WaterCompress PARAM */)?DIVISION_SIM((data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */),((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (1.0 + ((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->simulationInfo->realParameter[45] /* data.p_a PARAM */))),"data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))",equationIndexes):DIVISION_SIM((data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes));
  TRACE_POP
}
/*
equation index: 331
type: SIMPLE_ASSIGN
turbine1.dp = turbine1.Vdot ^ 2.0 * data.p_a / (turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_331(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,331};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = (data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */);
  tmp1 = ((data->localData[0]->realVars[162] /* turbine1.C_v_ variable */)) * ((data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */));
  (data->localData[0]->realVars[167] /* turbine1.dp DUMMY_STATE */) = ((tmp0 * tmp0)) * (DIVISION_SIM((data->simulationInfo->realParameter[45] /* data.p_a PARAM */),(tmp1 * tmp1),"(turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0",equationIndexes));
  TRACE_POP
}

void residualFunc349(RESIDUAL_USERDATA* userData, const double* xloc, double* res, const int* iflag)
{
  TRACE_PUSH
  DATA *data = userData->data;
  threadData_t *threadData = userData->threadData;
  const int equationIndexes[2] = {1,349};
  int i,j;
  /* iteration variables */
  for (i=0; i<1; i++) {
    if (isinf(xloc[i]) || isnan(xloc[i])) {
      errorStreamPrint(LOG_NLS, 0, "residualFunc349: Iteration variable xloc[%i] is nan.", i);
      for (j=0; j<1; j++) {
        res[j] = NAN;
      }
      throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, equationIndexes, "residualFunc349 failed at time=%.15g.\nFor more information please use -lv LOG_NLS.", data->localData[0]->timeValue);
      return;
    }
  }
  (data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */) = xloc[0];
  /* backup outputs */
  /* pre body */
  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_314(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_315(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_316(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_317(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_318(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_319(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_320(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_321(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_322(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_323(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_324(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_325(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_326(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_327(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_328(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_329(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_330(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_331(data, threadData);
  /* body */
  res[0] = (data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) + (-(data->localData[0]->realVars[99] /* discharge.p_i DUMMY_STATE */)) - (data->localData[0]->realVars[167] /* turbine1.dp DUMMY_STATE */);
  /* restore known outputs */
  TRACE_POP
}

OMC_DISABLE_OPT
void initializeSparsePatternNLS349(NONLINEAR_SYSTEM_DATA* inSysData)
{
  int i=0;
  const int colPtrIndex[1+1] = {0,1};
  const int rowIndex[1] = {0};
  /* sparsity pattern available */
  inSysData->isPatternAvailable = TRUE;
  inSysData->sparsePattern = allocSparsePattern(1, 1, 1);
  
  /* write lead index of compressed sparse column */
  memcpy(inSysData->sparsePattern->leadindex, colPtrIndex, (1+1)*sizeof(unsigned int));
  
  for(i=2;i<1+1;++i)
    inSysData->sparsePattern->leadindex[i] += inSysData->sparsePattern->leadindex[i-1];
  
  /* call sparse index */
  memcpy(inSysData->sparsePattern->index, rowIndex, 1*sizeof(unsigned int));
  
  /* write color array */
  /* color 1 with 1 columns */
  const int indices_1[1] = {0};
  for(i=0; i<1; i++)
    inSysData->sparsePattern->colorCols[indices_1[i]] = 1;
}
OMC_DISABLE_OPT
void initializeNonlinearPatternNLS349(NONLINEAR_SYSTEM_DATA* inSysData)
{
  int i=0;
  inSysData->nonlinearPattern = (NONLINEAR_PATTERN*) malloc(sizeof(NONLINEAR_PATTERN));
  inSysData->nonlinearPattern->numberOfVars = 1;
  inSysData->nonlinearPattern->numberOfEqns = 1;
  inSysData->nonlinearPattern->numberOfNonlinear = 0;
  inSysData->nonlinearPattern->indexVar = (unsigned int*) malloc((1+1)*sizeof(unsigned int));
  inSysData->nonlinearPattern->indexEqn = (unsigned int*) malloc((1+1)*sizeof(unsigned int));
  inSysData->nonlinearPattern->columns = (unsigned int*) malloc(0*sizeof(unsigned int));
  inSysData->nonlinearPattern->rows = (unsigned int*) malloc(0*sizeof(unsigned int));
  /* initialize and accumulate index vectors */
  const int index_var[1+1] = {0,0};
  const int index_eqn[1+1] = {0,0};
  memcpy(inSysData->nonlinearPattern->indexVar, index_var, (1+1)*sizeof(unsigned int));
  memcpy(inSysData->nonlinearPattern->indexEqn, index_eqn, (1+1)*sizeof(unsigned int));
  for(i=2;i<1+1;++i)
    inSysData->nonlinearPattern->indexVar[i] += inSysData->nonlinearPattern->indexVar[i-1];
  for(i=2;i<1+1;++i)
    inSysData->nonlinearPattern->indexEqn[i] += inSysData->nonlinearPattern->indexEqn[i-1];
  /* initialize columns and rows */
  const int columns[0] = {};
  const int rows[0] = {};
  memcpy(inSysData->nonlinearPattern->columns, columns, 0*sizeof(unsigned int));
  memcpy(inSysData->nonlinearPattern->rows, rows, 0*sizeof(unsigned int));
}

OMC_DISABLE_OPT
void initializeStaticDataNLS349(DATA* data, threadData_t *threadData, NONLINEAR_SYSTEM_DATA *sysData, modelica_boolean initSparsePattern, modelica_boolean initNonlinearPattern)
{
  int i=0;
  /* static nls data for der(surgeTank.v) */
  sysData->nominal[i] = data->modelData->realVarsData[56].attribute /* der(surgeTank.v) */.nominal;
  sysData->min[i]     = data->modelData->realVarsData[56].attribute /* der(surgeTank.v) */.min;
  sysData->max[i++]   = data->modelData->realVarsData[56].attribute /* der(surgeTank.v) */.max;
  /* initial sparse pattern */
  if (initSparsePattern) {
    initializeSparsePatternNLS349(sysData);
  }
  if (initNonlinearPattern) {
    initializeNonlinearPatternNLS349(sysData);
  }
}

OMC_DISABLE_OPT
void getIterationVarsNLS349(DATA* data, double *array)
{
  array[0] = (data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */);
}


/* inner equations */

/*
equation index: 519
type: SIMPLE_ASSIGN
$DER.surgeTank.M = surgeTank.m * $DER.surgeTank.v + surgeTank.mdot * surgeTank.v
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_519(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,519};
  (data->localData[0]->realVars[51] /* der(surgeTank.M) DUMMY_DER */) = ((data->localData[0]->realVars[2] /* surgeTank.m STATE(1,surgeTank.mdot) */)) * ((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)) + ((data->localData[0]->realVars[151] /* surgeTank.mdot DUMMY_STATE */)) * ((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 520
type: SIMPLE_ASSIGN
surgeTank.F = $DER.surgeTank.M - surgeTank.Mdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_520(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,520};
  (data->localData[0]->realVars[140] /* surgeTank.F DUMMY_STATE */) = (data->localData[0]->realVars[51] /* der(surgeTank.M) DUMMY_DER */) - (data->localData[0]->realVars[145] /* surgeTank.Mdot DUMMY_STATE */);
  TRACE_POP
}
/*
equation index: 521
type: SIMPLE_ASSIGN
surgeTank.F_p = surgeTank.F - ((-surgeTank.F_f) - surgeTank.F_g)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_521(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,521};
  (data->localData[0]->realVars[143] /* surgeTank.F_p DUMMY_STATE */) = (data->localData[0]->realVars[140] /* surgeTank.F DUMMY_STATE */) - ((-(data->localData[0]->realVars[141] /* surgeTank.F_f DUMMY_STATE */)) - (data->localData[0]->realVars[142] /* surgeTank.F_g DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 522
type: SIMPLE_ASSIGN
intake.p_o = data.p_a + surgeTank.F_p / surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_522(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,522};
  (data->localData[0]->realVars[116] /* intake.p_o DUMMY_STATE */) = (data->simulationInfo->realParameter[45] /* data.p_a PARAM */) + DIVISION_SIM((data->localData[0]->realVars[143] /* surgeTank.F_p DUMMY_STATE */),(data->localData[0]->realVars[138] /* surgeTank.A variable */),"surgeTank.A",equationIndexes);
  TRACE_POP
}
/*
equation index: 523
type: SIMPLE_ASSIGN
$DER.intake.M = data.rho * intake.Vdot ^ 2.0 * (1.0 / intake.A_i + (-1.0) / intake.A_o) + intake.p_i * intake.A_i + intake.m * data.g * intake.cos_theta - intake.F_f - intake.p_o * intake.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_523(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,523};
  modelica_real tmp0;
  tmp0 = (data->localData[0]->realVars[110] /* intake.Vdot DUMMY_STATE */);
  (data->localData[0]->realVars[5] /* der(intake.M) STATE_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((tmp0 * tmp0)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[106] /* intake.A_i variable */),"intake.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[107] /* intake.A_o variable */),"intake.A_o",equationIndexes))) + ((data->localData[0]->realVars[115] /* intake.p_i variable */)) * ((data->localData[0]->realVars[106] /* intake.A_i variable */)) + ((data->localData[0]->realVars[113] /* intake.m variable */)) * (((data->simulationInfo->realParameter[42] /* data.g PARAM */)) * ((data->localData[0]->realVars[111] /* intake.cos_theta variable */))) - (data->localData[0]->realVars[109] /* intake.F_f DUMMY_STATE */) - (((data->localData[0]->realVars[116] /* intake.p_o DUMMY_STATE */)) * ((data->localData[0]->realVars[107] /* intake.A_o variable */)));
  TRACE_POP
}
/*
equation index: 524
type: SIMPLE_ASSIGN
$DER.intake.Vdot = der(intake.M) / (data.rho * intake.L)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_524(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,524};
  (data->localData[0]->realVars[38] /* der(intake.Vdot) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[5] /* der(intake.M) STATE_DER */),((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->simulationInfo->realParameter[62] /* intake.L PARAM */)),"data.rho * intake.L",equationIndexes);
  TRACE_POP
}
/*
equation index: 525
type: SIMPLE_ASSIGN
$DER.intake.mdot = $DER.intake.Vdot * data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_525(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,525};
  (data->localData[0]->realVars[39] /* der(intake.mdot) DUMMY_DER */) = ((data->localData[0]->realVars[38] /* der(intake.Vdot) DUMMY_DER */)) * ((data->simulationInfo->realParameter[47] /* data.rho PARAM */));
  TRACE_POP
}
/*
equation index: 526
type: SIMPLE_ASSIGN
$DER.surgeTank.Vdot = $DER.surgeTank.v * surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_526(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,526};
  (data->localData[0]->realVars[53] /* der(surgeTank.Vdot) DUMMY_DER */) = ((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)) * ((data->localData[0]->realVars[138] /* surgeTank.A variable */));
  TRACE_POP
}
/*
equation index: 527
type: SIMPLE_ASSIGN
$DER.surgeTank.mdot = data.rho * $DER.surgeTank.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_527(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,527};
  (data->localData[0]->realVars[55] /* der(surgeTank.mdot) DUMMY_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->localData[0]->realVars[53] /* der(surgeTank.Vdot) DUMMY_DER */));
  TRACE_POP
}
/*
equation index: 528
type: SIMPLE_ASSIGN
$DER.discharge.mdot = $DER.intake.mdot - $DER.surgeTank.mdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_528(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,528};
  (data->localData[0]->realVars[31] /* der(discharge.mdot) DUMMY_DER */) = (data->localData[0]->realVars[39] /* der(intake.mdot) DUMMY_DER */) - (data->localData[0]->realVars[55] /* der(surgeTank.mdot) DUMMY_DER */);
  TRACE_POP
}
/*
equation index: 529
type: SIMPLE_ASSIGN
$DER.discharge.Vdot = $DER.discharge.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_529(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,529};
  (data->localData[0]->realVars[30] /* der(discharge.Vdot) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[31] /* der(discharge.mdot) DUMMY_DER */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes);
  TRACE_POP
}
/*
equation index: 530
type: SIMPLE_ASSIGN
$DER.discharge.M = data.rho * discharge.L * $DER.discharge.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_530(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,530};
  (data->localData[0]->realVars[29] /* der(discharge.M) DUMMY_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[51] /* discharge.L PARAM */)) * ((data->localData[0]->realVars[30] /* der(discharge.Vdot) DUMMY_DER */)));
  TRACE_POP
}
/*
equation index: 531
type: SIMPLE_ASSIGN
discharge.p_i = ($DER.discharge.M - (data.rho * discharge.Vdot ^ 2.0 * (1.0 / discharge.A_i + (-1.0) / discharge.A_o) + discharge.m * data.g * discharge.cos_theta - discharge.F_f - discharge.p_o * discharge.A_o)) / discharge.A_i
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_531(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,531};
  modelica_real tmp0;
  tmp0 = (data->localData[0]->realVars[94] /* discharge.Vdot DUMMY_STATE */);
  (data->localData[0]->realVars[99] /* discharge.p_i DUMMY_STATE */) = DIVISION_SIM((data->localData[0]->realVars[29] /* der(discharge.M) DUMMY_DER */) - (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((tmp0 * tmp0)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[89] /* discharge.A_i variable */),"discharge.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[90] /* discharge.A_o variable */),"discharge.A_o",equationIndexes))) + ((data->localData[0]->realVars[97] /* discharge.m variable */)) * (((data->simulationInfo->realParameter[42] /* data.g PARAM */)) * ((data->localData[0]->realVars[95] /* discharge.cos_theta variable */))) - (data->localData[0]->realVars[92] /* discharge.F_f DUMMY_STATE */) - (((data->localData[0]->realVars[100] /* discharge.p_o variable */)) * ((data->localData[0]->realVars[90] /* discharge.A_o variable */)))),(data->localData[0]->realVars[89] /* discharge.A_i variable */),"discharge.A_i",equationIndexes);
  TRACE_POP
}
/*
equation index: 532
type: SIMPLE_ASSIGN
$DER.penstock.Vdot = $DER.discharge.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_532(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,532};
  (data->localData[0]->realVars[43] /* der(penstock.Vdot) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[31] /* der(discharge.mdot) DUMMY_DER */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes);
  TRACE_POP
}
/*
equation index: 533
type: SIMPLE_ASSIGN
$DER.penstock.M = data.rho * penstock.L * $DER.penstock.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_533(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,533};
  (data->localData[0]->realVars[6] /* der(penstock.M) STATE_DER */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[69] /* penstock.L PARAM */)) * ((data->localData[0]->realVars[43] /* der(penstock.Vdot) DUMMY_DER */)));
  TRACE_POP
}
/*
equation index: 534
type: SIMPLE_ASSIGN
penstock.p_o = (data.rho * penstock.Vdot ^ 2.0 * (1.0 / penstock.A_i + (-1.0) / penstock.A_o) + intake.p_o * penstock.A_i + penstock.m * data.g * penstock.cos_theta - penstock.F_f - der(penstock.M)) / penstock.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_534(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,534};
  modelica_real tmp0;
  tmp0 = (data->localData[0]->realVars[123] /* penstock.Vdot DUMMY_STATE */);
  (data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) = DIVISION_SIM(((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((tmp0 * tmp0)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[119] /* penstock.A_i variable */),"penstock.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[120] /* penstock.A_o variable */),"penstock.A_o",equationIndexes))) + ((data->localData[0]->realVars[116] /* intake.p_o DUMMY_STATE */)) * ((data->localData[0]->realVars[119] /* penstock.A_i variable */)) + ((data->localData[0]->realVars[126] /* penstock.m variable */)) * (((data->simulationInfo->realParameter[42] /* data.g PARAM */)) * ((data->localData[0]->realVars[124] /* penstock.cos_theta variable */))) - (data->localData[0]->realVars[122] /* penstock.F_f DUMMY_STATE */) - (data->localData[0]->realVars[6] /* der(penstock.M) STATE_DER */),(data->localData[0]->realVars[120] /* penstock.A_o variable */),"penstock.A_o",equationIndexes);
  TRACE_POP
}
/*
equation index: 535
type: SIMPLE_ASSIGN
turbine1.Vdot = if turbine1.WaterCompress then discharge.mdot / (data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) else discharge.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_535(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,535};
  (data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */) = ((data->simulationInfo->booleanParameter[15] /* turbine1.WaterCompress PARAM */)?DIVISION_SIM((data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */),((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (1.0 + ((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->simulationInfo->realParameter[45] /* data.p_a PARAM */))),"data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))",equationIndexes):DIVISION_SIM((data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes));
  TRACE_POP
}
/*
equation index: 536
type: SIMPLE_ASSIGN
turbine1.dp = turbine1.Vdot ^ 2.0 * data.p_a / (turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_536(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,536};
  modelica_real tmp0;
  modelica_real tmp1;
  tmp0 = (data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */);
  tmp1 = ((data->localData[0]->realVars[162] /* turbine1.C_v_ variable */)) * ((data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */));
  (data->localData[0]->realVars[167] /* turbine1.dp DUMMY_STATE */) = ((tmp0 * tmp0)) * (DIVISION_SIM((data->simulationInfo->realParameter[45] /* data.p_a PARAM */),(tmp1 * tmp1),"(turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0",equationIndexes));
  TRACE_POP
}

void residualFunc554(RESIDUAL_USERDATA* userData, const double* xloc, double* res, const int* iflag)
{
  TRACE_PUSH
  DATA *data = userData->data;
  threadData_t *threadData = userData->threadData;
  const int equationIndexes[2] = {1,554};
  int i,j;
  /* iteration variables */
  for (i=0; i<1; i++) {
    if (isinf(xloc[i]) || isnan(xloc[i])) {
      errorStreamPrint(LOG_NLS, 0, "residualFunc554: Iteration variable xloc[%i] is nan.", i);
      for (j=0; j<1; j++) {
        res[j] = NAN;
      }
      throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, equationIndexes, "residualFunc554 failed at time=%.15g.\nFor more information please use -lv LOG_NLS.", data->localData[0]->timeValue);
      return;
    }
  }
  (data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */) = xloc[0];
  /* backup outputs */
  /* pre body */
  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_519(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_520(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_521(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_522(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_523(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_524(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_525(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_526(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_527(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_528(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_529(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_530(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_531(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_532(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_533(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_534(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_535(data, threadData);

  /* local constraints */
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_536(data, threadData);
  /* body */
  res[0] = (data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) + (-(data->localData[0]->realVars[99] /* discharge.p_i DUMMY_STATE */)) - (data->localData[0]->realVars[167] /* turbine1.dp DUMMY_STATE */);
  /* restore known outputs */
  TRACE_POP
}

OMC_DISABLE_OPT
void initializeSparsePatternNLS554(NONLINEAR_SYSTEM_DATA* inSysData)
{
  int i=0;
  const int colPtrIndex[1+1] = {0,1};
  const int rowIndex[1] = {0};
  /* sparsity pattern available */
  inSysData->isPatternAvailable = TRUE;
  inSysData->sparsePattern = allocSparsePattern(1, 1, 1);
  
  /* write lead index of compressed sparse column */
  memcpy(inSysData->sparsePattern->leadindex, colPtrIndex, (1+1)*sizeof(unsigned int));
  
  for(i=2;i<1+1;++i)
    inSysData->sparsePattern->leadindex[i] += inSysData->sparsePattern->leadindex[i-1];
  
  /* call sparse index */
  memcpy(inSysData->sparsePattern->index, rowIndex, 1*sizeof(unsigned int));
  
  /* write color array */
  /* color 1 with 1 columns */
  const int indices_1[1] = {0};
  for(i=0; i<1; i++)
    inSysData->sparsePattern->colorCols[indices_1[i]] = 1;
}
OMC_DISABLE_OPT
void initializeNonlinearPatternNLS554(NONLINEAR_SYSTEM_DATA* inSysData)
{
  int i=0;
  inSysData->nonlinearPattern = (NONLINEAR_PATTERN*) malloc(sizeof(NONLINEAR_PATTERN));
  inSysData->nonlinearPattern->numberOfVars = 1;
  inSysData->nonlinearPattern->numberOfEqns = 1;
  inSysData->nonlinearPattern->numberOfNonlinear = 0;
  inSysData->nonlinearPattern->indexVar = (unsigned int*) malloc((1+1)*sizeof(unsigned int));
  inSysData->nonlinearPattern->indexEqn = (unsigned int*) malloc((1+1)*sizeof(unsigned int));
  inSysData->nonlinearPattern->columns = (unsigned int*) malloc(0*sizeof(unsigned int));
  inSysData->nonlinearPattern->rows = (unsigned int*) malloc(0*sizeof(unsigned int));
  /* initialize and accumulate index vectors */
  const int index_var[1+1] = {0,0};
  const int index_eqn[1+1] = {0,0};
  memcpy(inSysData->nonlinearPattern->indexVar, index_var, (1+1)*sizeof(unsigned int));
  memcpy(inSysData->nonlinearPattern->indexEqn, index_eqn, (1+1)*sizeof(unsigned int));
  for(i=2;i<1+1;++i)
    inSysData->nonlinearPattern->indexVar[i] += inSysData->nonlinearPattern->indexVar[i-1];
  for(i=2;i<1+1;++i)
    inSysData->nonlinearPattern->indexEqn[i] += inSysData->nonlinearPattern->indexEqn[i-1];
  /* initialize columns and rows */
  const int columns[0] = {};
  const int rows[0] = {};
  memcpy(inSysData->nonlinearPattern->columns, columns, 0*sizeof(unsigned int));
  memcpy(inSysData->nonlinearPattern->rows, rows, 0*sizeof(unsigned int));
}

OMC_DISABLE_OPT
void initializeStaticDataNLS554(DATA* data, threadData_t *threadData, NONLINEAR_SYSTEM_DATA *sysData, modelica_boolean initSparsePattern, modelica_boolean initNonlinearPattern)
{
  int i=0;
  /* static nls data for der(surgeTank.v) */
  sysData->nominal[i] = data->modelData->realVarsData[56].attribute /* der(surgeTank.v) */.nominal;
  sysData->min[i]     = data->modelData->realVarsData[56].attribute /* der(surgeTank.v) */.min;
  sysData->max[i++]   = data->modelData->realVarsData[56].attribute /* der(surgeTank.v) */.max;
  /* initial sparse pattern */
  if (initSparsePattern) {
    initializeSparsePatternNLS554(sysData);
  }
  if (initNonlinearPattern) {
    initializeNonlinearPatternNLS554(sysData);
  }
}

OMC_DISABLE_OPT
void getIterationVarsNLS554(DATA* data, double *array)
{
  array[0] = (data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */);
}

/* Prototypes for the strict sets (Dynamic Tearing) */

/* Global constraints for the casual sets */
/* function initialize non-linear systems */
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialNonLinearSystem(int nNonLinearSystems, NONLINEAR_SYSTEM_DATA* nonLinearSystemData)
{
  
  nonLinearSystemData[2].equationIndex = 554;
  nonLinearSystemData[2].size = 1;
  nonLinearSystemData[2].homotopySupport = 0;
  nonLinearSystemData[2].mixedSystem = 0;
  nonLinearSystemData[2].residualFunc = residualFunc554;
  nonLinearSystemData[2].strictTearingFunctionCall = NULL;
  nonLinearSystemData[2].analyticalJacobianColumn = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacNLSJac190_column;
  nonLinearSystemData[2].initialAnalyticalJacobian = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianNLSJac190;
  nonLinearSystemData[2].jacobianIndex = 4 /*jacInx*/;
  nonLinearSystemData[2].initializeStaticNLSData = initializeStaticDataNLS554;
  nonLinearSystemData[2].getIterationVars = getIterationVarsNLS554;
  nonLinearSystemData[2].checkConstraints = NULL;
  
  
  nonLinearSystemData[1].equationIndex = 349;
  nonLinearSystemData[1].size = 1;
  nonLinearSystemData[1].homotopySupport = 0;
  nonLinearSystemData[1].mixedSystem = 0;
  nonLinearSystemData[1].residualFunc = residualFunc349;
  nonLinearSystemData[1].strictTearingFunctionCall = NULL;
  nonLinearSystemData[1].analyticalJacobianColumn = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacNLSJac188_column;
  nonLinearSystemData[1].initialAnalyticalJacobian = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianNLSJac188;
  nonLinearSystemData[1].jacobianIndex = 2 /*jacInx*/;
  nonLinearSystemData[1].initializeStaticNLSData = initializeStaticDataNLS349;
  nonLinearSystemData[1].getIterationVars = getIterationVarsNLS349;
  nonLinearSystemData[1].checkConstraints = NULL;
  
  
  nonLinearSystemData[0].equationIndex = 120;
  nonLinearSystemData[0].size = 1;
  nonLinearSystemData[0].homotopySupport = 0;
  nonLinearSystemData[0].mixedSystem = 0;
  nonLinearSystemData[0].residualFunc = residualFunc120;
  nonLinearSystemData[0].strictTearingFunctionCall = NULL;
  nonLinearSystemData[0].analyticalJacobianColumn = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacNLSJac186_column;
  nonLinearSystemData[0].initialAnalyticalJacobian = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianNLSJac186;
  nonLinearSystemData[0].jacobianIndex = 0 /*jacInx*/;
  nonLinearSystemData[0].initializeStaticNLSData = initializeStaticDataNLS120;
  nonLinearSystemData[0].getIterationVars = getIterationVarsNLS120;
  nonLinearSystemData[0].checkConstraints = NULL;
}

#if defined(__cplusplus)
}
#endif

