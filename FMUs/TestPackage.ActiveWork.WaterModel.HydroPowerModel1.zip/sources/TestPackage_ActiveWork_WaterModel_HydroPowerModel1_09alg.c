/* Algebraic */
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_model.h"

#ifdef __cplusplus
extern "C" {
#endif


/* forwarded equations */
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_459(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_460(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_461(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_462(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_463(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_464(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_465(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_466(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_467(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_470(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_471(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_472(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_473(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_474(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_475(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_478(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_481(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_484(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_485(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_488(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_489(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_490(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_493(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_496(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_502(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_503(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_506(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_507(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_510(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_513(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_514(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_515(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_518(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_555(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_556(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_557(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_558(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_559(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_560(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_561(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_562(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_563(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_564(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_565(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_566(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_567(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_568(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_569(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_570(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_571(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_572(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_573(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_574(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_575(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_576(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_577(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_578(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_579(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_580(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_581(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_582(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_583(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_584(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_585(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_621(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_622(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_623(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_624(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_625(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_626(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_627(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_628(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_629(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_630(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_631(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_632(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_633(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_634(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_635(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_636(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_637(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_638(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_639(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_640(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_641(DATA* data, threadData_t *threadData);

static void functionAlg_system0(DATA *data, threadData_t *threadData)
{
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_459(data, threadData);
    threadData->lastEquationSolved = 459;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_460(data, threadData);
    threadData->lastEquationSolved = 460;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_461(data, threadData);
    threadData->lastEquationSolved = 461;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_462(data, threadData);
    threadData->lastEquationSolved = 462;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_463(data, threadData);
    threadData->lastEquationSolved = 463;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_464(data, threadData);
    threadData->lastEquationSolved = 464;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_465(data, threadData);
    threadData->lastEquationSolved = 465;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_466(data, threadData);
    threadData->lastEquationSolved = 466;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_467(data, threadData);
    threadData->lastEquationSolved = 467;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_470(data, threadData);
    threadData->lastEquationSolved = 470;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_471(data, threadData);
    threadData->lastEquationSolved = 471;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_472(data, threadData);
    threadData->lastEquationSolved = 472;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_473(data, threadData);
    threadData->lastEquationSolved = 473;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_474(data, threadData);
    threadData->lastEquationSolved = 474;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_475(data, threadData);
    threadData->lastEquationSolved = 475;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_478(data, threadData);
    threadData->lastEquationSolved = 478;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_481(data, threadData);
    threadData->lastEquationSolved = 481;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_484(data, threadData);
    threadData->lastEquationSolved = 484;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_485(data, threadData);
    threadData->lastEquationSolved = 485;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_488(data, threadData);
    threadData->lastEquationSolved = 488;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_489(data, threadData);
    threadData->lastEquationSolved = 489;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_490(data, threadData);
    threadData->lastEquationSolved = 490;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_493(data, threadData);
    threadData->lastEquationSolved = 493;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_496(data, threadData);
    threadData->lastEquationSolved = 496;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_502(data, threadData);
    threadData->lastEquationSolved = 502;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_503(data, threadData);
    threadData->lastEquationSolved = 503;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_506(data, threadData);
    threadData->lastEquationSolved = 506;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_507(data, threadData);
    threadData->lastEquationSolved = 507;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_510(data, threadData);
    threadData->lastEquationSolved = 510;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_513(data, threadData);
    threadData->lastEquationSolved = 513;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_514(data, threadData);
    threadData->lastEquationSolved = 514;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_515(data, threadData);
    threadData->lastEquationSolved = 515;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_518(data, threadData);
    threadData->lastEquationSolved = 518;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_555(data, threadData);
    threadData->lastEquationSolved = 555;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_556(data, threadData);
    threadData->lastEquationSolved = 556;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_557(data, threadData);
    threadData->lastEquationSolved = 557;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_558(data, threadData);
    threadData->lastEquationSolved = 558;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_559(data, threadData);
    threadData->lastEquationSolved = 559;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_560(data, threadData);
    threadData->lastEquationSolved = 560;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_561(data, threadData);
    threadData->lastEquationSolved = 561;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_562(data, threadData);
    threadData->lastEquationSolved = 562;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_563(data, threadData);
    threadData->lastEquationSolved = 563;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_564(data, threadData);
    threadData->lastEquationSolved = 564;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_565(data, threadData);
    threadData->lastEquationSolved = 565;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_566(data, threadData);
    threadData->lastEquationSolved = 566;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_567(data, threadData);
    threadData->lastEquationSolved = 567;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_568(data, threadData);
    threadData->lastEquationSolved = 568;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_569(data, threadData);
    threadData->lastEquationSolved = 569;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_570(data, threadData);
    threadData->lastEquationSolved = 570;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_571(data, threadData);
    threadData->lastEquationSolved = 571;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_572(data, threadData);
    threadData->lastEquationSolved = 572;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_573(data, threadData);
    threadData->lastEquationSolved = 573;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_574(data, threadData);
    threadData->lastEquationSolved = 574;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_575(data, threadData);
    threadData->lastEquationSolved = 575;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_576(data, threadData);
    threadData->lastEquationSolved = 576;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_577(data, threadData);
    threadData->lastEquationSolved = 577;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_578(data, threadData);
    threadData->lastEquationSolved = 578;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_579(data, threadData);
    threadData->lastEquationSolved = 579;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_580(data, threadData);
    threadData->lastEquationSolved = 580;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_581(data, threadData);
    threadData->lastEquationSolved = 581;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_582(data, threadData);
    threadData->lastEquationSolved = 582;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_583(data, threadData);
    threadData->lastEquationSolved = 583;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_584(data, threadData);
    threadData->lastEquationSolved = 584;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_585(data, threadData);
    threadData->lastEquationSolved = 585;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_621(data, threadData);
    threadData->lastEquationSolved = 621;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_622(data, threadData);
    threadData->lastEquationSolved = 622;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_623(data, threadData);
    threadData->lastEquationSolved = 623;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_624(data, threadData);
    threadData->lastEquationSolved = 624;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_625(data, threadData);
    threadData->lastEquationSolved = 625;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_626(data, threadData);
    threadData->lastEquationSolved = 626;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_627(data, threadData);
    threadData->lastEquationSolved = 627;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_628(data, threadData);
    threadData->lastEquationSolved = 628;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_629(data, threadData);
    threadData->lastEquationSolved = 629;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_630(data, threadData);
    threadData->lastEquationSolved = 630;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_631(data, threadData);
    threadData->lastEquationSolved = 631;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_632(data, threadData);
    threadData->lastEquationSolved = 632;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_633(data, threadData);
    threadData->lastEquationSolved = 633;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_634(data, threadData);
    threadData->lastEquationSolved = 634;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_635(data, threadData);
    threadData->lastEquationSolved = 635;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_636(data, threadData);
    threadData->lastEquationSolved = 636;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_637(data, threadData);
    threadData->lastEquationSolved = 637;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_638(data, threadData);
    threadData->lastEquationSolved = 638;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_639(data, threadData);
    threadData->lastEquationSolved = 639;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_640(data, threadData);
    threadData->lastEquationSolved = 640;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_641(data, threadData);
    threadData->lastEquationSolved = 641;
  }
}
/* for continuous time variables */
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionAlgebraics(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_ALGEBRAICS);
#endif
  data->simulationInfo->callStatistics.functionAlgebraics++;

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_function_savePreSynchronous(data, threadData);
  
  functionAlg_system0(data, threadData);

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_ALGEBRAICS);
#endif

  TRACE_POP
  return 0;
}

#ifdef __cplusplus
}
#endif
