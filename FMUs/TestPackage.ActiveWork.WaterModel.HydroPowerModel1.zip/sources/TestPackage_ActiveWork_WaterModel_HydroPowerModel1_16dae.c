/* DAE residuals is empty */
 #include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initializeDAEmodeData(DATA* data, DAEMODE_DATA* daeModeData){ return -1; }
#ifdef __cplusplus
}
#endif
