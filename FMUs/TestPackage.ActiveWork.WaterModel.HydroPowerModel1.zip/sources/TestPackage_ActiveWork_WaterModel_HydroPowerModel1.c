/* Main Simulation File */

#if defined(__cplusplus)
extern "C" {
#endif

#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_model.h"
#include "simulation/solver/events.h"



/* dummy VARINFO and FILEINFO */
const VAR_INFO dummyVAR_INFO = omc_dummyVarInfo;

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_input_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  (data->localData[0]->realVars[82] /* SM_speed_in variable */) = data->simulationInfo->inputVars[0];
  (data->localData[0]->realVars[83] /* SM_torque_in variable */) = data->simulationInfo->inputVars[1];
  
  TRACE_POP
  return 0;
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_input_function_init(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->inputVars[0] = data->modelData->realVarsData[82].attribute.start;
  data->simulationInfo->inputVars[1] = data->modelData->realVarsData[83].attribute.start;
  
  TRACE_POP
  return 0;
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_input_function_updateStartValues(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->modelData->realVarsData[82].attribute.start = data->simulationInfo->inputVars[0];
  data->modelData->realVarsData[83].attribute.start = data->simulationInfo->inputVars[1];
  
  TRACE_POP
  return 0;
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_inputNames(DATA *data, char ** names){
  TRACE_PUSH

  names[0] = (char *) data->modelData->realVarsData[82].info.name;
  names[1] = (char *) data->modelData->realVarsData[83].info.name;
  
  TRACE_POP
  return 0;
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_data_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  TRACE_POP
  return 0;
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_dataReconciliationInputNames(DATA *data, char ** names){
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_dataReconciliationUnmeasuredVariables(DATA *data, char ** names)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_output_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->outputVars[0] = (data->localData[0]->realVars[80] /* SM_Speed_Out variable */);
  data->simulationInfo->outputVars[1] = (data->localData[0]->realVars[81] /* SM_Start_Torque_out variable */);
  data->simulationInfo->outputVars[2] = (data->localData[0]->realVars[84] /* TM_Torque_Out variable */);
  
  TRACE_POP
  return 0;
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_setc_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_setb_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}


/*
equation index: 459
type: SIMPLE_ASSIGN
$DER.add.u1 = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_459(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,459};
  (data->localData[0]->realVars[25] /* der(add.u1) DUMMY_DER */) = 0.0;
  TRACE_POP
}
/*
equation index: 460
type: SIMPLE_ASSIGN
$DER.booleanToReal.y = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_460(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,460};
  (data->localData[0]->realVars[27] /* der(booleanToReal.y) DUMMY_DER */) = 0.0;
  TRACE_POP
}
/*
equation index: 461
type: SIMPLE_ASSIGN
reservoir.F_f = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_461(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,461};
  (data->localData[0]->realVars[130] /* reservoir.F_f variable */) = 0.0;
  TRACE_POP
}
/*
equation index: 462
type: SIMPLE_ASSIGN
$DER.step.y = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_462(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,462};
  (data->localData[0]->realVars[46] /* der(step.y) DUMMY_DER */) = 0.0;
  TRACE_POP
}
/*
equation index: 463
type: SIMPLE_ASSIGN
$DER.add.y = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_463(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,463};
  (data->localData[0]->realVars[26] /* der(add.y) DUMMY_DER */) = 0.0;
  TRACE_POP
}
/*
equation index: 464
type: SIMPLE_ASSIGN
$DER.division2.y = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_464(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,464};
  (data->localData[0]->realVars[36] /* der(division2.y) DUMMY_DER */) = 0.0;
  TRACE_POP
}
/*
equation index: 465
type: SIMPLE_ASSIGN
tail.F_f = 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_465(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,465};
  (data->localData[0]->realVars[155] /* tail.F_f variable */) = 0.0;
  TRACE_POP
}
/*
equation index: 466
type: SIMPLE_ASSIGN
Power.y = SM_speed_in * SM_torque_in
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_466(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,466};
  (data->localData[0]->realVars[79] /* Power.y variable */) = ((data->localData[0]->realVars[82] /* SM_speed_in variable */)) * ((data->localData[0]->realVars[83] /* SM_torque_in variable */));
  TRACE_POP
}
/*
equation index: 467
type: SIMPLE_ASSIGN
$DER.turbine1.look_up_table.u[1] = if time < control.startTime then 0.0 else if time < control.startTime + control.duration then control.height * control.duration / control.duration ^ 2.0 else 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_467(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,467};
  modelica_boolean tmp0;
  modelica_boolean tmp1;
  modelica_real tmp2;
  modelica_boolean tmp3;
  modelica_real tmp4;
  modelica_boolean tmp5;
  modelica_real tmp6;
  relationhysteresis(data, &tmp0, data->localData[0]->timeValue, (data->simulationInfo->realParameter[34] /* control.startTime PARAM */), 0, Less, LessZC);
  tmp5 = (modelica_boolean)tmp0;
  if(tmp5)
  {
    tmp6 = 0.0;
  }
  else
  {
    relationhysteresis(data, &tmp1, data->localData[0]->timeValue, (data->simulationInfo->realParameter[34] /* control.startTime PARAM */) + (data->simulationInfo->realParameter[31] /* control.duration PARAM */), 1, Less, LessZC);
    tmp3 = (modelica_boolean)tmp1;
    if(tmp3)
    {
      tmp2 = (data->simulationInfo->realParameter[31] /* control.duration PARAM */);
      tmp4 = DIVISION_SIM(((data->simulationInfo->realParameter[32] /* control.height PARAM */)) * ((data->simulationInfo->realParameter[31] /* control.duration PARAM */)),(tmp2 * tmp2),"control.duration ^ 2.0",equationIndexes);
    }
    else
    {
      tmp4 = 0.0;
    }
    tmp6 = tmp4;
  }
  (data->localData[0]->realVars[63] /* der(turbine1.look_up_table.u[1]) DUMMY_DER */) = tmp6;
  TRACE_POP
}
/*
equation index: 468
type: SIMPLE_ASSIGN
$DER.turbine1.setSpeed.phi = turbine1.setSpeed.w
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_468(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,468};
  (data->localData[0]->realVars[8] /* der(turbine1.setSpeed.phi) STATE_DER */) = (data->localData[0]->realVars[4] /* turbine1.setSpeed.w STATE(1,turbine1.setSpeed.a) */);
  TRACE_POP
}
/*
equation index: 469
type: SIMPLE_ASSIGN
add.u1 = Ao1.k * SM_speed_in
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_469(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,469};
  (data->localData[0]->realVars[85] /* add.u1 DUMMY_STATE */) = ((data->simulationInfo->realParameter[0] /* Ao1.k PARAM */)) * ((data->localData[0]->realVars[82] /* SM_speed_in variable */));
  TRACE_POP
}
/*
equation index: 470
type: SIMPLE_ASSIGN
turbine1.friction.w = turbine1.toSysSpeed.ratio * turbine1.setSpeed.w
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_470(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,470};
  (data->localData[0]->realVars[174] /* turbine1.friction.w variable */) = ((data->simulationInfo->realParameter[148] /* turbine1.toSysSpeed.ratio PARAM */)) * ((data->localData[0]->realVars[4] /* turbine1.setSpeed.w STATE(1,turbine1.setSpeed.a) */));
  TRACE_POP
}
/*
equation index: 471
type: SIMPLE_ASSIGN
turbine1.toHz.y = turbine1.toHz.k * turbine1.friction.w
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_471(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,471};
  (data->localData[0]->realVars[186] /* turbine1.toHz.y variable */) = ((data->simulationInfo->realParameter[147] /* turbine1.toHz.k PARAM */)) * ((data->localData[0]->realVars[174] /* turbine1.friction.w variable */));
  TRACE_POP
}
/*
equation index: 472
type: SIMPLE_ASSIGN
turbine1.div0protect.y = smooth(0, if turbine1.friction.w > turbine1.div0protect.uMax then turbine1.div0protect.uMax else if turbine1.friction.w < turbine1.div0protect.uMin then turbine1.div0protect.uMin else turbine1.friction.w)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_472(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,472};
  modelica_boolean tmp7;
  modelica_boolean tmp8;
  modelica_boolean tmp9;
  modelica_real tmp10;
  tmp7 = Greater((data->localData[0]->realVars[174] /* turbine1.friction.w variable */),(data->simulationInfo->realParameter[108] /* turbine1.div0protect.uMax PARAM */));
  tmp9 = (modelica_boolean)tmp7;
  if(tmp9)
  {
    tmp10 = (data->simulationInfo->realParameter[108] /* turbine1.div0protect.uMax PARAM */);
  }
  else
  {
    tmp8 = Less((data->localData[0]->realVars[174] /* turbine1.friction.w variable */),(data->simulationInfo->realParameter[109] /* turbine1.div0protect.uMin PARAM */));
    tmp10 = (tmp8?(data->simulationInfo->realParameter[109] /* turbine1.div0protect.uMin PARAM */):(data->localData[0]->realVars[174] /* turbine1.friction.w variable */));
  }
  (data->localData[0]->realVars[166] /* turbine1.div0protect.y variable */) = tmp10;
  TRACE_POP
}
/*
equation index: 473
type: SIMPLE_ASSIGN
turbine1.inertia.w = turbine1.friction.w
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_473(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,473};
  (data->localData[0]->realVars[178] /* turbine1.inertia.w DUMMY_STATE */) = (data->localData[0]->realVars[174] /* turbine1.friction.w variable */);
  TRACE_POP
}
/*
equation index: 474
type: SIMPLE_ASSIGN
$DER.turbine1.friction.phi = turbine1.friction.w
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_474(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,474};
  (data->localData[0]->realVars[61] /* der(turbine1.friction.phi) DUMMY_DER */) = (data->localData[0]->realVars[174] /* turbine1.friction.w variable */);
  TRACE_POP
}
/*
equation index: 475
type: SIMPLE_ASSIGN
$DER.turbine1.speedSensor.flange.phi = turbine1.friction.w
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_475(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,475};
  (data->localData[0]->realVars[64] /* der(turbine1.speedSensor.flange.phi) DUMMY_DER */) = (data->localData[0]->realVars[174] /* turbine1.friction.w variable */);
  TRACE_POP
}
/*
equation index: 476
type: SIMPLE_ASSIGN
surgeTank.F_g = surgeTank.m * data.g * surgeTank.cos_theta
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_476(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,476};
  (data->localData[0]->realVars[142] /* surgeTank.F_g DUMMY_STATE */) = ((data->localData[0]->realVars[2] /* surgeTank.m STATE(1,surgeTank.mdot) */)) * (((data->simulationInfo->realParameter[42] /* data.g PARAM */)) * ((data->localData[0]->realVars[147] /* surgeTank.cos_theta variable */)));
  TRACE_POP
}
/*
equation index: 477
type: SIMPLE_ASSIGN
surgeTank.l = surgeTank.m / (data.rho * surgeTank.A)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_477(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,477};
  (data->localData[0]->realVars[149] /* surgeTank.l DUMMY_STATE */) = DIVISION_SIM((data->localData[0]->realVars[2] /* surgeTank.m STATE(1,surgeTank.mdot) */),((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->localData[0]->realVars[138] /* surgeTank.A variable */)),"data.rho * surgeTank.A",equationIndexes);
  TRACE_POP
}
/*
equation index: 478
type: SIMPLE_ASSIGN
surgeTank.h = surgeTank.l * surgeTank.cos_theta
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_478(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,478};
  (data->localData[0]->realVars[148] /* surgeTank.h variable */) = ((data->localData[0]->realVars[149] /* surgeTank.l DUMMY_STATE */)) * ((data->localData[0]->realVars[147] /* surgeTank.cos_theta variable */));
  TRACE_POP
}
/*
equation index: 479
type: SIMPLE_ASSIGN
step.y = step.offset + (if time < step.startTime then 0.0 else step.height)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_479(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,479};
  modelica_boolean tmp11;
  relationhysteresis(data, &tmp11, data->localData[0]->timeValue, (data->simulationInfo->realParameter[81] /* step.startTime PARAM */), 2, Less, LessZC);
  (data->localData[0]->realVars[137] /* step.y DUMMY_STATE */) = (data->simulationInfo->realParameter[80] /* step.offset PARAM */) + (tmp11?0.0:(data->simulationInfo->realParameter[79] /* step.height PARAM */));
  TRACE_POP
}
/*
equation index: 480
type: SIMPLE_ASSIGN
add.y = add.k1 * add.u1 + add.k2 * step.y
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_480(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,480};
  (data->localData[0]->realVars[86] /* add.y DUMMY_STATE */) = ((data->simulationInfo->realParameter[17] /* add.k1 PARAM */)) * ((data->localData[0]->realVars[85] /* add.u1 DUMMY_STATE */)) + ((data->simulationInfo->realParameter[18] /* add.k2 PARAM */)) * ((data->localData[0]->realVars[137] /* step.y DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 481
type: SIMPLE_ASSIGN
division2.y = add.y / constant4.k
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_481(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,481};
  (data->localData[0]->realVars[104] /* division2.y DUMMY_STATE */) = DIVISION_SIM((data->localData[0]->realVars[86] /* add.y DUMMY_STATE */),(data->simulationInfo->realParameter[29] /* constant4.k PARAM */),"constant4.k",equationIndexes);
  TRACE_POP
}
/*
equation index: 482
type: SIMPLE_ASSIGN
turbine1.setSpeed.w_ref = turbine1.pu2w.k * add.y
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_482(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,482};
  (data->localData[0]->realVars[183] /* turbine1.setSpeed.w_ref variable */) = ((data->simulationInfo->realParameter[144] /* turbine1.pu2w.k PARAM */)) * ((data->localData[0]->realVars[86] /* add.y DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 483
type: SIMPLE_ASSIGN
turbine1.setSpeed.a = (turbine1.setSpeed.w_ref - turbine1.setSpeed.w) * turbine1.setSpeed.w_crit
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_483(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,483};
  (data->localData[0]->realVars[181] /* turbine1.setSpeed.a variable */) = ((data->localData[0]->realVars[183] /* turbine1.setSpeed.w_ref variable */) - (data->localData[0]->realVars[4] /* turbine1.setSpeed.w STATE(1,turbine1.setSpeed.a) */)) * ((data->simulationInfo->realParameter[146] /* turbine1.setSpeed.w_crit PARAM */));
  TRACE_POP
}
/*
equation index: 484
type: SIMPLE_ASSIGN
turbine1.inertia.a = turbine1.toSysSpeed.ratio * turbine1.setSpeed.a
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_484(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,484};
  (data->localData[0]->realVars[177] /* turbine1.inertia.a variable */) = ((data->simulationInfo->realParameter[148] /* turbine1.toSysSpeed.ratio PARAM */)) * ((data->localData[0]->realVars[181] /* turbine1.setSpeed.a variable */));
  TRACE_POP
}
/*
equation index: 485
type: SIMPLE_ASSIGN
$DER.turbine1.inertia.w = turbine1.inertia.a
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_485(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,485};
  (data->localData[0]->realVars[62] /* der(turbine1.inertia.w) DUMMY_DER */) = (data->localData[0]->realVars[177] /* turbine1.inertia.a variable */);
  TRACE_POP
}
/*
equation index: 486
type: SIMPLE_ASSIGN
$DER.turbine1.setSpeed.w = turbine1.setSpeed.a
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_486(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,486};
  (data->localData[0]->realVars[9] /* der(turbine1.setSpeed.w) STATE_DER */) = (data->localData[0]->realVars[181] /* turbine1.setSpeed.a variable */);
  TRACE_POP
}
/*
equation index: 487
type: SIMPLE_ASSIGN
turbine1.look_up_table.u[1] = control.offset + (if time < control.startTime then 0.0 else if time < control.startTime + control.duration then (time - control.startTime) * control.height / control.duration else control.height)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_487(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,487};
  modelica_boolean tmp12;
  modelica_boolean tmp13;
  modelica_boolean tmp14;
  modelica_real tmp15;
  relationhysteresis(data, &tmp12, data->localData[0]->timeValue, (data->simulationInfo->realParameter[34] /* control.startTime PARAM */), 0, Less, LessZC);
  tmp14 = (modelica_boolean)tmp12;
  if(tmp14)
  {
    tmp15 = 0.0;
  }
  else
  {
    relationhysteresis(data, &tmp13, data->localData[0]->timeValue, (data->simulationInfo->realParameter[34] /* control.startTime PARAM */) + (data->simulationInfo->realParameter[31] /* control.duration PARAM */), 1, Less, LessZC);
    tmp15 = (tmp13?DIVISION_SIM((data->localData[0]->timeValue - (data->simulationInfo->realParameter[34] /* control.startTime PARAM */)) * ((data->simulationInfo->realParameter[32] /* control.height PARAM */)),(data->simulationInfo->realParameter[31] /* control.duration PARAM */),"control.duration",equationIndexes):(data->simulationInfo->realParameter[32] /* control.height PARAM */));
  }
  (data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */) = (data->simulationInfo->realParameter[33] /* control.offset PARAM */) + tmp15;
  TRACE_POP
}
/*
equation index: 488
type: SIMPLE_ASSIGN
turbine1.look_up_table.y[1] = Modelica.Blocks.Tables.Internal.getTable1DValueNoDer2(turbine1.look_up_table.tableID, 1, turbine1.look_up_table.u[1])
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_488(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,488};
  (data->localData[0]->realVars[180] /* turbine1.look_up_table.y[1] variable */) = omc_Modelica_Blocks_Tables_Internal_getTable1DValueNoDer2(threadData, (data->simulationInfo->extObjs[0]), ((modelica_integer) 1), (data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 489
type: SIMPLE_ASSIGN
turbine1.speedSensor.flange.phi = turbine1.toSysSpeed.ratio * turbine1.setSpeed.phi
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_489(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,489};
  (data->localData[0]->realVars[184] /* turbine1.speedSensor.flange.phi DUMMY_STATE */) = ((data->simulationInfo->realParameter[148] /* turbine1.toSysSpeed.ratio PARAM */)) * ((data->localData[0]->realVars[3] /* turbine1.setSpeed.phi STATE(1,turbine1.setSpeed.w) */));
  TRACE_POP
}
/*
equation index: 490
type: SIMPLE_ASSIGN
turbine1.friction.phi = turbine1.speedSensor.flange.phi - turbine1.fixed.phi0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_490(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,490};
  (data->localData[0]->realVars[172] /* turbine1.friction.phi DUMMY_STATE */) = (data->localData[0]->realVars[184] /* turbine1.speedSensor.flange.phi DUMMY_STATE */) - (data->simulationInfo->realParameter[112] /* turbine1.fixed.phi0 PARAM */);
  TRACE_POP
}
/*
equation index: 491
type: SIMPLE_ASSIGN
intake.Vdot = intake.M / (data.rho * intake.L)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_491(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,491};
  (data->localData[0]->realVars[110] /* intake.Vdot DUMMY_STATE */) = DIVISION_SIM((data->localData[0]->realVars[0] /* intake.M STATE(1) */),((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->simulationInfo->realParameter[62] /* intake.L PARAM */)),"data.rho * intake.L",equationIndexes);
  TRACE_POP
}
/*
equation index: 492
type: SIMPLE_ASSIGN
intake.mdot = intake.Vdot * data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_492(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,492};
  (data->localData[0]->realVars[114] /* intake.mdot DUMMY_STATE */) = ((data->localData[0]->realVars[110] /* intake.Vdot DUMMY_STATE */)) * ((data->simulationInfo->realParameter[47] /* data.rho PARAM */));
  TRACE_POP
}
/*
equation index: 493
type: SIMPLE_ASSIGN
reservoir.Vdot_i = intake.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_493(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,493};
  (data->localData[0]->realVars[133] /* reservoir.Vdot_i variable */) = DIVISION_SIM((data->localData[0]->realVars[114] /* intake.mdot DUMMY_STATE */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes);
  TRACE_POP
}
/*
equation index: 494
type: SIMPLE_ASSIGN
intake.v = intake.Vdot / intake.A_
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_494(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,494};
  (data->localData[0]->realVars[117] /* intake.v DUMMY_STATE */) = DIVISION_SIM((data->localData[0]->realVars[110] /* intake.Vdot DUMMY_STATE */),(data->localData[0]->realVars[105] /* intake.A_ variable */),"intake.A_",equationIndexes);
  TRACE_POP
}
/*
equation index: 495
type: SIMPLE_ASSIGN
intake.F_f = OpenHPL.Functions.DarcyFriction.Friction(intake.v, intake.D_, intake.L, data.rho, data.mu, intake.p_eps)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_495(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,495};
  (data->localData[0]->realVars[109] /* intake.F_f DUMMY_STATE */) = omc_OpenHPL_Functions_DarcyFriction_Friction(threadData, (data->localData[0]->realVars[117] /* intake.v DUMMY_STATE */), (data->localData[0]->realVars[108] /* intake.D_ variable */), (data->simulationInfo->realParameter[62] /* intake.L PARAM */), (data->simulationInfo->realParameter[47] /* data.rho PARAM */), (data->simulationInfo->realParameter[44] /* data.mu PARAM */), (data->simulationInfo->realParameter[64] /* intake.p_eps PARAM */));
  TRACE_POP
}
/*
equation index: 496
type: SIMPLE_ASSIGN
$cse5 = OpenHPL.Functions.DarcyFriction.fDarcy(data.rho * abs(intake.v) * intake.D_ / data.mu, intake.D_, intake.p_eps)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_496(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,496};
  (data->localData[0]->realVars[72] /* $cse5 variable */) = omc_OpenHPL_Functions_DarcyFriction_fDarcy(threadData, DIVISION_SIM((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (fabs((data->localData[0]->realVars[117] /* intake.v DUMMY_STATE */)))) * ((data->localData[0]->realVars[108] /* intake.D_ variable */)),(data->simulationInfo->realParameter[44] /* data.mu PARAM */),"data.mu",equationIndexes), (data->localData[0]->realVars[108] /* intake.D_ variable */), (data->simulationInfo->realParameter[64] /* intake.p_eps PARAM */));
  TRACE_POP
}
/*
equation index: 497
type: SIMPLE_ASSIGN
penstock.Vdot = penstock.M / (data.rho * penstock.L)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_497(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,497};
  (data->localData[0]->realVars[123] /* penstock.Vdot DUMMY_STATE */) = DIVISION_SIM((data->localData[0]->realVars[1] /* penstock.M STATE(1) */),((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->simulationInfo->realParameter[69] /* penstock.L PARAM */)),"data.rho * penstock.L",equationIndexes);
  TRACE_POP
}
/*
equation index: 498
type: SIMPLE_ASSIGN
discharge.mdot = penstock.Vdot * data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_498(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,498};
  (data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */) = ((data->localData[0]->realVars[123] /* penstock.Vdot DUMMY_STATE */)) * ((data->simulationInfo->realParameter[47] /* data.rho PARAM */));
  TRACE_POP
}
/*
equation index: 499
type: SIMPLE_ASSIGN
surgeTank.mdot = intake.mdot - discharge.mdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_499(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,499};
  (data->localData[0]->realVars[151] /* surgeTank.mdot DUMMY_STATE */) = (data->localData[0]->realVars[114] /* intake.mdot DUMMY_STATE */) - (data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */);
  TRACE_POP
}
/*
equation index: 500
type: SIMPLE_ASSIGN
surgeTank.Vdot = surgeTank.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_500(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,500};
  (data->localData[0]->realVars[146] /* surgeTank.Vdot DUMMY_STATE */) = DIVISION_SIM((data->localData[0]->realVars[151] /* surgeTank.mdot DUMMY_STATE */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes);
  TRACE_POP
}
/*
equation index: 501
type: SIMPLE_ASSIGN
surgeTank.v = surgeTank.Vdot / surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_501(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,501};
  (data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */) = DIVISION_SIM((data->localData[0]->realVars[146] /* surgeTank.Vdot DUMMY_STATE */),(data->localData[0]->realVars[138] /* surgeTank.A variable */),"surgeTank.A",equationIndexes);
  TRACE_POP
}
/*
equation index: 502
type: SIMPLE_ASSIGN
surgeTank.M = surgeTank.m * surgeTank.v
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_502(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,502};
  (data->localData[0]->realVars[144] /* surgeTank.M DUMMY_STATE */) = ((data->localData[0]->realVars[2] /* surgeTank.m STATE(1,surgeTank.mdot) */)) * ((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 503
type: SIMPLE_ASSIGN
$cse3 = OpenHPL.Functions.DarcyFriction.fDarcy(data.rho * abs(surgeTank.v) * surgeTank.D / data.mu, surgeTank.D, surgeTank.p_eps)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_503(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,503};
  (data->localData[0]->realVars[70] /* $cse3 variable */) = omc_OpenHPL_Functions_DarcyFriction_fDarcy(threadData, DIVISION_SIM((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (fabs((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */)))) * ((data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */)),(data->simulationInfo->realParameter[44] /* data.mu PARAM */),"data.mu",equationIndexes), (data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */), (data->simulationInfo->realParameter[92] /* surgeTank.p_eps PARAM */));
  TRACE_POP
}
/*
equation index: 504
type: SIMPLE_ASSIGN
surgeTank.F_f = OpenHPL.Functions.DarcyFriction.Friction(surgeTank.v, surgeTank.D, surgeTank.l, data.rho, data.mu, surgeTank.p_eps)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_504(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,504};
  (data->localData[0]->realVars[141] /* surgeTank.F_f DUMMY_STATE */) = omc_OpenHPL_Functions_DarcyFriction_Friction(threadData, (data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */), (data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */), (data->localData[0]->realVars[149] /* surgeTank.l DUMMY_STATE */), (data->simulationInfo->realParameter[47] /* data.rho PARAM */), (data->simulationInfo->realParameter[44] /* data.mu PARAM */), (data->simulationInfo->realParameter[92] /* surgeTank.p_eps PARAM */));
  TRACE_POP
}
/*
equation index: 505
type: SIMPLE_ASSIGN
surgeTank.Mdot = surgeTank.mdot * surgeTank.v
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_505(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,505};
  (data->localData[0]->realVars[145] /* surgeTank.Mdot DUMMY_STATE */) = ((data->localData[0]->realVars[151] /* surgeTank.mdot DUMMY_STATE */)) * ((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 506
type: SIMPLE_ASSIGN
$DER.surgeTank.F_g = surgeTank.mdot * data.g * surgeTank.cos_theta
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_506(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,506};
  (data->localData[0]->realVars[49] /* der(surgeTank.F_g) DUMMY_DER */) = ((data->localData[0]->realVars[151] /* surgeTank.mdot DUMMY_STATE */)) * (((data->simulationInfo->realParameter[42] /* data.g PARAM */)) * ((data->localData[0]->realVars[147] /* surgeTank.cos_theta variable */)));
  TRACE_POP
}
/*
equation index: 507
type: SIMPLE_ASSIGN
$DER.surgeTank.l = surgeTank.mdot / (data.rho * surgeTank.A)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_507(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,507};
  (data->localData[0]->realVars[54] /* der(surgeTank.l) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[151] /* surgeTank.mdot DUMMY_STATE */),((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->localData[0]->realVars[138] /* surgeTank.A variable */)),"data.rho * surgeTank.A",equationIndexes);
  TRACE_POP
}
/*
equation index: 508
type: SIMPLE_ASSIGN
$DER.surgeTank.m = surgeTank.mdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_508(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,508};
  (data->localData[0]->realVars[7] /* der(surgeTank.m) STATE_DER */) = (data->localData[0]->realVars[151] /* surgeTank.mdot DUMMY_STATE */);
  TRACE_POP
}
/*
equation index: 509
type: SIMPLE_ASSIGN
discharge.Vdot = discharge.mdot / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_509(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,509};
  (data->localData[0]->realVars[94] /* discharge.Vdot DUMMY_STATE */) = DIVISION_SIM((data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes);
  TRACE_POP
}
/*
equation index: 510
type: SIMPLE_ASSIGN
discharge.M = data.rho * discharge.L * discharge.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_510(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,510};
  (data->localData[0]->realVars[93] /* discharge.M DUMMY_STATE */) = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[51] /* discharge.L PARAM */)) * ((data->localData[0]->realVars[94] /* discharge.Vdot DUMMY_STATE */)));
  TRACE_POP
}
/*
equation index: 511
type: SIMPLE_ASSIGN
discharge.v = discharge.Vdot / discharge.A_
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_511(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,511};
  (data->localData[0]->realVars[101] /* discharge.v DUMMY_STATE */) = DIVISION_SIM((data->localData[0]->realVars[94] /* discharge.Vdot DUMMY_STATE */),(data->localData[0]->realVars[88] /* discharge.A_ variable */),"discharge.A_",equationIndexes);
  TRACE_POP
}
/*
equation index: 512
type: SIMPLE_ASSIGN
discharge.F_f = OpenHPL.Functions.DarcyFriction.Friction(discharge.v, discharge.D_, discharge.L, data.rho, data.mu, discharge.p_eps)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_512(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,512};
  (data->localData[0]->realVars[92] /* discharge.F_f DUMMY_STATE */) = omc_OpenHPL_Functions_DarcyFriction_Friction(threadData, (data->localData[0]->realVars[101] /* discharge.v DUMMY_STATE */), (data->localData[0]->realVars[91] /* discharge.D_ variable */), (data->simulationInfo->realParameter[51] /* discharge.L PARAM */), (data->simulationInfo->realParameter[47] /* data.rho PARAM */), (data->simulationInfo->realParameter[44] /* data.mu PARAM */), (data->simulationInfo->realParameter[53] /* discharge.p_eps PARAM */));
  TRACE_POP
}
/*
equation index: 513
type: SIMPLE_ASSIGN
$cse8 = $DER$OpenHPL$PFunctions$PDarcyFriction$PfDarcy(data.rho * abs(discharge.v) * discharge.D_ / data.mu, discharge.D_, discharge.p_eps, 1.0, 0.0, 0.0)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_513(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,513};
  (data->localData[0]->realVars[75] /* $cse8 variable */) = omc__omcQ_24DER_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy(threadData, DIVISION_SIM((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (fabs((data->localData[0]->realVars[101] /* discharge.v DUMMY_STATE */)))) * ((data->localData[0]->realVars[91] /* discharge.D_ variable */)),(data->simulationInfo->realParameter[44] /* data.mu PARAM */),"data.mu",equationIndexes), (data->localData[0]->realVars[91] /* discharge.D_ variable */), (data->simulationInfo->realParameter[53] /* discharge.p_eps PARAM */), 1.0, 0.0, 0.0);
  TRACE_POP
}
/*
equation index: 514
type: SIMPLE_ASSIGN
$cse7 = OpenHPL.Functions.DarcyFriction.fDarcy(data.rho * abs(discharge.v) * discharge.D_ / data.mu, discharge.D_, discharge.p_eps)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_514(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,514};
  (data->localData[0]->realVars[74] /* $cse7 variable */) = omc_OpenHPL_Functions_DarcyFriction_fDarcy(threadData, DIVISION_SIM((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (fabs((data->localData[0]->realVars[101] /* discharge.v DUMMY_STATE */)))) * ((data->localData[0]->realVars[91] /* discharge.D_ variable */)),(data->simulationInfo->realParameter[44] /* data.mu PARAM */),"data.mu",equationIndexes), (data->localData[0]->realVars[91] /* discharge.D_ variable */), (data->simulationInfo->realParameter[53] /* discharge.p_eps PARAM */));
  TRACE_POP
}
/*
equation index: 515
type: SIMPLE_ASSIGN
tail.Vdot_i = (-discharge.mdot) / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_515(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,515};
  (data->localData[0]->realVars[158] /* tail.Vdot_i variable */) = DIVISION_SIM((-(data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */)),(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho",equationIndexes);
  TRACE_POP
}
/*
equation index: 516
type: SIMPLE_ASSIGN
penstock.v = penstock.Vdot / penstock.A_
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_516(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,516};
  (data->localData[0]->realVars[128] /* penstock.v DUMMY_STATE */) = DIVISION_SIM((data->localData[0]->realVars[123] /* penstock.Vdot DUMMY_STATE */),(data->localData[0]->realVars[118] /* penstock.A_ variable */),"penstock.A_",equationIndexes);
  TRACE_POP
}
/*
equation index: 517
type: SIMPLE_ASSIGN
penstock.F_f = OpenHPL.Functions.DarcyFriction.Friction(penstock.v, penstock.D_, penstock.L, data.rho, data.mu, penstock.p_eps)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_517(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,517};
  (data->localData[0]->realVars[122] /* penstock.F_f DUMMY_STATE */) = omc_OpenHPL_Functions_DarcyFriction_Friction(threadData, (data->localData[0]->realVars[128] /* penstock.v DUMMY_STATE */), (data->localData[0]->realVars[121] /* penstock.D_ variable */), (data->simulationInfo->realParameter[69] /* penstock.L PARAM */), (data->simulationInfo->realParameter[47] /* data.rho PARAM */), (data->simulationInfo->realParameter[44] /* data.mu PARAM */), (data->simulationInfo->realParameter[71] /* penstock.p_eps PARAM */));
  TRACE_POP
}
/*
equation index: 518
type: SIMPLE_ASSIGN
$cse1 = OpenHPL.Functions.DarcyFriction.fDarcy(data.rho * abs(penstock.v) * penstock.D_ / data.mu, penstock.D_, penstock.p_eps)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_518(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,518};
  (data->localData[0]->realVars[68] /* $cse1 variable */) = omc_OpenHPL_Functions_DarcyFriction_fDarcy(threadData, DIVISION_SIM((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (fabs((data->localData[0]->realVars[128] /* penstock.v DUMMY_STATE */)))) * ((data->localData[0]->realVars[121] /* penstock.D_ variable */)),(data->simulationInfo->realParameter[44] /* data.mu PARAM */),"data.mu",equationIndexes), (data->localData[0]->realVars[121] /* penstock.D_ variable */), (data->simulationInfo->realParameter[71] /* penstock.p_eps PARAM */));
  TRACE_POP
}
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_519(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_520(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_521(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_522(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_523(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_524(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_525(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_526(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_527(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_528(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_529(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_530(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_531(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_532(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_533(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_534(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_535(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_536(DATA*, threadData_t*);
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_537(DATA*, threadData_t*);
/*
equation index: 554
indexNonlinear: 2
type: NONLINEAR

vars: {$DER.surgeTank.v}
eqns: {519, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530, 531, 532, 533, 534, 535, 536, 537}
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_554(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,554};
  int retValue;
  if(ACTIVE_STREAM(LOG_DT))
  {
    infoStreamPrint(LOG_DT, 1, "Solving nonlinear system 554 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);
    messageClose(LOG_DT);
  }
  /* get old value */
  data->simulationInfo->nonlinearSystemData[2].nlsxOld[0] = (data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */);
  retValue = solve_nonlinear_system(data, threadData, 2);
  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,554};
    throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, indexes, "Solving non-linear system 554 failed at time=%.15g.\nFor more information please use -lv LOG_NLS.", data->localData[0]->timeValue);
  }
  /* write solution */
  (data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */) = data->simulationInfo->nonlinearSystemData[2].nlsx[0];
  TRACE_POP
}
/*
equation index: 555
type: SIMPLE_ASSIGN
$cse4 = $DER$OpenHPL$PFunctions$PDarcyFriction$PfDarcy(data.rho * abs(surgeTank.v) * surgeTank.D / data.mu, surgeTank.D, surgeTank.p_eps, data.rho * sign(surgeTank.v) * $DER.surgeTank.v * surgeTank.D * data.mu / data.mu ^ 2.0, 0.0, 0.0)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_555(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,555};
  modelica_real tmp0;
  tmp0 = (data->simulationInfo->realParameter[44] /* data.mu PARAM */);
  (data->localData[0]->realVars[71] /* $cse4 variable */) = omc__omcQ_24DER_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy(threadData, DIVISION_SIM((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (fabs((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */)))) * ((data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */)),(data->simulationInfo->realParameter[44] /* data.mu PARAM */),"data.mu",equationIndexes), (data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */), (data->simulationInfo->realParameter[92] /* surgeTank.p_eps PARAM */), DIVISION_SIM(((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((sign((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */))) * ((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)))) * ((data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */))) * ((data->simulationInfo->realParameter[44] /* data.mu PARAM */)),(tmp0 * tmp0),"data.mu ^ 2.0",equationIndexes), 0.0, 0.0);
  TRACE_POP
}
/*
equation index: 556
type: SIMPLE_ASSIGN
$DER.surgeTank.Mdot = surgeTank.mdot * $DER.surgeTank.v + $DER.surgeTank.mdot * surgeTank.v
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_556(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,556};
  (data->localData[0]->realVars[52] /* der(surgeTank.Mdot) DUMMY_DER */) = ((data->localData[0]->realVars[151] /* surgeTank.mdot DUMMY_STATE */)) * ((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)) + ((data->localData[0]->realVars[55] /* der(surgeTank.mdot) DUMMY_DER */)) * ((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 557
type: SIMPLE_ASSIGN
$DER.surgeTank.F_f = 0.3926990816987241 * data.rho * ($cse3 * (surgeTank.l * (surgeTank.v * sign(surgeTank.v) * $DER.surgeTank.v * surgeTank.D + $DER.surgeTank.v * abs(surgeTank.v) * surgeTank.D) + $DER.surgeTank.l * surgeTank.v * abs(surgeTank.v) * surgeTank.D) + $cse4 * surgeTank.l * surgeTank.v * abs(surgeTank.v) * surgeTank.D)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_557(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,557};
  (data->localData[0]->realVars[48] /* der(surgeTank.F_f) DUMMY_DER */) = (0.3926990816987241) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->localData[0]->realVars[70] /* $cse3 variable */)) * (((data->localData[0]->realVars[149] /* surgeTank.l DUMMY_STATE */)) * (((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */)) * ((sign((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */))) * (((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)) * ((data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */)))) + ((data->localData[0]->realVars[56] /* der(surgeTank.v) DUMMY_DER */)) * ((fabs((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */))) * ((data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */)))) + ((data->localData[0]->realVars[54] /* der(surgeTank.l) DUMMY_DER */)) * (((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */)) * ((fabs((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */))) * ((data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */))))) + ((data->localData[0]->realVars[71] /* $cse4 variable */)) * (((data->localData[0]->realVars[149] /* surgeTank.l DUMMY_STATE */)) * (((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */)) * ((fabs((data->localData[0]->realVars[153] /* surgeTank.v DUMMY_STATE */))) * ((data->simulationInfo->realParameter[82] /* surgeTank.D PARAM */)))))));
  TRACE_POP
}
/*
equation index: 558
type: SIMPLE_ASSIGN
$DER.penstock.v = $DER.penstock.Vdot / penstock.A_
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_558(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,558};
  (data->localData[0]->realVars[45] /* der(penstock.v) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[43] /* der(penstock.Vdot) DUMMY_DER */),(data->localData[0]->realVars[118] /* penstock.A_ variable */),"penstock.A_",equationIndexes);
  TRACE_POP
}
/*
equation index: 559
type: SIMPLE_ASSIGN
$cse2 = $DER$OpenHPL$PFunctions$PDarcyFriction$PfDarcy(data.rho * abs(penstock.v) * penstock.D_ / data.mu, penstock.D_, penstock.p_eps, data.rho * sign(penstock.v) * $DER.penstock.v * penstock.D_ * data.mu / data.mu ^ 2.0, 0.0, 0.0)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_559(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,559};
  modelica_real tmp1;
  tmp1 = (data->simulationInfo->realParameter[44] /* data.mu PARAM */);
  (data->localData[0]->realVars[69] /* $cse2 variable */) = omc__omcQ_24DER_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy(threadData, DIVISION_SIM((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (fabs((data->localData[0]->realVars[128] /* penstock.v DUMMY_STATE */)))) * ((data->localData[0]->realVars[121] /* penstock.D_ variable */)),(data->simulationInfo->realParameter[44] /* data.mu PARAM */),"data.mu",equationIndexes), (data->localData[0]->realVars[121] /* penstock.D_ variable */), (data->simulationInfo->realParameter[71] /* penstock.p_eps PARAM */), DIVISION_SIM(((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((sign((data->localData[0]->realVars[128] /* penstock.v DUMMY_STATE */))) * ((data->localData[0]->realVars[45] /* der(penstock.v) DUMMY_DER */)))) * ((data->localData[0]->realVars[121] /* penstock.D_ variable */))) * ((data->simulationInfo->realParameter[44] /* data.mu PARAM */)),(tmp1 * tmp1),"data.mu ^ 2.0",equationIndexes), 0.0, 0.0);
  TRACE_POP
}
/*
equation index: 560
type: SIMPLE_ASSIGN
$DER.penstock.F_f = 0.3926990816987241 * data.rho * penstock.L * ($cse1 * (penstock.v * sign(penstock.v) * $DER.penstock.v * penstock.D_ + $DER.penstock.v * abs(penstock.v) * penstock.D_) + $cse2 * penstock.v * abs(penstock.v) * penstock.D_)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_560(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,560};
  (data->localData[0]->realVars[42] /* der(penstock.F_f) DUMMY_DER */) = (0.3926990816987241) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[69] /* penstock.L PARAM */)) * (((data->localData[0]->realVars[68] /* $cse1 variable */)) * (((data->localData[0]->realVars[128] /* penstock.v DUMMY_STATE */)) * ((sign((data->localData[0]->realVars[128] /* penstock.v DUMMY_STATE */))) * (((data->localData[0]->realVars[45] /* der(penstock.v) DUMMY_DER */)) * ((data->localData[0]->realVars[121] /* penstock.D_ variable */)))) + ((data->localData[0]->realVars[45] /* der(penstock.v) DUMMY_DER */)) * ((fabs((data->localData[0]->realVars[128] /* penstock.v DUMMY_STATE */))) * ((data->localData[0]->realVars[121] /* penstock.D_ variable */)))) + ((data->localData[0]->realVars[69] /* $cse2 variable */)) * (((data->localData[0]->realVars[128] /* penstock.v DUMMY_STATE */)) * ((fabs((data->localData[0]->realVars[128] /* penstock.v DUMMY_STATE */))) * ((data->localData[0]->realVars[121] /* penstock.D_ variable */)))))));
  TRACE_POP
}
/*
equation index: 561
type: SIMPLE_ASSIGN
turbine1.Kdot_i_tr = turbine1.dp * turbine1.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_561(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,561};
  (data->localData[0]->realVars[163] /* turbine1.Kdot_i_tr DUMMY_STATE */) = ((data->localData[0]->realVars[167] /* turbine1.dp DUMMY_STATE */)) * ((data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 562
type: SIMPLE_ASSIGN
turbine1.Wdot_s = turbine1.eta_h * turbine1.Kdot_i_tr
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_562(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,562};
  (data->localData[0]->realVars[165] /* turbine1.Wdot_s DUMMY_STATE */) = ((data->simulationInfo->realParameter[110] /* turbine1.eta_h PARAM */)) * ((data->localData[0]->realVars[163] /* turbine1.Kdot_i_tr DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 563
type: SIMPLE_ASSIGN
division1.y = turbine1.Wdot_s / division2.y
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_563(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,563};
  (data->localData[0]->realVars[103] /* division1.y DUMMY_STATE */) = DIVISION_SIM((data->localData[0]->realVars[165] /* turbine1.Wdot_s DUMMY_STATE */),(data->localData[0]->realVars[104] /* division2.y DUMMY_STATE */),"division2.y",equationIndexes);
  TRACE_POP
}
/*
equation index: 564
type: SIMPLE_ASSIGN
division.y = division1.y / constant1.k
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_564(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,564};
  (data->localData[0]->realVars[102] /* division.y DUMMY_STATE */) = DIVISION_SIM((data->localData[0]->realVars[103] /* division1.y DUMMY_STATE */),(data->simulationInfo->realParameter[23] /* constant1.k PARAM */),"constant1.k",equationIndexes);
  TRACE_POP
}
/*
equation index: 565
type: SIMPLE_ASSIGN
greaterEqual.y = division.y >= constant3.k
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_565(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,565};
  modelica_boolean tmp2;
  relationhysteresis(data, &tmp2, (data->localData[0]->realVars[102] /* division.y DUMMY_STATE */), (data->simulationInfo->realParameter[27] /* constant3.k PARAM */), 3, GreaterEq, GreaterEqZC);
  (data->localData[0]->booleanVars[4] /* greaterEqual.y DISCRETE */) = tmp2;
  TRACE_POP
}
/*
equation index: 566
type: SIMPLE_ASSIGN
lessEqualThreshold.y = division.y <= lessEqualThreshold.threshold
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_566(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,566};
  modelica_boolean tmp3;
  relationhysteresis(data, &tmp3, (data->localData[0]->realVars[102] /* division.y DUMMY_STATE */), (data->simulationInfo->realParameter[65] /* lessEqualThreshold.threshold PARAM */), 4, LessEq, LessEqZC);
  (data->localData[0]->booleanVars[5] /* lessEqualThreshold.y DISCRETE */) = tmp3;
  TRACE_POP
}
/*
equation index: 567
type: SIMPLE_ASSIGN
and1.y = lessEqualThreshold.y and greaterEqual.y
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_567(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,567};
  (data->localData[0]->booleanVars[0] /* and1.y DISCRETE */) = ((data->localData[0]->booleanVars[5] /* lessEqualThreshold.y DISCRETE */) && (data->localData[0]->booleanVars[4] /* greaterEqual.y DISCRETE */));
  TRACE_POP
}
/*
equation index: 568
type: SIMPLE_ASSIGN
TM_Speed_Torque_Out = if and1.y then booleanToInteger.integerTrue else booleanToInteger.integerFalse
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_568(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,568};
  (data->localData[0]->integerVars[2] /* TM_Speed_Torque_Out variable */) = ((data->localData[0]->booleanVars[0] /* and1.y DISCRETE */)?(data->simulationInfo->integerParameter[1] /* booleanToInteger.integerTrue PARAM */):(data->simulationInfo->integerParameter[0] /* booleanToInteger.integerFalse PARAM */));
  TRACE_POP
}
/*
equation index: 569
type: SIMPLE_ASSIGN
TM_Start_Stop_Out = TM_Speed_Torque_Out
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_569(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,569};
  (data->localData[0]->integerVars[3] /* TM_Start_Stop_Out variable */) = (data->localData[0]->integerVars[2] /* TM_Speed_Torque_Out variable */);
  TRACE_POP
}
/*
equation index: 570
type: SIMPLE_ASSIGN
TM_Forward_Reverse_Out = TM_Speed_Torque_Out
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_570(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,570};
  (data->localData[0]->integerVars[1] /* TM_Forward_Reverse_Out variable */) = (data->localData[0]->integerVars[2] /* TM_Speed_Torque_Out variable */);
  TRACE_POP
}
/*
equation index: 571
type: SIMPLE_ASSIGN
booleanToReal.y = if and1.y then booleanToReal.realTrue else booleanToReal.realFalse
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_571(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,571};
  (data->localData[0]->realVars[87] /* booleanToReal.y DUMMY_STATE */) = ((data->localData[0]->booleanVars[0] /* and1.y DISCRETE */)?(data->simulationInfo->realParameter[20] /* booleanToReal.realTrue PARAM */):(data->simulationInfo->realParameter[19] /* booleanToReal.realFalse PARAM */));
  TRACE_POP
}
/*
equation index: 572
type: SIMPLE_ASSIGN
TM_Torque_Out = division.y * booleanToReal.y
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_572(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,572};
  (data->localData[0]->realVars[84] /* TM_Torque_Out variable */) = ((data->localData[0]->realVars[102] /* division.y DUMMY_STATE */)) * ((data->localData[0]->realVars[87] /* booleanToReal.y DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 573
type: SIMPLE_ASSIGN
$outputAlias_TM_Torque_Out = TM_Torque_Out
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_573(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,573};
  (data->localData[0]->realVars[78] /* $outputAlias_TM_Torque_Out DUMMY_STATE */) = (data->localData[0]->realVars[84] /* TM_Torque_Out variable */);
  TRACE_POP
}
/*
equation index: 574
type: SIMPLE_ASSIGN
turbine1.torqueLimit.u = turbine1.Wdot_s / turbine1.div0protect.y
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_574(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,574};
  (data->localData[0]->realVars[192] /* turbine1.torqueLimit.u variable */) = DIVISION_SIM((data->localData[0]->realVars[165] /* turbine1.Wdot_s DUMMY_STATE */),(data->localData[0]->realVars[166] /* turbine1.div0protect.y variable */),"turbine1.div0protect.y",equationIndexes);
  TRACE_POP
}
/*
equation index: 575
type: SIMPLE_ASSIGN
turbine1.torque.tau = smooth(0, if turbine1.torqueLimit.u > turbine1.torqueLimit.uMax then turbine1.torqueLimit.uMax else if turbine1.torqueLimit.u < turbine1.torqueLimit.uMin then turbine1.torqueLimit.uMin else turbine1.torqueLimit.u)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_575(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,575};
  modelica_boolean tmp4;
  modelica_boolean tmp5;
  modelica_boolean tmp6;
  modelica_real tmp7;
  tmp4 = Greater((data->localData[0]->realVars[192] /* turbine1.torqueLimit.u variable */),(data->simulationInfo->realParameter[149] /* turbine1.torqueLimit.uMax PARAM */));
  tmp6 = (modelica_boolean)tmp4;
  if(tmp6)
  {
    tmp7 = (data->simulationInfo->realParameter[149] /* turbine1.torqueLimit.uMax PARAM */);
  }
  else
  {
    tmp5 = Less((data->localData[0]->realVars[192] /* turbine1.torqueLimit.u variable */),(data->simulationInfo->realParameter[150] /* turbine1.torqueLimit.uMin PARAM */));
    tmp7 = (tmp5?(data->simulationInfo->realParameter[150] /* turbine1.torqueLimit.uMin PARAM */):(data->localData[0]->realVars[192] /* turbine1.torqueLimit.u variable */));
  }
  (data->localData[0]->realVars[191] /* turbine1.torque.tau variable */) = tmp7;
  TRACE_POP
}
/*
equation index: 576
type: SIMPLE_ASSIGN
turbine1.toSysSpeed.flange_a.tau = turbine1.torque.tau - turbine1.inertia.J * turbine1.inertia.a
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_576(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,576};
  (data->localData[0]->realVars[187] /* turbine1.toSysSpeed.flange_a.tau variable */) = (data->localData[0]->realVars[191] /* turbine1.torque.tau variable */) - (((data->simulationInfo->realParameter[121] /* turbine1.inertia.J PARAM */)) * ((data->localData[0]->realVars[177] /* turbine1.inertia.a variable */)));
  TRACE_POP
}
/*
equation index: 577
type: SIMPLE_ASSIGN
turbine1.toSysSpeed.flange_b.tau = (-turbine1.toSysSpeed.ratio) * turbine1.toSysSpeed.flange_a.tau
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_577(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,577};
  (data->localData[0]->realVars[188] /* turbine1.toSysSpeed.flange_b.tau variable */) = ((-(data->simulationInfo->realParameter[148] /* turbine1.toSysSpeed.ratio PARAM */))) * ((data->localData[0]->realVars[187] /* turbine1.toSysSpeed.flange_a.tau variable */));
  TRACE_POP
}
/*
equation index: 578
type: SIMPLE_ASSIGN
discharge.dp = discharge.p_o - discharge.p_i
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_578(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,578};
  (data->localData[0]->realVars[96] /* discharge.dp variable */) = (data->localData[0]->realVars[100] /* discharge.p_o variable */) - (data->localData[0]->realVars[99] /* discharge.p_i DUMMY_STATE */);
  TRACE_POP
}
/*
equation index: 579
type: SIMPLE_ASSIGN
$DER.discharge.v = $DER.discharge.Vdot / discharge.A_
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_579(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,579};
  (data->localData[0]->realVars[33] /* der(discharge.v) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[30] /* der(discharge.Vdot) DUMMY_DER */),(data->localData[0]->realVars[88] /* discharge.A_ variable */),"discharge.A_",equationIndexes);
  TRACE_POP
}
/*
equation index: 580
type: SIMPLE_ASSIGN
$DER.discharge.F_f = 0.3926990816987241 * data.rho * discharge.L * ($cse7 * (discharge.v * sign(discharge.v) * $DER.discharge.v * discharge.D_ + $DER.discharge.v * abs(discharge.v) * discharge.D_) + data.rho * sign(discharge.v) * $DER.discharge.v * discharge.D_ ^ 2.0 * $cse8 * discharge.v * abs(discharge.v) / data.mu)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_580(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,580};
  modelica_real tmp8;
  tmp8 = (data->localData[0]->realVars[91] /* discharge.D_ variable */);
  (data->localData[0]->realVars[28] /* der(discharge.F_f) DUMMY_DER */) = (0.3926990816987241) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[51] /* discharge.L PARAM */)) * (((data->localData[0]->realVars[74] /* $cse7 variable */)) * (((data->localData[0]->realVars[101] /* discharge.v DUMMY_STATE */)) * ((sign((data->localData[0]->realVars[101] /* discharge.v DUMMY_STATE */))) * (((data->localData[0]->realVars[33] /* der(discharge.v) DUMMY_DER */)) * ((data->localData[0]->realVars[91] /* discharge.D_ variable */)))) + ((data->localData[0]->realVars[33] /* der(discharge.v) DUMMY_DER */)) * ((fabs((data->localData[0]->realVars[101] /* discharge.v DUMMY_STATE */))) * ((data->localData[0]->realVars[91] /* discharge.D_ variable */)))) + ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((sign((data->localData[0]->realVars[101] /* discharge.v DUMMY_STATE */))) * (((data->localData[0]->realVars[33] /* der(discharge.v) DUMMY_DER */)) * (((tmp8 * tmp8)) * (DIVISION_SIM(((data->localData[0]->realVars[75] /* $cse8 variable */)) * (((data->localData[0]->realVars[101] /* discharge.v DUMMY_STATE */)) * (fabs((data->localData[0]->realVars[101] /* discharge.v DUMMY_STATE */)))),(data->simulationInfo->realParameter[44] /* data.mu PARAM */),"data.mu",equationIndexes))))))));
  TRACE_POP
}
/*
equation index: 581
type: SIMPLE_ASSIGN
$DER.intake.v = $DER.intake.Vdot / intake.A_
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_581(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,581};
  (data->localData[0]->realVars[41] /* der(intake.v) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[38] /* der(intake.Vdot) DUMMY_DER */),(data->localData[0]->realVars[105] /* intake.A_ variable */),"intake.A_",equationIndexes);
  TRACE_POP
}
/*
equation index: 582
type: SIMPLE_ASSIGN
$cse6 = $DER$OpenHPL$PFunctions$PDarcyFriction$PfDarcy(data.rho * abs(intake.v) * intake.D_ / data.mu, intake.D_, intake.p_eps, data.rho * sign(intake.v) * $DER.intake.v * intake.D_ * data.mu / data.mu ^ 2.0, 0.0, 0.0)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_582(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,582};
  modelica_real tmp9;
  tmp9 = (data->simulationInfo->realParameter[44] /* data.mu PARAM */);
  (data->localData[0]->realVars[73] /* $cse6 variable */) = omc__omcQ_24DER_24OpenHPL_24PFunctions_24PDarcyFriction_24PfDarcy(threadData, DIVISION_SIM((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (fabs((data->localData[0]->realVars[117] /* intake.v DUMMY_STATE */)))) * ((data->localData[0]->realVars[108] /* intake.D_ variable */)),(data->simulationInfo->realParameter[44] /* data.mu PARAM */),"data.mu",equationIndexes), (data->localData[0]->realVars[108] /* intake.D_ variable */), (data->simulationInfo->realParameter[64] /* intake.p_eps PARAM */), DIVISION_SIM(((((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((sign((data->localData[0]->realVars[117] /* intake.v DUMMY_STATE */))) * ((data->localData[0]->realVars[41] /* der(intake.v) DUMMY_DER */)))) * ((data->localData[0]->realVars[108] /* intake.D_ variable */))) * ((data->simulationInfo->realParameter[44] /* data.mu PARAM */)),(tmp9 * tmp9),"data.mu ^ 2.0",equationIndexes), 0.0, 0.0);
  TRACE_POP
}
/*
equation index: 583
type: SIMPLE_ASSIGN
$DER.intake.F_f = 0.3926990816987241 * data.rho * intake.L * ($cse5 * (intake.v * sign(intake.v) * $DER.intake.v * intake.D_ + $DER.intake.v * abs(intake.v) * intake.D_) + $cse6 * intake.v * abs(intake.v) * intake.D_)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_583(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,583};
  (data->localData[0]->realVars[37] /* der(intake.F_f) DUMMY_DER */) = (0.3926990816987241) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[62] /* intake.L PARAM */)) * (((data->localData[0]->realVars[72] /* $cse5 variable */)) * (((data->localData[0]->realVars[117] /* intake.v DUMMY_STATE */)) * ((sign((data->localData[0]->realVars[117] /* intake.v DUMMY_STATE */))) * (((data->localData[0]->realVars[41] /* der(intake.v) DUMMY_DER */)) * ((data->localData[0]->realVars[108] /* intake.D_ variable */)))) + ((data->localData[0]->realVars[41] /* der(intake.v) DUMMY_DER */)) * ((fabs((data->localData[0]->realVars[117] /* intake.v DUMMY_STATE */))) * ((data->localData[0]->realVars[108] /* intake.D_ variable */)))) + ((data->localData[0]->realVars[73] /* $cse6 variable */)) * (((data->localData[0]->realVars[117] /* intake.v DUMMY_STATE */)) * ((fabs((data->localData[0]->realVars[117] /* intake.v DUMMY_STATE */))) * ((data->localData[0]->realVars[108] /* intake.D_ variable */)))))));
  TRACE_POP
}
/*
equation index: 584
type: SIMPLE_ASSIGN
intake.dp = intake.p_o - intake.p_i
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_584(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,584};
  (data->localData[0]->realVars[112] /* intake.dp variable */) = (data->localData[0]->realVars[116] /* intake.p_o DUMMY_STATE */) - (data->localData[0]->realVars[115] /* intake.p_i variable */);
  TRACE_POP
}
/*
equation index: 585
type: SIMPLE_ASSIGN
penstock.dp = penstock.p_o - intake.p_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_585(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,585};
  (data->localData[0]->realVars[125] /* penstock.dp variable */) = (data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->localData[0]->realVars[116] /* intake.p_o DUMMY_STATE */);
  TRACE_POP
}
/*
equation index: 621
type: LINEAR

<var>$DER.$DER.surgeTank.v</var>
<row>

</row>
<matrix>
</matrix>
*/
OMC_DISABLE_OPT
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_621(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,621};
  /* Linear equation system */
  int retValue;
  double aux_x[1] = { (data->localData[1]->realVars[21] /* der(der(surgeTank.v)) DUMMY_DER */) };
  if(ACTIVE_STREAM(LOG_DT))
  {
    infoStreamPrint(LOG_DT, 1, "Solving linear system 621 (STRICT TEARING SET if tearing enabled) at time = %18.10e", data->localData[0]->timeValue);
    messageClose(LOG_DT);
  }
  
  retValue = solve_linear_system(data, threadData, 2, &aux_x[0]);
  
  /* check if solution process was successful */
  if (retValue > 0){
    const int indexes[2] = {1,621};
    throwStreamPrintWithEquationIndexes(threadData, omc_dummyFileInfo, indexes, "Solving linear system 621 failed at time=%.15g.\nFor more information please use -lv LOG_LS.", data->localData[0]->timeValue);
  }
  /* write solution */
  (data->localData[0]->realVars[21] /* der(der(surgeTank.v)) DUMMY_DER */) = aux_x[0];

  TRACE_POP
}
/*
equation index: 622
type: SIMPLE_ASSIGN
$DER.turbine1.Kdot_i_tr = turbine1.dp * $DER.turbine1.Vdot + $DER.turbine1.dp * turbine1.Vdot
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_622(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,622};
  (data->localData[0]->realVars[57] /* der(turbine1.Kdot_i_tr) DUMMY_DER */) = ((data->localData[0]->realVars[167] /* turbine1.dp DUMMY_STATE */)) * ((data->localData[0]->realVars[58] /* der(turbine1.Vdot) DUMMY_DER */)) + ((data->localData[0]->realVars[60] /* der(turbine1.dp) DUMMY_DER */)) * ((data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 623
type: SIMPLE_ASSIGN
$DER.turbine1.Wdot_s = turbine1.eta_h * $DER.turbine1.Kdot_i_tr
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_623(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,623};
  (data->localData[0]->realVars[59] /* der(turbine1.Wdot_s) DUMMY_DER */) = ((data->simulationInfo->realParameter[110] /* turbine1.eta_h PARAM */)) * ((data->localData[0]->realVars[57] /* der(turbine1.Kdot_i_tr) DUMMY_DER */));
  TRACE_POP
}
/*
equation index: 624
type: SIMPLE_ASSIGN
$DER.division1.y = $DER.turbine1.Wdot_s / division2.y
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_624(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,624};
  (data->localData[0]->realVars[35] /* der(division1.y) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[59] /* der(turbine1.Wdot_s) DUMMY_DER */),(data->localData[0]->realVars[104] /* division2.y DUMMY_STATE */),"division2.y",equationIndexes);
  TRACE_POP
}
/*
equation index: 625
type: SIMPLE_ASSIGN
$DER.division.y = $DER.division1.y / constant1.k
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_625(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,625};
  (data->localData[0]->realVars[34] /* der(division.y) DUMMY_DER */) = DIVISION_SIM((data->localData[0]->realVars[35] /* der(division1.y) DUMMY_DER */),(data->simulationInfo->realParameter[23] /* constant1.k PARAM */),"constant1.k",equationIndexes);
  TRACE_POP
}
/*
equation index: 626
type: SIMPLE_ASSIGN
$TM_Torque_Out_der = $DER.division.y * booleanToReal.y
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_626(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,626};
  (data->localData[0]->realVars[67] /* $TM_Torque_Out_der variable */) = ((data->localData[0]->realVars[34] /* der(division.y) DUMMY_DER */)) * ((data->localData[0]->realVars[87] /* booleanToReal.y DUMMY_STATE */));
  TRACE_POP
}
/*
equation index: 627
type: SIMPLE_ASSIGN
$DER.$outputAlias_TM_Torque_Out = $TM_Torque_Out_der
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_627(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,627};
  (data->localData[0]->realVars[24] /* der($outputAlias_TM_Torque_Out) DUMMY_DER */) = (data->localData[0]->realVars[67] /* $TM_Torque_Out_der variable */);
  TRACE_POP
}
/*
equation index: 628
type: SIMPLE_ASSIGN
$SM_Start_Torque_out_der = if time < ServoMotorTorque.startTime then 0.0 else if time < ServoMotorTorque.startTime + ServoMotorTorque.duration then ServoMotorTorque.height * ServoMotorTorque.duration / ServoMotorTorque.duration ^ 2.0 else 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_628(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,628};
  modelica_boolean tmp10;
  modelica_boolean tmp11;
  modelica_real tmp12;
  modelica_boolean tmp13;
  modelica_real tmp14;
  modelica_boolean tmp15;
  modelica_real tmp16;
  relationhysteresis(data, &tmp10, data->localData[0]->timeValue, (data->simulationInfo->realParameter[4] /* ServoMotorTorque.startTime PARAM */), 7, Less, LessZC);
  tmp15 = (modelica_boolean)tmp10;
  if(tmp15)
  {
    tmp16 = 0.0;
  }
  else
  {
    relationhysteresis(data, &tmp11, data->localData[0]->timeValue, (data->simulationInfo->realParameter[4] /* ServoMotorTorque.startTime PARAM */) + (data->simulationInfo->realParameter[1] /* ServoMotorTorque.duration PARAM */), 8, Less, LessZC);
    tmp13 = (modelica_boolean)tmp11;
    if(tmp13)
    {
      tmp12 = (data->simulationInfo->realParameter[1] /* ServoMotorTorque.duration PARAM */);
      tmp14 = DIVISION_SIM(((data->simulationInfo->realParameter[2] /* ServoMotorTorque.height PARAM */)) * ((data->simulationInfo->realParameter[1] /* ServoMotorTorque.duration PARAM */)),(tmp12 * tmp12),"ServoMotorTorque.duration ^ 2.0",equationIndexes);
    }
    else
    {
      tmp14 = 0.0;
    }
    tmp16 = tmp14;
  }
  (data->localData[0]->realVars[66] /* $SM_Start_Torque_out_der variable */) = tmp16;
  TRACE_POP
}
/*
equation index: 629
type: SIMPLE_ASSIGN
$DER.$outputAlias_SM_Start_Torque_out = $SM_Start_Torque_out_der
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_629(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,629};
  (data->localData[0]->realVars[23] /* der($outputAlias_SM_Start_Torque_out) DUMMY_DER */) = (data->localData[0]->realVars[66] /* $SM_Start_Torque_out_der variable */);
  TRACE_POP
}
/*
equation index: 630
type: SIMPLE_ASSIGN
$SM_Speed_Out_der = if time < ServoMotorVoltage.startTime then 0.0 else if time < ServoMotorVoltage.startTime + ServoMotorVoltage.duration then ServoMotorVoltage.height * ServoMotorVoltage.duration / ServoMotorVoltage.duration ^ 2.0 else 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_630(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,630};
  modelica_boolean tmp17;
  modelica_boolean tmp18;
  modelica_real tmp19;
  modelica_boolean tmp20;
  modelica_real tmp21;
  modelica_boolean tmp22;
  modelica_real tmp23;
  relationhysteresis(data, &tmp17, data->localData[0]->timeValue, (data->simulationInfo->realParameter[12] /* ServoMotorVoltage.startTime PARAM */), 5, Less, LessZC);
  tmp22 = (modelica_boolean)tmp17;
  if(tmp22)
  {
    tmp23 = 0.0;
  }
  else
  {
    relationhysteresis(data, &tmp18, data->localData[0]->timeValue, (data->simulationInfo->realParameter[12] /* ServoMotorVoltage.startTime PARAM */) + (data->simulationInfo->realParameter[9] /* ServoMotorVoltage.duration PARAM */), 6, Less, LessZC);
    tmp20 = (modelica_boolean)tmp18;
    if(tmp20)
    {
      tmp19 = (data->simulationInfo->realParameter[9] /* ServoMotorVoltage.duration PARAM */);
      tmp21 = DIVISION_SIM(((data->simulationInfo->realParameter[10] /* ServoMotorVoltage.height PARAM */)) * ((data->simulationInfo->realParameter[9] /* ServoMotorVoltage.duration PARAM */)),(tmp19 * tmp19),"ServoMotorVoltage.duration ^ 2.0",equationIndexes);
    }
    else
    {
      tmp21 = 0.0;
    }
    tmp23 = tmp21;
  }
  (data->localData[0]->realVars[65] /* $SM_Speed_Out_der variable */) = tmp23;
  TRACE_POP
}
/*
equation index: 631
type: SIMPLE_ASSIGN
$DER.$outputAlias_SM_Speed_Out = $SM_Speed_Out_der
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_631(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,631};
  (data->localData[0]->realVars[22] /* der($outputAlias_SM_Speed_Out) DUMMY_DER */) = (data->localData[0]->realVars[65] /* $SM_Speed_Out_der variable */);
  TRACE_POP
}
/*
equation index: 632
type: SIMPLE_ASSIGN
SM_Start_Torque_out = ServoMotorTorque.offset + (if time < ServoMotorTorque.startTime then 0.0 else if time < ServoMotorTorque.startTime + ServoMotorTorque.duration then (time - ServoMotorTorque.startTime) * ServoMotorTorque.height / ServoMotorTorque.duration else ServoMotorTorque.height)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_632(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,632};
  modelica_boolean tmp24;
  modelica_boolean tmp25;
  modelica_boolean tmp26;
  modelica_real tmp27;
  relationhysteresis(data, &tmp24, data->localData[0]->timeValue, (data->simulationInfo->realParameter[4] /* ServoMotorTorque.startTime PARAM */), 7, Less, LessZC);
  tmp26 = (modelica_boolean)tmp24;
  if(tmp26)
  {
    tmp27 = 0.0;
  }
  else
  {
    relationhysteresis(data, &tmp25, data->localData[0]->timeValue, (data->simulationInfo->realParameter[4] /* ServoMotorTorque.startTime PARAM */) + (data->simulationInfo->realParameter[1] /* ServoMotorTorque.duration PARAM */), 8, Less, LessZC);
    tmp27 = (tmp25?DIVISION_SIM((data->localData[0]->timeValue - (data->simulationInfo->realParameter[4] /* ServoMotorTorque.startTime PARAM */)) * ((data->simulationInfo->realParameter[2] /* ServoMotorTorque.height PARAM */)),(data->simulationInfo->realParameter[1] /* ServoMotorTorque.duration PARAM */),"ServoMotorTorque.duration",equationIndexes):(data->simulationInfo->realParameter[2] /* ServoMotorTorque.height PARAM */));
  }
  (data->localData[0]->realVars[81] /* SM_Start_Torque_out variable */) = (data->simulationInfo->realParameter[3] /* ServoMotorTorque.offset PARAM */) + tmp27;
  TRACE_POP
}
/*
equation index: 633
type: SIMPLE_ASSIGN
and2.u2 = SM_Start_Torque_out > greaterThreshold2.threshold
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_633(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,633};
  modelica_boolean tmp28;
  relationhysteresis(data, &tmp28, (data->localData[0]->realVars[81] /* SM_Start_Torque_out variable */), (data->simulationInfo->realParameter[58] /* greaterThreshold2.threshold PARAM */), 9, Greater, GreaterZC);
  (data->localData[0]->booleanVars[2] /* and2.u2 DISCRETE */) = tmp28;
  TRACE_POP
}
/*
equation index: 634
type: SIMPLE_ASSIGN
$outputAlias_SM_Start_Torque_out = SM_Start_Torque_out
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_634(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,634};
  (data->localData[0]->realVars[77] /* $outputAlias_SM_Start_Torque_out DUMMY_STATE */) = (data->localData[0]->realVars[81] /* SM_Start_Torque_out variable */);
  TRACE_POP
}
/*
equation index: 635
type: SIMPLE_ASSIGN
SM_Speed_Out = ServoMotorVoltage.offset + (if time < ServoMotorVoltage.startTime then 0.0 else if time < ServoMotorVoltage.startTime + ServoMotorVoltage.duration then (time - ServoMotorVoltage.startTime) * ServoMotorVoltage.height / ServoMotorVoltage.duration else ServoMotorVoltage.height)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_635(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,635};
  modelica_boolean tmp29;
  modelica_boolean tmp30;
  modelica_boolean tmp31;
  modelica_real tmp32;
  relationhysteresis(data, &tmp29, data->localData[0]->timeValue, (data->simulationInfo->realParameter[12] /* ServoMotorVoltage.startTime PARAM */), 5, Less, LessZC);
  tmp31 = (modelica_boolean)tmp29;
  if(tmp31)
  {
    tmp32 = 0.0;
  }
  else
  {
    relationhysteresis(data, &tmp30, data->localData[0]->timeValue, (data->simulationInfo->realParameter[12] /* ServoMotorVoltage.startTime PARAM */) + (data->simulationInfo->realParameter[9] /* ServoMotorVoltage.duration PARAM */), 6, Less, LessZC);
    tmp32 = (tmp30?DIVISION_SIM((data->localData[0]->timeValue - (data->simulationInfo->realParameter[12] /* ServoMotorVoltage.startTime PARAM */)) * ((data->simulationInfo->realParameter[10] /* ServoMotorVoltage.height PARAM */)),(data->simulationInfo->realParameter[9] /* ServoMotorVoltage.duration PARAM */),"ServoMotorVoltage.duration",equationIndexes):(data->simulationInfo->realParameter[10] /* ServoMotorVoltage.height PARAM */));
  }
  (data->localData[0]->realVars[80] /* SM_Speed_Out variable */) = (data->simulationInfo->realParameter[11] /* ServoMotorVoltage.offset PARAM */) + tmp32;
  TRACE_POP
}
/*
equation index: 636
type: SIMPLE_ASSIGN
and2.u1 = SM_Speed_Out > greaterThreshold1.threshold
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_636(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,636};
  modelica_boolean tmp33;
  relationhysteresis(data, &tmp33, (data->localData[0]->realVars[80] /* SM_Speed_Out variable */), (data->simulationInfo->realParameter[57] /* greaterThreshold1.threshold PARAM */), 10, Greater, GreaterZC);
  (data->localData[0]->booleanVars[1] /* and2.u1 DISCRETE */) = tmp33;
  TRACE_POP
}
/*
equation index: 637
type: SIMPLE_ASSIGN
booleanToInteger1.u = and2.u1 and and2.u2
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_637(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,637};
  (data->localData[0]->booleanVars[3] /* booleanToInteger1.u DISCRETE */) = ((data->localData[0]->booleanVars[1] /* and2.u1 DISCRETE */) && (data->localData[0]->booleanVars[2] /* and2.u2 DISCRETE */));
  TRACE_POP
}
/*
equation index: 638
type: SIMPLE_ASSIGN
SM_Start_Stop_Out = if booleanToInteger1.u then booleanToInteger1.integerTrue else booleanToInteger1.integerFalse
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_638(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,638};
  (data->localData[0]->integerVars[0] /* SM_Start_Stop_Out variable */) = ((data->localData[0]->booleanVars[3] /* booleanToInteger1.u DISCRETE */)?(data->simulationInfo->integerParameter[3] /* booleanToInteger1.integerTrue PARAM */):(data->simulationInfo->integerParameter[2] /* booleanToInteger1.integerFalse PARAM */));
  TRACE_POP
}
/*
equation index: 639
type: SIMPLE_ASSIGN
$outputAlias_SM_Speed_Out = SM_Speed_Out
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_639(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,639};
  (data->localData[0]->realVars[76] /* $outputAlias_SM_Speed_Out DUMMY_STATE */) = (data->localData[0]->realVars[80] /* SM_Speed_Out variable */);
  TRACE_POP
}
/*
equation index: 641
type: ALGORITHM

  assert(turbine1.torqueLimit.uMax >= turbine1.torqueLimit.uMin, "Limiter: Limits must be consistent. However, uMax (=" + String(turbine1.torqueLimit.uMax, 6, 0, true) + ") < uMin (=" + String(turbine1.torqueLimit.uMin, 6, 0, true) + ")");
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_641(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,641};
  modelica_boolean tmp34;
  static const MMC_DEFSTRINGLIT(tmp35,52,"Limiter: Limits must be consistent. However, uMax (=");
  modelica_string tmp36;
  modelica_metatype tmpMeta37;
  static const MMC_DEFSTRINGLIT(tmp38,11,") < uMin (=");
  modelica_metatype tmpMeta39;
  modelica_string tmp40;
  modelica_metatype tmpMeta41;
  modelica_metatype tmpMeta42;
  static int tmp43 = 0;
  {
    tmp34 = GreaterEq((data->simulationInfo->realParameter[149] /* turbine1.torqueLimit.uMax PARAM */),(data->simulationInfo->realParameter[150] /* turbine1.torqueLimit.uMin PARAM */));
    if(!tmp34)
    {
      tmp36 = modelica_real_to_modelica_string((data->simulationInfo->realParameter[149] /* turbine1.torqueLimit.uMax PARAM */), ((modelica_integer) 6), ((modelica_integer) 0), 1);
      tmpMeta37 = stringAppend(MMC_REFSTRINGLIT(tmp35),tmp36);
      tmpMeta39 = stringAppend(tmpMeta37,MMC_REFSTRINGLIT(tmp38));
      tmp40 = modelica_real_to_modelica_string((data->simulationInfo->realParameter[150] /* turbine1.torqueLimit.uMin PARAM */), ((modelica_integer) 6), ((modelica_integer) 0), 1);
      tmpMeta41 = stringAppend(tmpMeta39,tmp40);
      tmpMeta42 = stringAppend(tmpMeta41,(modelica_string) mmc_strings_len1[41]);
      {
        const char* assert_cond = "(turbine1.torqueLimit.uMax >= turbine1.torqueLimit.uMin)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Nonlinear.mo",19,9,20,65,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta42));
          data->simulationInfo->needToReThrow = 1;
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Nonlinear.mo",19,9,20,65,0};
          omc_assert_withEquationIndexes(threadData, info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta42));
        }
      }
    }
  }
  TRACE_POP
}
/*
equation index: 640
type: ALGORITHM

  assert(turbine1.div0protect.uMax >= turbine1.div0protect.uMin, "Limiter: Limits must be consistent. However, uMax (=" + String(turbine1.div0protect.uMax, 6, 0, true) + ") < uMin (=" + String(turbine1.div0protect.uMin, 6, 0, true) + ")");
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_640(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,640};
  modelica_boolean tmp44;
  static const MMC_DEFSTRINGLIT(tmp45,52,"Limiter: Limits must be consistent. However, uMax (=");
  modelica_string tmp46;
  modelica_metatype tmpMeta47;
  static const MMC_DEFSTRINGLIT(tmp48,11,") < uMin (=");
  modelica_metatype tmpMeta49;
  modelica_string tmp50;
  modelica_metatype tmpMeta51;
  modelica_metatype tmpMeta52;
  static int tmp53 = 0;
  {
    tmp44 = GreaterEq((data->simulationInfo->realParameter[108] /* turbine1.div0protect.uMax PARAM */),(data->simulationInfo->realParameter[109] /* turbine1.div0protect.uMin PARAM */));
    if(!tmp44)
    {
      tmp46 = modelica_real_to_modelica_string((data->simulationInfo->realParameter[108] /* turbine1.div0protect.uMax PARAM */), ((modelica_integer) 6), ((modelica_integer) 0), 1);
      tmpMeta47 = stringAppend(MMC_REFSTRINGLIT(tmp45),tmp46);
      tmpMeta49 = stringAppend(tmpMeta47,MMC_REFSTRINGLIT(tmp48));
      tmp50 = modelica_real_to_modelica_string((data->simulationInfo->realParameter[109] /* turbine1.div0protect.uMin PARAM */), ((modelica_integer) 6), ((modelica_integer) 0), 1);
      tmpMeta51 = stringAppend(tmpMeta49,tmp50);
      tmpMeta52 = stringAppend(tmpMeta51,(modelica_string) mmc_strings_len1[41]);
      {
        const char* assert_cond = "(turbine1.div0protect.uMax >= turbine1.div0protect.uMin)";
        if (data->simulationInfo->noThrowAsserts) {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Nonlinear.mo",19,9,20,65,0};
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, info, 0, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta52));
          data->simulationInfo->needToReThrow = 1;
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Blocks/Nonlinear.mo",19,9,20,65,0};
          omc_assert_withEquationIndexes(threadData, info, equationIndexes, "The following assertion has been violated %sat time %f\n(%s) --> \"%s\"", initial() ? "during initialization " : "", data->localData[0]->timeValue, assert_cond, MMC_STRINGDATA(tmpMeta52));
        }
      }
    }
  }
  TRACE_POP
}

OMC_DISABLE_OPT
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionDAE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  int equationIndexes[1] = {0};
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_DAE);
#endif

  data->simulationInfo->needToIterate = 0;
  data->simulationInfo->discreteCall = 1;
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionLocalKnownVars(data, threadData);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_459(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_460(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_461(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_462(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_463(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_464(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_465(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_466(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_467(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_468(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_469(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_470(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_471(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_472(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_473(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_474(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_475(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_476(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_477(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_478(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_479(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_480(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_481(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_482(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_483(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_484(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_485(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_486(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_487(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_488(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_489(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_490(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_491(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_492(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_493(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_494(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_495(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_496(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_497(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_498(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_499(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_500(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_501(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_502(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_503(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_504(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_505(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_506(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_507(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_508(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_509(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_510(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_511(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_512(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_513(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_514(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_515(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_516(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_517(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_518(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_554(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_555(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_556(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_557(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_558(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_559(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_560(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_561(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_562(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_563(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_564(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_565(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_566(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_567(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_568(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_569(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_570(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_571(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_572(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_573(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_574(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_575(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_576(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_577(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_578(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_579(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_580(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_581(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_582(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_583(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_584(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_585(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_621(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_622(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_623(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_624(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_625(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_626(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_627(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_628(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_629(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_630(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_631(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_632(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_633(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_634(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_635(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_636(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_637(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_638(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_639(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_641(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_640(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_DAE);
#endif
  TRACE_POP
  return 0;
}


int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionLocalKnownVars(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}


/* forwarded equations */
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_468(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_469(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_476(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_477(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_479(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_480(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_482(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_483(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_486(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_487(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_491(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_492(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_494(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_495(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_497(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_498(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_499(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_500(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_501(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_504(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_505(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_508(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_509(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_511(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_512(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_516(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_517(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_554(DATA* data, threadData_t *threadData);

static void functionODE_system0(DATA *data, threadData_t *threadData)
{
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_468(data, threadData);
    threadData->lastEquationSolved = 468;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_469(data, threadData);
    threadData->lastEquationSolved = 469;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_476(data, threadData);
    threadData->lastEquationSolved = 476;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_477(data, threadData);
    threadData->lastEquationSolved = 477;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_479(data, threadData);
    threadData->lastEquationSolved = 479;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_480(data, threadData);
    threadData->lastEquationSolved = 480;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_482(data, threadData);
    threadData->lastEquationSolved = 482;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_483(data, threadData);
    threadData->lastEquationSolved = 483;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_486(data, threadData);
    threadData->lastEquationSolved = 486;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_487(data, threadData);
    threadData->lastEquationSolved = 487;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_491(data, threadData);
    threadData->lastEquationSolved = 491;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_492(data, threadData);
    threadData->lastEquationSolved = 492;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_494(data, threadData);
    threadData->lastEquationSolved = 494;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_495(data, threadData);
    threadData->lastEquationSolved = 495;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_497(data, threadData);
    threadData->lastEquationSolved = 497;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_498(data, threadData);
    threadData->lastEquationSolved = 498;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_499(data, threadData);
    threadData->lastEquationSolved = 499;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_500(data, threadData);
    threadData->lastEquationSolved = 500;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_501(data, threadData);
    threadData->lastEquationSolved = 501;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_504(data, threadData);
    threadData->lastEquationSolved = 504;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_505(data, threadData);
    threadData->lastEquationSolved = 505;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_508(data, threadData);
    threadData->lastEquationSolved = 508;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_509(data, threadData);
    threadData->lastEquationSolved = 509;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_511(data, threadData);
    threadData->lastEquationSolved = 511;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_512(data, threadData);
    threadData->lastEquationSolved = 512;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_516(data, threadData);
    threadData->lastEquationSolved = 516;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_517(data, threadData);
    threadData->lastEquationSolved = 517;
  }
  {
    TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_554(data, threadData);
    threadData->lastEquationSolved = 554;
  }
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionODE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_FUNCTION_ODE);
#endif

  
  data->simulationInfo->callStatistics.functionODE++;
  
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionLocalKnownVars(data, threadData);
  functionODE_system0(data, threadData);

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_FUNCTION_ODE);
#endif

  TRACE_POP
  return 0;
}

/* forward the main in the simulation runtime */
extern int _main_SimulationRuntime(int argc, char**argv, DATA *data, threadData_t *threadData);

#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_12jac.h"
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_13opt.h"

struct OpenModelicaGeneratedFunctionCallbacks TestPackage_ActiveWork_WaterModel_HydroPowerModel1_callback = {
   NULL,    /* performSimulation */
   NULL,    /* performQSSSimulation */
   NULL,    /* updateContinuousSystem */
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_callExternalObjectDestructors,    /* callExternalObjectDestructors */
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialNonLinearSystem,    /* initialNonLinearSystem */
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialLinearSystem,    /* initialLinearSystem */
   NULL,    /* initialMixedSystem */
   #if !defined(OMC_NO_STATESELECTION)
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initializeStateSets,
   #else
   NULL,
   #endif    /* initializeStateSets */
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initializeDAEmodeData,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionODE,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionAlgebraics,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionDAE,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionLocalKnownVars,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_input_function,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_input_function_init,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_input_function_updateStartValues,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_data_function,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_output_function,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_setc_function,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_setb_function,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_function_storeDelayed,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_function_storeSpatialDistribution,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_function_initSpatialDistribution,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_updateBoundVariableAttributes,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionInitialEquations,
   1, /* useHomotopy - 0: local homotopy (equidistant lambda), 1: global homotopy (equidistant lambda), 2: new global homotopy approach (adaptive lambda), 3: new local homotopy approach (adaptive lambda)*/
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionInitialEquations_lambda0,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionRemovedInitialEquations,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_updateBoundParameters,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_checkForAsserts,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_function_ZeroCrossingsEquations,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_function_ZeroCrossings,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_function_updateRelations,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_zeroCrossingDescription,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_relationDescription,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_function_initSample,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_A,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_B,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_C,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_D,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_F,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_H,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianA,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianB,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianC,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianD,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianF,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianH,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacA_column,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacB_column,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacC_column,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacD_column,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacF_column,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacH_column,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_linear_model_frame,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_linear_model_datarecovery_frame,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_mayer,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_lagrange,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_pickUpBoundsForInputsInOptimization,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_setInputData,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_getTimeGrid,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_symbolicInlineSystem,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_function_initSynchronous,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_function_updateSynchronous,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_function_equationsSynchronous,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_inputNames,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_dataReconciliationInputNames,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_dataReconciliationUnmeasuredVariables,
   TestPackage_ActiveWork_WaterModel_HydroPowerModel1_read_input_fmu,
   NULL,
   NULL,
   -1,
   NULL,
   NULL,
   -1

};

#define _OMC_LIT_RESOURCE_0_name_data "Complex"
#define _OMC_LIT_RESOURCE_0_dir_data "C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Complex 4.0.0+maint.om"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_0_name,7,_OMC_LIT_RESOURCE_0_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_0_dir,77,_OMC_LIT_RESOURCE_0_dir_data);

#define _OMC_LIT_RESOURCE_1_name_data "Modelica"
#define _OMC_LIT_RESOURCE_1_dir_data "C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_1_name,8,_OMC_LIT_RESOURCE_1_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_1_dir,78,_OMC_LIT_RESOURCE_1_dir_data);

#define _OMC_LIT_RESOURCE_2_name_data "ModelicaServices"
#define _OMC_LIT_RESOURCE_2_dir_data "C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/ModelicaServices 4.0.0+maint.om"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_2_name,16,_OMC_LIT_RESOURCE_2_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_2_dir,86,_OMC_LIT_RESOURCE_2_dir_data);

#define _OMC_LIT_RESOURCE_3_name_data "OpenHPL"
#define _OMC_LIT_RESOURCE_3_dir_data "C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_3_name,7,_OMC_LIT_RESOURCE_3_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_3_dir,68,_OMC_LIT_RESOURCE_3_dir_data);

#define _OMC_LIT_RESOURCE_4_name_data "OpenIPSL"
#define _OMC_LIT_RESOURCE_4_dir_data "C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenIPSL 3.0.1"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_4_name,8,_OMC_LIT_RESOURCE_4_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_4_dir,69,_OMC_LIT_RESOURCE_4_dir_data);

#define _OMC_LIT_RESOURCE_5_name_data "TestPackage"
#define _OMC_LIT_RESOURCE_5_dir_data "C:/Users/haugn/OneDrive/Dokumenter/Master/FMU_Models/Modelica_files"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_5_name,11,_OMC_LIT_RESOURCE_5_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_5_dir,67,_OMC_LIT_RESOURCE_5_dir_data);

static const MMC_DEFSTRUCTLIT(_OMC_LIT_RESOURCES,12,MMC_ARRAY_TAG) {MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_0_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_0_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_1_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_1_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_2_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_2_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_3_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_3_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_4_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_4_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_5_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_5_dir)}};
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_setupDataStruc(DATA *data, threadData_t *threadData)
{
  assertStreamPrint(threadData,0!=data, "Error while initialize Data");
  threadData->localRoots[LOCAL_ROOT_SIMULATION_DATA] = data;
  data->callback = &TestPackage_ActiveWork_WaterModel_HydroPowerModel1_callback;
  OpenModelica_updateUriMapping(threadData, MMC_REFSTRUCTLIT(_OMC_LIT_RESOURCES));
  data->modelData->modelName = "TestPackage.ActiveWork.WaterModel.HydroPowerModel1";
  data->modelData->modelFilePrefix = "TestPackage_ActiveWork_WaterModel_HydroPowerModel1";
  data->modelData->resultFileName = NULL;
  data->modelData->modelDir = "C:/Users/haugn/OneDrive/Dokumenter/Master/FMU_Models/Modelica_files";
  data->modelData->modelGUID = "{bed2c60c-78a6-4f2b-90ff-43fc032a4b3e}";
  data->modelData->initXMLData = NULL;
  data->modelData->modelDataXml.infoXMLData = NULL;
  GC_asprintf(&data->modelData->modelDataXml.fileName, "%s/TestPackage_ActiveWork_WaterModel_HydroPowerModel1_info.json", data->modelData->resourcesDir);
  data->modelData->runTestsuite = 0;
  data->modelData->nStates = 5;
  data->modelData->nVariablesReal = 193;
  data->modelData->nDiscreteReal = 0;
  data->modelData->nVariablesInteger = 4;
  data->modelData->nVariablesBoolean = 6;
  data->modelData->nVariablesString = 0;
  data->modelData->nParametersReal = 153;
  data->modelData->nParametersInteger = 13;
  data->modelData->nParametersBoolean = 32;
  data->modelData->nParametersString = 2;
  data->modelData->nInputVars = 2;
  data->modelData->nOutputVars = 7;
  data->modelData->nAliasReal = 89;
  data->modelData->nAliasInteger = 6;
  data->modelData->nAliasBoolean = 7;
  data->modelData->nAliasString = 0;
  data->modelData->nZeroCrossings = 11;
  data->modelData->nSamples = 0;
  data->modelData->nRelations = 11;
  data->modelData->nMathEvents = 0;
  data->modelData->nExtObjs = 1;
  data->modelData->modelDataXml.modelInfoXmlLength = 0;
  data->modelData->modelDataXml.nFunctions = 14;
  data->modelData->modelDataXml.nProfileBlocks = 0;
  data->modelData->modelDataXml.nEquations = 833;
  data->modelData->nMixedSystems = 0;
  data->modelData->nLinearSystems = 3;
  data->modelData->nNonLinearSystems = 3;
  data->modelData->nStateSets = 0;
  data->modelData->nJacobians = 12;
  data->modelData->nOptimizeConstraints = 0;
  data->modelData->nOptimizeFinalConstraints = 0;
  data->modelData->nDelayExpressions = 0;
  data->modelData->nBaseClocks = 0;
  data->modelData->nSpatialDistributions = 0;
  data->modelData->nSensitivityVars = 0;
  data->modelData->nSensitivityParamVars = 0;
  data->modelData->nSetcVars = 0;
  data->modelData->ndataReconVars = 0;
  data->modelData->nSetbVars = 0;
  data->modelData->nRelatedBoundaryConditions = 0;
  data->modelData->linearizationDumpLanguage = OMC_LINEARIZE_DUMP_LANGUAGE_MODELICA;
}

static int rml_execution_failed()
{
  fflush(NULL);
  fprintf(stderr, "Execution failed!\n");
  fflush(NULL);
  return 1;
}

