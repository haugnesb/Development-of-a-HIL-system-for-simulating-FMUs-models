/* Events: Sample, Zero Crossings, Relations, Discrete Changes */
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* Initializes the raw time events of the simulation using the now
   calcualted parameters. */
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_function_initSample(DATA *data, threadData_t *threadData)
{
  long i=0;
}

const char *TestPackage_ActiveWork_WaterModel_HydroPowerModel1_zeroCrossingDescription(int i, int **out_EquationIndexes)
{
  static const char *res[] = {"time < control.startTime",
  "time < control.startTime + control.duration",
  "time < step.startTime",
  "division.y >= constant3.k",
  "division.y <= lessEqualThreshold.threshold",
  "time < ServoMotorVoltage.startTime",
  "time < ServoMotorVoltage.startTime + ServoMotorVoltage.duration",
  "time < ServoMotorTorque.startTime",
  "time < ServoMotorTorque.startTime + ServoMotorTorque.duration",
  "SM_Start_Torque_out > greaterThreshold2.threshold",
  "SM_Speed_Out > greaterThreshold1.threshold"};
  static const int occurEqs0[] = {1,487};
  static const int occurEqs1[] = {1,487};
  static const int occurEqs2[] = {1,479};
  static const int occurEqs3[] = {1,565};
  static const int occurEqs4[] = {1,566};
  static const int occurEqs5[] = {1,459};
  static const int occurEqs6[] = {1,459};
  static const int occurEqs7[] = {1,498};
  static const int occurEqs8[] = {1,498};
  static const int occurEqs9[] = {1,491};
  static const int occurEqs10[] = {1,500};
  static const int *occurEqs[] = {occurEqs0,occurEqs1,occurEqs2,occurEqs3,occurEqs4,occurEqs5,occurEqs6,occurEqs7,occurEqs8,occurEqs9,occurEqs10};
  *out_EquationIndexes = (int*) occurEqs[i];
  return res[i];
}

/* forwarded equations */
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_469(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_476(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_477(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_479(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_480(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_481(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_487(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_491(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_492(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_494(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_495(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_497(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_498(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_499(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_500(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_501(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_504(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_505(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_508(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_509(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_511(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_512(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_516(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_517(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_554(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_561(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_562(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_563(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_564(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_632(DATA* data, threadData_t *threadData);
extern void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_635(DATA* data, threadData_t *threadData);

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_function_ZeroCrossingsEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->callStatistics.functionZeroCrossingsEquations++;

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_469(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_476(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_477(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_479(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_480(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_481(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_487(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_491(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_492(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_494(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_495(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_497(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_498(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_499(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_500(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_501(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_504(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_505(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_508(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_509(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_511(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_512(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_516(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_517(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_554(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_561(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_562(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_563(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_564(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_632(data, threadData);

  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_635(data, threadData);
  
  TRACE_POP
  return 0;
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_function_ZeroCrossings(DATA *data, threadData_t *threadData, double *gout)
{
  TRACE_PUSH
  const int *equationIndexes = NULL;

  modelica_boolean tmp0;
  modelica_boolean tmp1;
  modelica_boolean tmp2;
  modelica_boolean tmp3;
  modelica_boolean tmp4;
  modelica_boolean tmp5;
  modelica_boolean tmp6;
  modelica_boolean tmp7;
  modelica_boolean tmp8;
  modelica_boolean tmp9;
  modelica_boolean tmp10;

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_ZC);
#endif
  data->simulationInfo->callStatistics.functionZeroCrossings++;

  tmp0 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[34] /* control.startTime PARAM */), data->simulationInfo->storedRelations[0]);
  gout[0] = (tmp0) ? 1 : -1;

  tmp1 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[34] /* control.startTime PARAM */) + (data->simulationInfo->realParameter[31] /* control.duration PARAM */), data->simulationInfo->storedRelations[1]);
  gout[1] = (tmp1) ? 1 : -1;

  tmp2 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[81] /* step.startTime PARAM */), data->simulationInfo->storedRelations[2]);
  gout[2] = (tmp2) ? 1 : -1;

  tmp3 = GreaterEqZC((data->localData[0]->realVars[102] /* division.y DUMMY_STATE */), (data->simulationInfo->realParameter[27] /* constant3.k PARAM */), data->simulationInfo->storedRelations[3]);
  gout[3] = (tmp3) ? 1 : -1;

  tmp4 = LessEqZC((data->localData[0]->realVars[102] /* division.y DUMMY_STATE */), (data->simulationInfo->realParameter[65] /* lessEqualThreshold.threshold PARAM */), data->simulationInfo->storedRelations[4]);
  gout[4] = (tmp4) ? 1 : -1;

  tmp5 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[12] /* ServoMotorVoltage.startTime PARAM */), data->simulationInfo->storedRelations[5]);
  gout[5] = (tmp5) ? 1 : -1;

  tmp6 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[12] /* ServoMotorVoltage.startTime PARAM */) + (data->simulationInfo->realParameter[9] /* ServoMotorVoltage.duration PARAM */), data->simulationInfo->storedRelations[6]);
  gout[6] = (tmp6) ? 1 : -1;

  tmp7 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[4] /* ServoMotorTorque.startTime PARAM */), data->simulationInfo->storedRelations[7]);
  gout[7] = (tmp7) ? 1 : -1;

  tmp8 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[4] /* ServoMotorTorque.startTime PARAM */) + (data->simulationInfo->realParameter[1] /* ServoMotorTorque.duration PARAM */), data->simulationInfo->storedRelations[8]);
  gout[8] = (tmp8) ? 1 : -1;

  tmp9 = GreaterZC((data->localData[0]->realVars[81] /* SM_Start_Torque_out variable */), (data->simulationInfo->realParameter[58] /* greaterThreshold2.threshold PARAM */), data->simulationInfo->storedRelations[9]);
  gout[9] = (tmp9) ? 1 : -1;

  tmp10 = GreaterZC((data->localData[0]->realVars[80] /* SM_Speed_Out variable */), (data->simulationInfo->realParameter[57] /* greaterThreshold1.threshold PARAM */), data->simulationInfo->storedRelations[10]);
  gout[10] = (tmp10) ? 1 : -1;

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_ZC);
#endif

  TRACE_POP
  return 0;
}

const char *TestPackage_ActiveWork_WaterModel_HydroPowerModel1_relationDescription(int i)
{
  const char *res[] = {"time < control.startTime",
  "time < control.startTime + control.duration",
  "time < step.startTime",
  "division.y >= constant3.k",
  "division.y <= lessEqualThreshold.threshold",
  "time < ServoMotorVoltage.startTime",
  "time < ServoMotorVoltage.startTime + ServoMotorVoltage.duration",
  "time < ServoMotorTorque.startTime",
  "time < ServoMotorTorque.startTime + ServoMotorTorque.duration",
  "SM_Start_Torque_out > greaterThreshold2.threshold",
  "SM_Speed_Out > greaterThreshold1.threshold"};
  return res[i];
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_function_updateRelations(DATA *data, threadData_t *threadData, int evalforZeroCross)
{
  TRACE_PUSH
  const int *equationIndexes = NULL;

  modelica_boolean tmp11;
  modelica_boolean tmp12;
  modelica_boolean tmp13;
  modelica_boolean tmp14;
  modelica_boolean tmp15;
  modelica_boolean tmp16;
  modelica_boolean tmp17;
  modelica_boolean tmp18;
  modelica_boolean tmp19;
  modelica_boolean tmp20;
  modelica_boolean tmp21;
  
  if(evalforZeroCross) {
    tmp11 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[34] /* control.startTime PARAM */), data->simulationInfo->storedRelations[0]);
    data->simulationInfo->relations[0] = tmp11;

    tmp12 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[34] /* control.startTime PARAM */) + (data->simulationInfo->realParameter[31] /* control.duration PARAM */), data->simulationInfo->storedRelations[1]);
    data->simulationInfo->relations[1] = tmp12;

    tmp13 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[81] /* step.startTime PARAM */), data->simulationInfo->storedRelations[2]);
    data->simulationInfo->relations[2] = tmp13;

    tmp14 = GreaterEqZC((data->localData[0]->realVars[102] /* division.y DUMMY_STATE */), (data->simulationInfo->realParameter[27] /* constant3.k PARAM */), data->simulationInfo->storedRelations[3]);
    data->simulationInfo->relations[3] = tmp14;

    tmp15 = LessEqZC((data->localData[0]->realVars[102] /* division.y DUMMY_STATE */), (data->simulationInfo->realParameter[65] /* lessEqualThreshold.threshold PARAM */), data->simulationInfo->storedRelations[4]);
    data->simulationInfo->relations[4] = tmp15;

    tmp16 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[12] /* ServoMotorVoltage.startTime PARAM */), data->simulationInfo->storedRelations[5]);
    data->simulationInfo->relations[5] = tmp16;

    tmp17 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[12] /* ServoMotorVoltage.startTime PARAM */) + (data->simulationInfo->realParameter[9] /* ServoMotorVoltage.duration PARAM */), data->simulationInfo->storedRelations[6]);
    data->simulationInfo->relations[6] = tmp17;

    tmp18 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[4] /* ServoMotorTorque.startTime PARAM */), data->simulationInfo->storedRelations[7]);
    data->simulationInfo->relations[7] = tmp18;

    tmp19 = LessZC(data->localData[0]->timeValue, (data->simulationInfo->realParameter[4] /* ServoMotorTorque.startTime PARAM */) + (data->simulationInfo->realParameter[1] /* ServoMotorTorque.duration PARAM */), data->simulationInfo->storedRelations[8]);
    data->simulationInfo->relations[8] = tmp19;

    tmp20 = GreaterZC((data->localData[0]->realVars[81] /* SM_Start_Torque_out variable */), (data->simulationInfo->realParameter[58] /* greaterThreshold2.threshold PARAM */), data->simulationInfo->storedRelations[9]);
    data->simulationInfo->relations[9] = tmp20;

    tmp21 = GreaterZC((data->localData[0]->realVars[80] /* SM_Speed_Out variable */), (data->simulationInfo->realParameter[57] /* greaterThreshold1.threshold PARAM */), data->simulationInfo->storedRelations[10]);
    data->simulationInfo->relations[10] = tmp21;
  } else {
    data->simulationInfo->relations[0] = (data->localData[0]->timeValue < (data->simulationInfo->realParameter[34] /* control.startTime PARAM */));

    data->simulationInfo->relations[1] = (data->localData[0]->timeValue < (data->simulationInfo->realParameter[34] /* control.startTime PARAM */) + (data->simulationInfo->realParameter[31] /* control.duration PARAM */));

    data->simulationInfo->relations[2] = (data->localData[0]->timeValue < (data->simulationInfo->realParameter[81] /* step.startTime PARAM */));

    data->simulationInfo->relations[3] = ((data->localData[0]->realVars[102] /* division.y DUMMY_STATE */) >= (data->simulationInfo->realParameter[27] /* constant3.k PARAM */));

    data->simulationInfo->relations[4] = ((data->localData[0]->realVars[102] /* division.y DUMMY_STATE */) <= (data->simulationInfo->realParameter[65] /* lessEqualThreshold.threshold PARAM */));

    data->simulationInfo->relations[5] = (data->localData[0]->timeValue < (data->simulationInfo->realParameter[12] /* ServoMotorVoltage.startTime PARAM */));

    data->simulationInfo->relations[6] = (data->localData[0]->timeValue < (data->simulationInfo->realParameter[12] /* ServoMotorVoltage.startTime PARAM */) + (data->simulationInfo->realParameter[9] /* ServoMotorVoltage.duration PARAM */));

    data->simulationInfo->relations[7] = (data->localData[0]->timeValue < (data->simulationInfo->realParameter[4] /* ServoMotorTorque.startTime PARAM */));

    data->simulationInfo->relations[8] = (data->localData[0]->timeValue < (data->simulationInfo->realParameter[4] /* ServoMotorTorque.startTime PARAM */) + (data->simulationInfo->realParameter[1] /* ServoMotorTorque.duration PARAM */));

    data->simulationInfo->relations[9] = ((data->localData[0]->realVars[81] /* SM_Start_Torque_out variable */) > (data->simulationInfo->realParameter[58] /* greaterThreshold2.threshold PARAM */));

    data->simulationInfo->relations[10] = ((data->localData[0]->realVars[80] /* SM_Speed_Out variable */) > (data->simulationInfo->realParameter[57] /* greaterThreshold1.threshold PARAM */));
  }
  
  TRACE_POP
  return 0;
}

#if defined(__cplusplus)
}
#endif

