/* Initial State Set */
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_model.h"
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_11mix.h"
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif
/* funtion initialize state sets */
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initializeStateSets(int nStateSets, STATE_SET_DATA* statesetData, DATA *data)
{
}

#if defined(__cplusplus)
}
#endif

