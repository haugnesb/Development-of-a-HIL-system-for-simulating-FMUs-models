/* Jacobians 12 */
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_model.h"
#include "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_12jac.h"
#include "simulation/jacobian_util.h"
#include "util/omc_file.h"
/* constant equations */
/* dynamic equations */

/*
equation index: 104
type: SIMPLE_ASSIGN
$DER.surgeTank.Vdot.$pDERNLSJac186.dummyVarNLSJac186 = $DER.surgeTank.v.SeedNLSJac186 * surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_104(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 0;
  const int equationIndexes[2] = {1,104};
  jacobian->tmpVars[6] /* der(surgeTank.Vdot.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */ = (jacobian->seedVars[0] /* der(surgeTank.v.SeedNLSJac186) SEED_VAR */) * ((data->localData[0]->realVars[138] /* surgeTank.A variable */));
  TRACE_POP
}

/*
equation index: 105
type: SIMPLE_ASSIGN
$DER.surgeTank.mdot.$pDERNLSJac186.dummyVarNLSJac186 = data.rho * $DER.surgeTank.Vdot.$pDERNLSJac186.dummyVarNLSJac186
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_105(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 1;
  const int equationIndexes[2] = {1,105};
  jacobian->tmpVars[7] /* der(surgeTank.mdot.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */ = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (jacobian->tmpVars[6] /* der(surgeTank.Vdot.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */);
  TRACE_POP
}

/*
equation index: 106
type: SIMPLE_ASSIGN
surgeTank.F.$pDERNLSJac186.dummyVarNLSJac186 = surgeTank.m * $DER.surgeTank.v.SeedNLSJac186
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_106(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 2;
  const int equationIndexes[2] = {1,106};
  jacobian->tmpVars[1] /* surgeTank.F.$pDERNLSJac186.dummyVarNLSJac186 JACOBIAN_DIFF_VAR */ = ((data->localData[0]->realVars[2] /* surgeTank.m STATE(1,surgeTank.mdot) */)) * (jacobian->seedVars[0] /* der(surgeTank.v.SeedNLSJac186) SEED_VAR */);
  TRACE_POP
}

/*
equation index: 107
type: SIMPLE_ASSIGN
intake.p_o.$pDERNLSJac186.dummyVarNLSJac186 = surgeTank.F.$pDERNLSJac186.dummyVarNLSJac186 / surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_107(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 3;
  const int equationIndexes[2] = {1,107};
  jacobian->tmpVars[3] /* intake.p_o.$pDERNLSJac186.dummyVarNLSJac186 JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[1] /* surgeTank.F.$pDERNLSJac186.dummyVarNLSJac186 JACOBIAN_DIFF_VAR */,(data->localData[0]->realVars[138] /* surgeTank.A variable */),"surgeTank.A");
  TRACE_POP
}

/*
equation index: 108
type: SIMPLE_ASSIGN
$DER.intake.M.$pDERNLSJac186.dummyVarNLSJac186 = (-intake.p_o.$pDERNLSJac186.dummyVarNLSJac186) * intake.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_108(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 4;
  const int equationIndexes[2] = {1,108};
  jacobian->tmpVars[4] /* der(intake.M.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */ = ((-jacobian->tmpVars[3] /* intake.p_o.$pDERNLSJac186.dummyVarNLSJac186 JACOBIAN_DIFF_VAR */)) * ((data->localData[0]->realVars[107] /* intake.A_o variable */));
  TRACE_POP
}

/*
equation index: 109
type: SIMPLE_ASSIGN
$DER.intake.Vdot.$pDERNLSJac186.dummyVarNLSJac186 = $DER.intake.M.$pDERNLSJac186.dummyVarNLSJac186 / (data.rho * intake.L)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_109(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 5;
  const int equationIndexes[2] = {1,109};
  jacobian->tmpVars[5] /* der(intake.Vdot.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[4] /* der(intake.M.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */,((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->simulationInfo->realParameter[62] /* intake.L PARAM */)),"data.rho * intake.L");
  TRACE_POP
}

/*
equation index: 110
type: SIMPLE_ASSIGN
$DER.intake.mdot.$pDERNLSJac186.dummyVarNLSJac186 = $DER.intake.Vdot.$pDERNLSJac186.dummyVarNLSJac186 * data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_110(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 6;
  const int equationIndexes[2] = {1,110};
  jacobian->tmpVars[8] /* der(intake.mdot.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */ = (jacobian->tmpVars[5] /* der(intake.Vdot.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */) * ((data->simulationInfo->realParameter[47] /* data.rho PARAM */));
  TRACE_POP
}

/*
equation index: 111
type: SIMPLE_ASSIGN
$DER.discharge.mdot.$pDERNLSJac186.dummyVarNLSJac186 = $DER.intake.mdot.$pDERNLSJac186.dummyVarNLSJac186 - $DER.surgeTank.mdot.$pDERNLSJac186.dummyVarNLSJac186
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_111(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 7;
  const int equationIndexes[2] = {1,111};
  jacobian->tmpVars[9] /* der(discharge.mdot.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */ = jacobian->tmpVars[8] /* der(intake.mdot.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */ - jacobian->tmpVars[7] /* der(surgeTank.mdot.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */;
  TRACE_POP
}

/*
equation index: 112
type: SIMPLE_ASSIGN
$DER.discharge.Vdot.$pDERNLSJac186.dummyVarNLSJac186 = $DER.discharge.mdot.$pDERNLSJac186.dummyVarNLSJac186 / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_112(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 8;
  const int equationIndexes[2] = {1,112};
  jacobian->tmpVars[10] /* der(discharge.Vdot.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[9] /* der(discharge.mdot.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */,(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho");
  TRACE_POP
}

/*
equation index: 113
type: SIMPLE_ASSIGN
$DER.discharge.M.$pDERNLSJac186.dummyVarNLSJac186 = data.rho * discharge.L * $DER.discharge.Vdot.$pDERNLSJac186.dummyVarNLSJac186
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_113(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 9;
  const int equationIndexes[2] = {1,113};
  jacobian->tmpVars[11] /* der(discharge.M.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */ = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[51] /* discharge.L PARAM */)) * (jacobian->tmpVars[10] /* der(discharge.Vdot.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */));
  TRACE_POP
}

/*
equation index: 114
type: SIMPLE_ASSIGN
discharge.p_i.$pDERNLSJac186.dummyVarNLSJac186 = $DER.discharge.M.$pDERNLSJac186.dummyVarNLSJac186 / discharge.A_i
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_114(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 10;
  const int equationIndexes[2] = {1,114};
  jacobian->tmpVars[12] /* discharge.p_i.$pDERNLSJac186.dummyVarNLSJac186 JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[11] /* der(discharge.M.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */,(data->localData[0]->realVars[89] /* discharge.A_i variable */),"discharge.A_i");
  TRACE_POP
}

/*
equation index: 115
type: SIMPLE_ASSIGN
$DER.penstock.M.$pDERNLSJac186.dummyVarNLSJac186 = data.rho * penstock.L * $DER.discharge.Vdot.$pDERNLSJac186.dummyVarNLSJac186
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_115(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 11;
  const int equationIndexes[2] = {1,115};
  jacobian->tmpVars[14] /* der(penstock.M.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */ = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[69] /* penstock.L PARAM */)) * (jacobian->tmpVars[10] /* der(discharge.Vdot.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */));
  TRACE_POP
}

/*
equation index: 116
type: SIMPLE_ASSIGN
penstock.p_o.$pDERNLSJac186.dummyVarNLSJac186 = (intake.p_o.$pDERNLSJac186.dummyVarNLSJac186 * penstock.A_i - $DER.penstock.M.$pDERNLSJac186.dummyVarNLSJac186) / penstock.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_116(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 12;
  const int equationIndexes[2] = {1,116};
  jacobian->tmpVars[15] /* penstock.p_o.$pDERNLSJac186.dummyVarNLSJac186 JACOBIAN_DIFF_VAR */ = DIVISION((jacobian->tmpVars[3] /* intake.p_o.$pDERNLSJac186.dummyVarNLSJac186 JACOBIAN_DIFF_VAR */) * ((data->localData[0]->realVars[119] /* penstock.A_i variable */)) - jacobian->tmpVars[14] /* der(penstock.M.$pDERNLSJac186.dummyVarNLSJac186) JACOBIAN_DIFF_VAR */,(data->localData[0]->realVars[120] /* penstock.A_o variable */),"penstock.A_o");
  TRACE_POP
}

/*
equation index: 117
type: SIMPLE_ASSIGN
turbine1.Vdot.$pDERNLSJac186.dummyVarNLSJac186 = if turbine1.WaterCompress then (-discharge.mdot) * data.rho * data.beta * penstock.p_o.$pDERNLSJac186.dummyVarNLSJac186 / (data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 2.0 else 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_117(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 13;
  const int equationIndexes[2] = {1,117};
  modelica_real tmp0;
  modelica_boolean tmp1;
  modelica_real tmp2;
  tmp1 = (modelica_boolean)(data->simulationInfo->booleanParameter[15] /* turbine1.WaterCompress PARAM */);
  if(tmp1)
  {
    tmp0 = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (1.0 + ((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->simulationInfo->realParameter[45] /* data.p_a PARAM */)));
    tmp2 = DIVISION(((-(data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */))) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * (jacobian->tmpVars[15] /* penstock.p_o.$pDERNLSJac186.dummyVarNLSJac186 JACOBIAN_DIFF_VAR */))),(tmp0 * tmp0),"(data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 2.0");
  }
  else
  {
    tmp2 = 0.0;
  }
  jacobian->tmpVars[16] /* turbine1.Vdot.$pDERNLSJac186.dummyVarNLSJac186 JACOBIAN_DIFF_VAR */ = tmp2;
  TRACE_POP
}

/*
equation index: 118
type: SIMPLE_ASSIGN
turbine1.dp.$pDERNLSJac186.dummyVarNLSJac186 = 2.0 * turbine1.Vdot * turbine1.Vdot.$pDERNLSJac186.dummyVarNLSJac186 * data.p_a / (turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_118(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 14;
  const int equationIndexes[2] = {1,118};
  modelica_real tmp3;
  tmp3 = ((data->localData[0]->realVars[162] /* turbine1.C_v_ variable */)) * ((data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */));
  jacobian->tmpVars[17] /* turbine1.dp.$pDERNLSJac186.dummyVarNLSJac186 JACOBIAN_DIFF_VAR */ = (2.0) * (((data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */)) * ((jacobian->tmpVars[16] /* turbine1.Vdot.$pDERNLSJac186.dummyVarNLSJac186 JACOBIAN_DIFF_VAR */) * (DIVISION((data->simulationInfo->realParameter[45] /* data.p_a PARAM */),(tmp3 * tmp3),"(turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0"))));
  TRACE_POP
}

/*
equation index: 119
type: SIMPLE_ASSIGN
$res_NLSJac186_1.$pDERNLSJac186.dummyVarNLSJac186 = penstock.p_o.$pDERNLSJac186.dummyVarNLSJac186 + (-discharge.p_i.$pDERNLSJac186.dummyVarNLSJac186) - turbine1.dp.$pDERNLSJac186.dummyVarNLSJac186
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_119(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 15;
  const int equationIndexes[2] = {1,119};
  jacobian->resultVars[0] /* $res_NLSJac186_1.$pDERNLSJac186.dummyVarNLSJac186 JACOBIAN_VAR */ = jacobian->tmpVars[15] /* penstock.p_o.$pDERNLSJac186.dummyVarNLSJac186 JACOBIAN_DIFF_VAR */ + (-jacobian->tmpVars[12] /* discharge.p_i.$pDERNLSJac186.dummyVarNLSJac186 JACOBIAN_DIFF_VAR */) - jacobian->tmpVars[17] /* turbine1.dp.$pDERNLSJac186.dummyVarNLSJac186 JACOBIAN_DIFF_VAR */;
  TRACE_POP
}

OMC_DISABLE_OPT
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacNLSJac186_constantEqns(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_NLSJac186;
  
  
  TRACE_POP
  return 0;
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacNLSJac186_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_NLSJac186;
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_104(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_105(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_106(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_107(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_108(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_109(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_110(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_111(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_112(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_113(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_114(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_115(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_116(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_117(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_118(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_119(data, threadData, jacobian, parentJacobian);
  TRACE_POP
  return 0;
}
/* constant equations */
/* dynamic equations */

/*
equation index: 168
type: SIMPLE_ASSIGN
$DER.$DER.surgeTank.Vdot.$pDERLSJac187.dummyVarLSJac187 = $DER.$DER.surgeTank.v.SeedLSJac187 * surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_168(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 0;
  const int equationIndexes[2] = {1,168};
  jacobian->tmpVars[1] /* der(der(surgeTank.Vdot.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */ = (jacobian->seedVars[0] /* der(der(surgeTank.v.SeedLSJac187)) SEED_VAR */) * ((data->localData[0]->realVars[138] /* surgeTank.A variable */));
  TRACE_POP
}

/*
equation index: 169
type: SIMPLE_ASSIGN
$DER.$DER.surgeTank.mdot.$pDERLSJac187.dummyVarLSJac187 = data.rho * $DER.$DER.surgeTank.Vdot.$pDERLSJac187.dummyVarLSJac187
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_169(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 1;
  const int equationIndexes[2] = {1,169};
  jacobian->tmpVars[2] /* der(der(surgeTank.mdot.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */ = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (jacobian->tmpVars[1] /* der(der(surgeTank.Vdot.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */);
  TRACE_POP
}

/*
equation index: 170
type: SIMPLE_ASSIGN
$DER.surgeTank.F.$pDERLSJac187.dummyVarLSJac187 = surgeTank.m * $DER.$DER.surgeTank.v.SeedLSJac187
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_170(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 2;
  const int equationIndexes[2] = {1,170};
  jacobian->tmpVars[3] /* der(surgeTank.F.$pDERLSJac187.dummyVarLSJac187) JACOBIAN_DIFF_VAR */ = ((data->localData[0]->realVars[2] /* surgeTank.m STATE(1,surgeTank.mdot) */)) * (jacobian->seedVars[0] /* der(der(surgeTank.v.SeedLSJac187)) SEED_VAR */);
  TRACE_POP
}

/*
equation index: 171
type: SIMPLE_ASSIGN
$DER.intake.p_o.$pDERLSJac187.dummyVarLSJac187 = $DER.surgeTank.F.$pDERLSJac187.dummyVarLSJac187 / surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_171(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 3;
  const int equationIndexes[2] = {1,171};
  jacobian->tmpVars[5] /* der(intake.p_o.$pDERLSJac187.dummyVarLSJac187) JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[3] /* der(surgeTank.F.$pDERLSJac187.dummyVarLSJac187) JACOBIAN_DIFF_VAR */,(data->localData[0]->realVars[138] /* surgeTank.A variable */),"surgeTank.A");
  TRACE_POP
}

/*
equation index: 172
type: SIMPLE_ASSIGN
$DER.$DER.intake.M.$pDERLSJac187.dummyVarLSJac187 = (-$DER.intake.p_o.$pDERLSJac187.dummyVarLSJac187) * intake.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_172(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 4;
  const int equationIndexes[2] = {1,172};
  jacobian->tmpVars[6] /* der(der(intake.M.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */ = ((-jacobian->tmpVars[5] /* der(intake.p_o.$pDERLSJac187.dummyVarLSJac187) JACOBIAN_DIFF_VAR */)) * ((data->localData[0]->realVars[107] /* intake.A_o variable */));
  TRACE_POP
}

/*
equation index: 173
type: SIMPLE_ASSIGN
$DER.$DER.intake.Vdot.$pDERLSJac187.dummyVarLSJac187 = $DER.$DER.intake.M.$pDERLSJac187.dummyVarLSJac187 / (data.rho * intake.L)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_173(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 5;
  const int equationIndexes[2] = {1,173};
  jacobian->tmpVars[7] /* der(der(intake.Vdot.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[6] /* der(der(intake.M.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */,((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->simulationInfo->realParameter[62] /* intake.L PARAM */)),"data.rho * intake.L");
  TRACE_POP
}

/*
equation index: 174
type: SIMPLE_ASSIGN
$DER.$DER.intake.mdot.$pDERLSJac187.dummyVarLSJac187 = $DER.$DER.intake.Vdot.$pDERLSJac187.dummyVarLSJac187 * data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_174(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 6;
  const int equationIndexes[2] = {1,174};
  jacobian->tmpVars[8] /* der(der(intake.mdot.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */ = (jacobian->tmpVars[7] /* der(der(intake.Vdot.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */) * ((data->simulationInfo->realParameter[47] /* data.rho PARAM */));
  TRACE_POP
}

/*
equation index: 175
type: SIMPLE_ASSIGN
$DER.$DER.discharge.mdot.$pDERLSJac187.dummyVarLSJac187 = $DER.$DER.intake.mdot.$pDERLSJac187.dummyVarLSJac187 - $DER.$DER.surgeTank.mdot.$pDERLSJac187.dummyVarLSJac187
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_175(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 7;
  const int equationIndexes[2] = {1,175};
  jacobian->tmpVars[9] /* der(der(discharge.mdot.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */ = jacobian->tmpVars[8] /* der(der(intake.mdot.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */ - jacobian->tmpVars[2] /* der(der(surgeTank.mdot.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */;
  TRACE_POP
}

/*
equation index: 176
type: SIMPLE_ASSIGN
$DER.$DER.discharge.Vdot.$pDERLSJac187.dummyVarLSJac187 = $DER.$DER.discharge.mdot.$pDERLSJac187.dummyVarLSJac187 / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_176(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 8;
  const int equationIndexes[2] = {1,176};
  jacobian->tmpVars[10] /* der(der(discharge.Vdot.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[9] /* der(der(discharge.mdot.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */,(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho");
  TRACE_POP
}

/*
equation index: 177
type: SIMPLE_ASSIGN
$DER.$DER.discharge.M.$pDERLSJac187.dummyVarLSJac187 = data.rho * discharge.L * $DER.$DER.discharge.Vdot.$pDERLSJac187.dummyVarLSJac187
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_177(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 9;
  const int equationIndexes[2] = {1,177};
  jacobian->tmpVars[11] /* der(der(discharge.M.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */ = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[51] /* discharge.L PARAM */)) * (jacobian->tmpVars[10] /* der(der(discharge.Vdot.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */));
  TRACE_POP
}

/*
equation index: 178
type: SIMPLE_ASSIGN
$DER.discharge.p_i.$pDERLSJac187.dummyVarLSJac187 = $DER.$DER.discharge.M.$pDERLSJac187.dummyVarLSJac187 / discharge.A_i
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_178(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 10;
  const int equationIndexes[2] = {1,178};
  jacobian->tmpVars[12] /* der(discharge.p_i.$pDERLSJac187.dummyVarLSJac187) JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[11] /* der(der(discharge.M.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */,(data->localData[0]->realVars[89] /* discharge.A_i variable */),"discharge.A_i");
  TRACE_POP
}

/*
equation index: 179
type: SIMPLE_ASSIGN
$DER.$DER.penstock.M.$pDERLSJac187.dummyVarLSJac187 = data.rho * penstock.L * $DER.$DER.discharge.Vdot.$pDERLSJac187.dummyVarLSJac187
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_179(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 11;
  const int equationIndexes[2] = {1,179};
  jacobian->tmpVars[14] /* der(der(penstock.M.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */ = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[69] /* penstock.L PARAM */)) * (jacobian->tmpVars[10] /* der(der(discharge.Vdot.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */));
  TRACE_POP
}

/*
equation index: 180
type: SIMPLE_ASSIGN
$DER.penstock.p_o.$pDERLSJac187.dummyVarLSJac187 = ($DER.intake.p_o.$pDERLSJac187.dummyVarLSJac187 * penstock.A_i - $DER.$DER.penstock.M.$pDERLSJac187.dummyVarLSJac187) / penstock.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_180(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 12;
  const int equationIndexes[2] = {1,180};
  jacobian->tmpVars[15] /* der(penstock.p_o.$pDERLSJac187.dummyVarLSJac187) JACOBIAN_DIFF_VAR */ = DIVISION((jacobian->tmpVars[5] /* der(intake.p_o.$pDERLSJac187.dummyVarLSJac187) JACOBIAN_DIFF_VAR */) * ((data->localData[0]->realVars[119] /* penstock.A_i variable */)) - jacobian->tmpVars[14] /* der(der(penstock.M.$pDERLSJac187.dummyVarLSJac187)) JACOBIAN_DIFF_VAR */,(data->localData[0]->realVars[120] /* penstock.A_o variable */),"penstock.A_o");
  TRACE_POP
}

/*
equation index: 181
type: SIMPLE_ASSIGN
$DER.turbine1.Vdot.$pDERLSJac187.dummyVarLSJac187 = if turbine1.WaterCompress then (-data.rho) * discharge.mdot * data.beta * $DER.penstock.p_o.$pDERLSJac187.dummyVarLSJac187 * (data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 2.0 / (data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 4.0 else 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_181(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 13;
  const int equationIndexes[2] = {1,181};
  modelica_real tmp4;
  modelica_real tmp5;
  modelica_boolean tmp6;
  modelica_real tmp7;
  tmp6 = (modelica_boolean)(data->simulationInfo->booleanParameter[15] /* turbine1.WaterCompress PARAM */);
  if(tmp6)
  {
    tmp4 = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (1.0 + ((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->simulationInfo->realParameter[45] /* data.p_a PARAM */)));
    tmp5 = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (1.0 + ((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->simulationInfo->realParameter[45] /* data.p_a PARAM */)));
    tmp5 *= tmp5;
    tmp7 = DIVISION((((-(data->simulationInfo->realParameter[47] /* data.rho PARAM */))) * (((data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */)) * (((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * (jacobian->tmpVars[15] /* der(penstock.p_o.$pDERLSJac187.dummyVarLSJac187) JACOBIAN_DIFF_VAR */)))) * ((tmp4 * tmp4)),(tmp5 * tmp5),"(data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 4.0");
  }
  else
  {
    tmp7 = 0.0;
  }
  jacobian->tmpVars[16] /* der(turbine1.Vdot.$pDERLSJac187.dummyVarLSJac187) JACOBIAN_DIFF_VAR */ = tmp7;
  TRACE_POP
}

/*
equation index: 182
type: SIMPLE_ASSIGN
$DER.turbine1.dp.$pDERLSJac187.dummyVarLSJac187 = 2.0 * turbine1.Vdot * $DER.turbine1.Vdot.$pDERLSJac187.dummyVarLSJac187 * data.p_a / (turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_182(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 14;
  const int equationIndexes[2] = {1,182};
  modelica_real tmp8;
  tmp8 = ((data->localData[0]->realVars[162] /* turbine1.C_v_ variable */)) * ((data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */));
  jacobian->tmpVars[17] /* der(turbine1.dp.$pDERLSJac187.dummyVarLSJac187) JACOBIAN_DIFF_VAR */ = (2.0) * (((data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */)) * ((jacobian->tmpVars[16] /* der(turbine1.Vdot.$pDERLSJac187.dummyVarLSJac187) JACOBIAN_DIFF_VAR */) * (DIVISION((data->simulationInfo->realParameter[45] /* data.p_a PARAM */),(tmp8 * tmp8),"(turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0"))));
  TRACE_POP
}

/*
equation index: 183
type: SIMPLE_ASSIGN
$res_LSJac187_1.$pDERLSJac187.dummyVarLSJac187 = $DER.penstock.p_o.$pDERLSJac187.dummyVarLSJac187 + (-$DER.discharge.p_i.$pDERLSJac187.dummyVarLSJac187) - $DER.turbine1.dp.$pDERLSJac187.dummyVarLSJac187
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_183(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 15;
  const int equationIndexes[2] = {1,183};
  jacobian->resultVars[0] /* $res_LSJac187_1.$pDERLSJac187.dummyVarLSJac187 JACOBIAN_VAR */ = jacobian->tmpVars[15] /* der(penstock.p_o.$pDERLSJac187.dummyVarLSJac187) JACOBIAN_DIFF_VAR */ + (-jacobian->tmpVars[12] /* der(discharge.p_i.$pDERLSJac187.dummyVarLSJac187) JACOBIAN_DIFF_VAR */) - jacobian->tmpVars[17] /* der(turbine1.dp.$pDERLSJac187.dummyVarLSJac187) JACOBIAN_DIFF_VAR */;
  TRACE_POP
}

OMC_DISABLE_OPT
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacLSJac187_constantEqns(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_LSJac187;
  
  
  TRACE_POP
  return 0;
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacLSJac187_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_LSJac187;
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_168(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_169(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_170(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_171(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_172(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_173(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_174(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_175(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_176(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_177(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_178(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_179(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_180(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_181(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_182(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_183(data, threadData, jacobian, parentJacobian);
  TRACE_POP
  return 0;
}
/* constant equations */
/* dynamic equations */

/*
equation index: 333
type: SIMPLE_ASSIGN
$DER.surgeTank.Vdot.$pDERNLSJac188.dummyVarNLSJac188 = $DER.surgeTank.v.SeedNLSJac188 * surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_333(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 0;
  const int equationIndexes[2] = {1,333};
  jacobian->tmpVars[6] /* der(surgeTank.Vdot.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */ = (jacobian->seedVars[0] /* der(surgeTank.v.SeedNLSJac188) SEED_VAR */) * ((data->localData[0]->realVars[138] /* surgeTank.A variable */));
  TRACE_POP
}

/*
equation index: 334
type: SIMPLE_ASSIGN
$DER.surgeTank.mdot.$pDERNLSJac188.dummyVarNLSJac188 = data.rho * $DER.surgeTank.Vdot.$pDERNLSJac188.dummyVarNLSJac188
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_334(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 1;
  const int equationIndexes[2] = {1,334};
  jacobian->tmpVars[7] /* der(surgeTank.mdot.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */ = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (jacobian->tmpVars[6] /* der(surgeTank.Vdot.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */);
  TRACE_POP
}

/*
equation index: 335
type: SIMPLE_ASSIGN
surgeTank.F.$pDERNLSJac188.dummyVarNLSJac188 = surgeTank.m * $DER.surgeTank.v.SeedNLSJac188
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_335(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 2;
  const int equationIndexes[2] = {1,335};
  jacobian->tmpVars[1] /* surgeTank.F.$pDERNLSJac188.dummyVarNLSJac188 JACOBIAN_DIFF_VAR */ = ((data->localData[0]->realVars[2] /* surgeTank.m STATE(1,surgeTank.mdot) */)) * (jacobian->seedVars[0] /* der(surgeTank.v.SeedNLSJac188) SEED_VAR */);
  TRACE_POP
}

/*
equation index: 336
type: SIMPLE_ASSIGN
intake.p_o.$pDERNLSJac188.dummyVarNLSJac188 = surgeTank.F.$pDERNLSJac188.dummyVarNLSJac188 / surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_336(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 3;
  const int equationIndexes[2] = {1,336};
  jacobian->tmpVars[3] /* intake.p_o.$pDERNLSJac188.dummyVarNLSJac188 JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[1] /* surgeTank.F.$pDERNLSJac188.dummyVarNLSJac188 JACOBIAN_DIFF_VAR */,(data->localData[0]->realVars[138] /* surgeTank.A variable */),"surgeTank.A");
  TRACE_POP
}

/*
equation index: 337
type: SIMPLE_ASSIGN
$DER.intake.M.$pDERNLSJac188.dummyVarNLSJac188 = (-intake.p_o.$pDERNLSJac188.dummyVarNLSJac188) * intake.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_337(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 4;
  const int equationIndexes[2] = {1,337};
  jacobian->tmpVars[4] /* der(intake.M.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */ = ((-jacobian->tmpVars[3] /* intake.p_o.$pDERNLSJac188.dummyVarNLSJac188 JACOBIAN_DIFF_VAR */)) * ((data->localData[0]->realVars[107] /* intake.A_o variable */));
  TRACE_POP
}

/*
equation index: 338
type: SIMPLE_ASSIGN
$DER.intake.Vdot.$pDERNLSJac188.dummyVarNLSJac188 = $DER.intake.M.$pDERNLSJac188.dummyVarNLSJac188 / (data.rho * intake.L)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_338(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 5;
  const int equationIndexes[2] = {1,338};
  jacobian->tmpVars[5] /* der(intake.Vdot.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[4] /* der(intake.M.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */,((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->simulationInfo->realParameter[62] /* intake.L PARAM */)),"data.rho * intake.L");
  TRACE_POP
}

/*
equation index: 339
type: SIMPLE_ASSIGN
$DER.intake.mdot.$pDERNLSJac188.dummyVarNLSJac188 = $DER.intake.Vdot.$pDERNLSJac188.dummyVarNLSJac188 * data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_339(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 6;
  const int equationIndexes[2] = {1,339};
  jacobian->tmpVars[8] /* der(intake.mdot.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */ = (jacobian->tmpVars[5] /* der(intake.Vdot.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */) * ((data->simulationInfo->realParameter[47] /* data.rho PARAM */));
  TRACE_POP
}

/*
equation index: 340
type: SIMPLE_ASSIGN
$DER.discharge.mdot.$pDERNLSJac188.dummyVarNLSJac188 = $DER.intake.mdot.$pDERNLSJac188.dummyVarNLSJac188 - $DER.surgeTank.mdot.$pDERNLSJac188.dummyVarNLSJac188
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_340(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 7;
  const int equationIndexes[2] = {1,340};
  jacobian->tmpVars[9] /* der(discharge.mdot.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */ = jacobian->tmpVars[8] /* der(intake.mdot.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */ - jacobian->tmpVars[7] /* der(surgeTank.mdot.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */;
  TRACE_POP
}

/*
equation index: 341
type: SIMPLE_ASSIGN
$DER.discharge.Vdot.$pDERNLSJac188.dummyVarNLSJac188 = $DER.discharge.mdot.$pDERNLSJac188.dummyVarNLSJac188 / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_341(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 8;
  const int equationIndexes[2] = {1,341};
  jacobian->tmpVars[10] /* der(discharge.Vdot.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[9] /* der(discharge.mdot.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */,(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho");
  TRACE_POP
}

/*
equation index: 342
type: SIMPLE_ASSIGN
$DER.discharge.M.$pDERNLSJac188.dummyVarNLSJac188 = data.rho * discharge.L * $DER.discharge.Vdot.$pDERNLSJac188.dummyVarNLSJac188
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_342(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 9;
  const int equationIndexes[2] = {1,342};
  jacobian->tmpVars[11] /* der(discharge.M.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */ = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[51] /* discharge.L PARAM */)) * (jacobian->tmpVars[10] /* der(discharge.Vdot.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */));
  TRACE_POP
}

/*
equation index: 343
type: SIMPLE_ASSIGN
discharge.p_i.$pDERNLSJac188.dummyVarNLSJac188 = $DER.discharge.M.$pDERNLSJac188.dummyVarNLSJac188 / discharge.A_i
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_343(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 10;
  const int equationIndexes[2] = {1,343};
  jacobian->tmpVars[12] /* discharge.p_i.$pDERNLSJac188.dummyVarNLSJac188 JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[11] /* der(discharge.M.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */,(data->localData[0]->realVars[89] /* discharge.A_i variable */),"discharge.A_i");
  TRACE_POP
}

/*
equation index: 344
type: SIMPLE_ASSIGN
$DER.penstock.M.$pDERNLSJac188.dummyVarNLSJac188 = data.rho * penstock.L * $DER.discharge.Vdot.$pDERNLSJac188.dummyVarNLSJac188
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_344(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 11;
  const int equationIndexes[2] = {1,344};
  jacobian->tmpVars[14] /* der(penstock.M.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */ = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[69] /* penstock.L PARAM */)) * (jacobian->tmpVars[10] /* der(discharge.Vdot.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */));
  TRACE_POP
}

/*
equation index: 345
type: SIMPLE_ASSIGN
penstock.p_o.$pDERNLSJac188.dummyVarNLSJac188 = (intake.p_o.$pDERNLSJac188.dummyVarNLSJac188 * penstock.A_i - $DER.penstock.M.$pDERNLSJac188.dummyVarNLSJac188) / penstock.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_345(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 12;
  const int equationIndexes[2] = {1,345};
  jacobian->tmpVars[15] /* penstock.p_o.$pDERNLSJac188.dummyVarNLSJac188 JACOBIAN_DIFF_VAR */ = DIVISION((jacobian->tmpVars[3] /* intake.p_o.$pDERNLSJac188.dummyVarNLSJac188 JACOBIAN_DIFF_VAR */) * ((data->localData[0]->realVars[119] /* penstock.A_i variable */)) - jacobian->tmpVars[14] /* der(penstock.M.$pDERNLSJac188.dummyVarNLSJac188) JACOBIAN_DIFF_VAR */,(data->localData[0]->realVars[120] /* penstock.A_o variable */),"penstock.A_o");
  TRACE_POP
}

/*
equation index: 346
type: SIMPLE_ASSIGN
turbine1.Vdot.$pDERNLSJac188.dummyVarNLSJac188 = if turbine1.WaterCompress then (-discharge.mdot) * data.rho * data.beta * penstock.p_o.$pDERNLSJac188.dummyVarNLSJac188 / (data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 2.0 else 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_346(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 13;
  const int equationIndexes[2] = {1,346};
  modelica_real tmp9;
  modelica_boolean tmp10;
  modelica_real tmp11;
  tmp10 = (modelica_boolean)(data->simulationInfo->booleanParameter[15] /* turbine1.WaterCompress PARAM */);
  if(tmp10)
  {
    tmp9 = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (1.0 + ((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->simulationInfo->realParameter[45] /* data.p_a PARAM */)));
    tmp11 = DIVISION(((-(data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */))) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * (jacobian->tmpVars[15] /* penstock.p_o.$pDERNLSJac188.dummyVarNLSJac188 JACOBIAN_DIFF_VAR */))),(tmp9 * tmp9),"(data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 2.0");
  }
  else
  {
    tmp11 = 0.0;
  }
  jacobian->tmpVars[16] /* turbine1.Vdot.$pDERNLSJac188.dummyVarNLSJac188 JACOBIAN_DIFF_VAR */ = tmp11;
  TRACE_POP
}

/*
equation index: 347
type: SIMPLE_ASSIGN
turbine1.dp.$pDERNLSJac188.dummyVarNLSJac188 = 2.0 * turbine1.Vdot * turbine1.Vdot.$pDERNLSJac188.dummyVarNLSJac188 * data.p_a / (turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_347(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 14;
  const int equationIndexes[2] = {1,347};
  modelica_real tmp12;
  tmp12 = ((data->localData[0]->realVars[162] /* turbine1.C_v_ variable */)) * ((data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */));
  jacobian->tmpVars[17] /* turbine1.dp.$pDERNLSJac188.dummyVarNLSJac188 JACOBIAN_DIFF_VAR */ = (2.0) * (((data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */)) * ((jacobian->tmpVars[16] /* turbine1.Vdot.$pDERNLSJac188.dummyVarNLSJac188 JACOBIAN_DIFF_VAR */) * (DIVISION((data->simulationInfo->realParameter[45] /* data.p_a PARAM */),(tmp12 * tmp12),"(turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0"))));
  TRACE_POP
}

/*
equation index: 348
type: SIMPLE_ASSIGN
$res_NLSJac188_1.$pDERNLSJac188.dummyVarNLSJac188 = penstock.p_o.$pDERNLSJac188.dummyVarNLSJac188 + (-discharge.p_i.$pDERNLSJac188.dummyVarNLSJac188) - turbine1.dp.$pDERNLSJac188.dummyVarNLSJac188
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_348(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 15;
  const int equationIndexes[2] = {1,348};
  jacobian->resultVars[0] /* $res_NLSJac188_1.$pDERNLSJac188.dummyVarNLSJac188 JACOBIAN_VAR */ = jacobian->tmpVars[15] /* penstock.p_o.$pDERNLSJac188.dummyVarNLSJac188 JACOBIAN_DIFF_VAR */ + (-jacobian->tmpVars[12] /* discharge.p_i.$pDERNLSJac188.dummyVarNLSJac188 JACOBIAN_DIFF_VAR */) - jacobian->tmpVars[17] /* turbine1.dp.$pDERNLSJac188.dummyVarNLSJac188 JACOBIAN_DIFF_VAR */;
  TRACE_POP
}

OMC_DISABLE_OPT
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacNLSJac188_constantEqns(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_NLSJac188;
  
  
  TRACE_POP
  return 0;
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacNLSJac188_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_NLSJac188;
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_333(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_334(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_335(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_336(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_337(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_338(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_339(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_340(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_341(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_342(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_343(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_344(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_345(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_346(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_347(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_348(data, threadData, jacobian, parentJacobian);
  TRACE_POP
  return 0;
}
/* constant equations */
/* dynamic equations */

/*
equation index: 397
type: SIMPLE_ASSIGN
$DER.$DER.surgeTank.Vdot.$pDERLSJac189.dummyVarLSJac189 = $DER.$DER.surgeTank.v.SeedLSJac189 * surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_397(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 0;
  const int equationIndexes[2] = {1,397};
  jacobian->tmpVars[1] /* der(der(surgeTank.Vdot.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */ = (jacobian->seedVars[0] /* der(der(surgeTank.v.SeedLSJac189)) SEED_VAR */) * ((data->localData[0]->realVars[138] /* surgeTank.A variable */));
  TRACE_POP
}

/*
equation index: 398
type: SIMPLE_ASSIGN
$DER.$DER.surgeTank.mdot.$pDERLSJac189.dummyVarLSJac189 = data.rho * $DER.$DER.surgeTank.Vdot.$pDERLSJac189.dummyVarLSJac189
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_398(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 1;
  const int equationIndexes[2] = {1,398};
  jacobian->tmpVars[2] /* der(der(surgeTank.mdot.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */ = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (jacobian->tmpVars[1] /* der(der(surgeTank.Vdot.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */);
  TRACE_POP
}

/*
equation index: 399
type: SIMPLE_ASSIGN
$DER.surgeTank.F.$pDERLSJac189.dummyVarLSJac189 = surgeTank.m * $DER.$DER.surgeTank.v.SeedLSJac189
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_399(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 2;
  const int equationIndexes[2] = {1,399};
  jacobian->tmpVars[3] /* der(surgeTank.F.$pDERLSJac189.dummyVarLSJac189) JACOBIAN_DIFF_VAR */ = ((data->localData[0]->realVars[2] /* surgeTank.m STATE(1,surgeTank.mdot) */)) * (jacobian->seedVars[0] /* der(der(surgeTank.v.SeedLSJac189)) SEED_VAR */);
  TRACE_POP
}

/*
equation index: 400
type: SIMPLE_ASSIGN
$DER.intake.p_o.$pDERLSJac189.dummyVarLSJac189 = $DER.surgeTank.F.$pDERLSJac189.dummyVarLSJac189 / surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_400(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 3;
  const int equationIndexes[2] = {1,400};
  jacobian->tmpVars[5] /* der(intake.p_o.$pDERLSJac189.dummyVarLSJac189) JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[3] /* der(surgeTank.F.$pDERLSJac189.dummyVarLSJac189) JACOBIAN_DIFF_VAR */,(data->localData[0]->realVars[138] /* surgeTank.A variable */),"surgeTank.A");
  TRACE_POP
}

/*
equation index: 401
type: SIMPLE_ASSIGN
$DER.$DER.intake.M.$pDERLSJac189.dummyVarLSJac189 = (-$DER.intake.p_o.$pDERLSJac189.dummyVarLSJac189) * intake.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_401(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 4;
  const int equationIndexes[2] = {1,401};
  jacobian->tmpVars[6] /* der(der(intake.M.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */ = ((-jacobian->tmpVars[5] /* der(intake.p_o.$pDERLSJac189.dummyVarLSJac189) JACOBIAN_DIFF_VAR */)) * ((data->localData[0]->realVars[107] /* intake.A_o variable */));
  TRACE_POP
}

/*
equation index: 402
type: SIMPLE_ASSIGN
$DER.$DER.intake.Vdot.$pDERLSJac189.dummyVarLSJac189 = $DER.$DER.intake.M.$pDERLSJac189.dummyVarLSJac189 / (data.rho * intake.L)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_402(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 5;
  const int equationIndexes[2] = {1,402};
  jacobian->tmpVars[7] /* der(der(intake.Vdot.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[6] /* der(der(intake.M.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */,((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->simulationInfo->realParameter[62] /* intake.L PARAM */)),"data.rho * intake.L");
  TRACE_POP
}

/*
equation index: 403
type: SIMPLE_ASSIGN
$DER.$DER.intake.mdot.$pDERLSJac189.dummyVarLSJac189 = $DER.$DER.intake.Vdot.$pDERLSJac189.dummyVarLSJac189 * data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_403(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 6;
  const int equationIndexes[2] = {1,403};
  jacobian->tmpVars[8] /* der(der(intake.mdot.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */ = (jacobian->tmpVars[7] /* der(der(intake.Vdot.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */) * ((data->simulationInfo->realParameter[47] /* data.rho PARAM */));
  TRACE_POP
}

/*
equation index: 404
type: SIMPLE_ASSIGN
$DER.$DER.discharge.mdot.$pDERLSJac189.dummyVarLSJac189 = $DER.$DER.intake.mdot.$pDERLSJac189.dummyVarLSJac189 - $DER.$DER.surgeTank.mdot.$pDERLSJac189.dummyVarLSJac189
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_404(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 7;
  const int equationIndexes[2] = {1,404};
  jacobian->tmpVars[9] /* der(der(discharge.mdot.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */ = jacobian->tmpVars[8] /* der(der(intake.mdot.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */ - jacobian->tmpVars[2] /* der(der(surgeTank.mdot.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */;
  TRACE_POP
}

/*
equation index: 405
type: SIMPLE_ASSIGN
$DER.$DER.discharge.Vdot.$pDERLSJac189.dummyVarLSJac189 = $DER.$DER.discharge.mdot.$pDERLSJac189.dummyVarLSJac189 / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_405(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 8;
  const int equationIndexes[2] = {1,405};
  jacobian->tmpVars[10] /* der(der(discharge.Vdot.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[9] /* der(der(discharge.mdot.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */,(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho");
  TRACE_POP
}

/*
equation index: 406
type: SIMPLE_ASSIGN
$DER.$DER.discharge.M.$pDERLSJac189.dummyVarLSJac189 = data.rho * discharge.L * $DER.$DER.discharge.Vdot.$pDERLSJac189.dummyVarLSJac189
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_406(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 9;
  const int equationIndexes[2] = {1,406};
  jacobian->tmpVars[11] /* der(der(discharge.M.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */ = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[51] /* discharge.L PARAM */)) * (jacobian->tmpVars[10] /* der(der(discharge.Vdot.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */));
  TRACE_POP
}

/*
equation index: 407
type: SIMPLE_ASSIGN
$DER.discharge.p_i.$pDERLSJac189.dummyVarLSJac189 = $DER.$DER.discharge.M.$pDERLSJac189.dummyVarLSJac189 / discharge.A_i
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_407(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 10;
  const int equationIndexes[2] = {1,407};
  jacobian->tmpVars[12] /* der(discharge.p_i.$pDERLSJac189.dummyVarLSJac189) JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[11] /* der(der(discharge.M.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */,(data->localData[0]->realVars[89] /* discharge.A_i variable */),"discharge.A_i");
  TRACE_POP
}

/*
equation index: 408
type: SIMPLE_ASSIGN
$DER.$DER.penstock.M.$pDERLSJac189.dummyVarLSJac189 = data.rho * penstock.L * $DER.$DER.discharge.Vdot.$pDERLSJac189.dummyVarLSJac189
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_408(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 11;
  const int equationIndexes[2] = {1,408};
  jacobian->tmpVars[14] /* der(der(penstock.M.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */ = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[69] /* penstock.L PARAM */)) * (jacobian->tmpVars[10] /* der(der(discharge.Vdot.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */));
  TRACE_POP
}

/*
equation index: 409
type: SIMPLE_ASSIGN
$DER.penstock.p_o.$pDERLSJac189.dummyVarLSJac189 = ($DER.intake.p_o.$pDERLSJac189.dummyVarLSJac189 * penstock.A_i - $DER.$DER.penstock.M.$pDERLSJac189.dummyVarLSJac189) / penstock.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_409(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 12;
  const int equationIndexes[2] = {1,409};
  jacobian->tmpVars[15] /* der(penstock.p_o.$pDERLSJac189.dummyVarLSJac189) JACOBIAN_DIFF_VAR */ = DIVISION((jacobian->tmpVars[5] /* der(intake.p_o.$pDERLSJac189.dummyVarLSJac189) JACOBIAN_DIFF_VAR */) * ((data->localData[0]->realVars[119] /* penstock.A_i variable */)) - jacobian->tmpVars[14] /* der(der(penstock.M.$pDERLSJac189.dummyVarLSJac189)) JACOBIAN_DIFF_VAR */,(data->localData[0]->realVars[120] /* penstock.A_o variable */),"penstock.A_o");
  TRACE_POP
}

/*
equation index: 410
type: SIMPLE_ASSIGN
$DER.turbine1.Vdot.$pDERLSJac189.dummyVarLSJac189 = if turbine1.WaterCompress then (-data.rho) * discharge.mdot * data.beta * $DER.penstock.p_o.$pDERLSJac189.dummyVarLSJac189 * (data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 2.0 / (data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 4.0 else 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_410(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 13;
  const int equationIndexes[2] = {1,410};
  modelica_real tmp13;
  modelica_real tmp14;
  modelica_boolean tmp15;
  modelica_real tmp16;
  tmp15 = (modelica_boolean)(data->simulationInfo->booleanParameter[15] /* turbine1.WaterCompress PARAM */);
  if(tmp15)
  {
    tmp13 = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (1.0 + ((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->simulationInfo->realParameter[45] /* data.p_a PARAM */)));
    tmp14 = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (1.0 + ((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->simulationInfo->realParameter[45] /* data.p_a PARAM */)));
    tmp14 *= tmp14;
    tmp16 = DIVISION((((-(data->simulationInfo->realParameter[47] /* data.rho PARAM */))) * (((data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */)) * (((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * (jacobian->tmpVars[15] /* der(penstock.p_o.$pDERLSJac189.dummyVarLSJac189) JACOBIAN_DIFF_VAR */)))) * ((tmp13 * tmp13)),(tmp14 * tmp14),"(data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 4.0");
  }
  else
  {
    tmp16 = 0.0;
  }
  jacobian->tmpVars[16] /* der(turbine1.Vdot.$pDERLSJac189.dummyVarLSJac189) JACOBIAN_DIFF_VAR */ = tmp16;
  TRACE_POP
}

/*
equation index: 411
type: SIMPLE_ASSIGN
$DER.turbine1.dp.$pDERLSJac189.dummyVarLSJac189 = 2.0 * turbine1.Vdot * $DER.turbine1.Vdot.$pDERLSJac189.dummyVarLSJac189 * data.p_a / (turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_411(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 14;
  const int equationIndexes[2] = {1,411};
  modelica_real tmp17;
  tmp17 = ((data->localData[0]->realVars[162] /* turbine1.C_v_ variable */)) * ((data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */));
  jacobian->tmpVars[17] /* der(turbine1.dp.$pDERLSJac189.dummyVarLSJac189) JACOBIAN_DIFF_VAR */ = (2.0) * (((data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */)) * ((jacobian->tmpVars[16] /* der(turbine1.Vdot.$pDERLSJac189.dummyVarLSJac189) JACOBIAN_DIFF_VAR */) * (DIVISION((data->simulationInfo->realParameter[45] /* data.p_a PARAM */),(tmp17 * tmp17),"(turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0"))));
  TRACE_POP
}

/*
equation index: 412
type: SIMPLE_ASSIGN
$res_LSJac189_1.$pDERLSJac189.dummyVarLSJac189 = $DER.penstock.p_o.$pDERLSJac189.dummyVarLSJac189 + (-$DER.discharge.p_i.$pDERLSJac189.dummyVarLSJac189) - $DER.turbine1.dp.$pDERLSJac189.dummyVarLSJac189
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_412(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 15;
  const int equationIndexes[2] = {1,412};
  jacobian->resultVars[0] /* $res_LSJac189_1.$pDERLSJac189.dummyVarLSJac189 JACOBIAN_VAR */ = jacobian->tmpVars[15] /* der(penstock.p_o.$pDERLSJac189.dummyVarLSJac189) JACOBIAN_DIFF_VAR */ + (-jacobian->tmpVars[12] /* der(discharge.p_i.$pDERLSJac189.dummyVarLSJac189) JACOBIAN_DIFF_VAR */) - jacobian->tmpVars[17] /* der(turbine1.dp.$pDERLSJac189.dummyVarLSJac189) JACOBIAN_DIFF_VAR */;
  TRACE_POP
}

OMC_DISABLE_OPT
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacLSJac189_constantEqns(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_LSJac189;
  
  
  TRACE_POP
  return 0;
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacLSJac189_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_LSJac189;
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_397(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_398(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_399(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_400(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_401(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_402(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_403(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_404(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_405(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_406(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_407(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_408(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_409(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_410(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_411(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_412(data, threadData, jacobian, parentJacobian);
  TRACE_POP
  return 0;
}
/* constant equations */
/* dynamic equations */

/*
equation index: 538
type: SIMPLE_ASSIGN
$DER.surgeTank.Vdot.$pDERNLSJac190.dummyVarNLSJac190 = $DER.surgeTank.v.SeedNLSJac190 * surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_538(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 0;
  const int equationIndexes[2] = {1,538};
  jacobian->tmpVars[7] /* der(surgeTank.Vdot.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */ = (jacobian->seedVars[0] /* der(surgeTank.v.SeedNLSJac190) SEED_VAR */) * ((data->localData[0]->realVars[138] /* surgeTank.A variable */));
  TRACE_POP
}

/*
equation index: 539
type: SIMPLE_ASSIGN
$DER.surgeTank.mdot.$pDERNLSJac190.dummyVarNLSJac190 = data.rho * $DER.surgeTank.Vdot.$pDERNLSJac190.dummyVarNLSJac190
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_539(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 1;
  const int equationIndexes[2] = {1,539};
  jacobian->tmpVars[8] /* der(surgeTank.mdot.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */ = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (jacobian->tmpVars[7] /* der(surgeTank.Vdot.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */);
  TRACE_POP
}

/*
equation index: 540
type: SIMPLE_ASSIGN
surgeTank.F.$pDERNLSJac190.dummyVarNLSJac190 = surgeTank.m * $DER.surgeTank.v.SeedNLSJac190
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_540(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 2;
  const int equationIndexes[2] = {1,540};
  jacobian->tmpVars[1] /* surgeTank.F.$pDERNLSJac190.dummyVarNLSJac190 JACOBIAN_DIFF_VAR */ = ((data->localData[0]->realVars[2] /* surgeTank.m STATE(1,surgeTank.mdot) */)) * (jacobian->seedVars[0] /* der(surgeTank.v.SeedNLSJac190) SEED_VAR */);
  TRACE_POP
}

/*
equation index: 541
type: SIMPLE_ASSIGN
intake.p_o.$pDERNLSJac190.dummyVarNLSJac190 = surgeTank.F.$pDERNLSJac190.dummyVarNLSJac190 / surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_541(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 3;
  const int equationIndexes[2] = {1,541};
  jacobian->tmpVars[3] /* intake.p_o.$pDERNLSJac190.dummyVarNLSJac190 JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[1] /* surgeTank.F.$pDERNLSJac190.dummyVarNLSJac190 JACOBIAN_DIFF_VAR */,(data->localData[0]->realVars[138] /* surgeTank.A variable */),"surgeTank.A");
  TRACE_POP
}

/*
equation index: 542
type: SIMPLE_ASSIGN
$DER.intake.M.$pDERNLSJac190.dummyVarNLSJac190 = (-intake.p_o.$pDERNLSJac190.dummyVarNLSJac190) * intake.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_542(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 4;
  const int equationIndexes[2] = {1,542};
  jacobian->tmpVars[4] /* der(intake.M.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */ = ((-jacobian->tmpVars[3] /* intake.p_o.$pDERNLSJac190.dummyVarNLSJac190 JACOBIAN_DIFF_VAR */)) * ((data->localData[0]->realVars[107] /* intake.A_o variable */));
  TRACE_POP
}

/*
equation index: 543
type: SIMPLE_ASSIGN
$DER.intake.Vdot.$pDERNLSJac190.dummyVarNLSJac190 = $DER.intake.M.$pDERNLSJac190.dummyVarNLSJac190 / (data.rho * intake.L)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_543(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 5;
  const int equationIndexes[2] = {1,543};
  jacobian->tmpVars[5] /* der(intake.Vdot.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[4] /* der(intake.M.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */,((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->simulationInfo->realParameter[62] /* intake.L PARAM */)),"data.rho * intake.L");
  TRACE_POP
}

/*
equation index: 544
type: SIMPLE_ASSIGN
$DER.intake.mdot.$pDERNLSJac190.dummyVarNLSJac190 = $DER.intake.Vdot.$pDERNLSJac190.dummyVarNLSJac190 * data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_544(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 6;
  const int equationIndexes[2] = {1,544};
  jacobian->tmpVars[6] /* der(intake.mdot.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */ = (jacobian->tmpVars[5] /* der(intake.Vdot.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */) * ((data->simulationInfo->realParameter[47] /* data.rho PARAM */));
  TRACE_POP
}

/*
equation index: 545
type: SIMPLE_ASSIGN
$DER.discharge.mdot.$pDERNLSJac190.dummyVarNLSJac190 = $DER.intake.mdot.$pDERNLSJac190.dummyVarNLSJac190 - $DER.surgeTank.mdot.$pDERNLSJac190.dummyVarNLSJac190
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_545(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 7;
  const int equationIndexes[2] = {1,545};
  jacobian->tmpVars[9] /* der(discharge.mdot.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */ = jacobian->tmpVars[6] /* der(intake.mdot.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */ - jacobian->tmpVars[8] /* der(surgeTank.mdot.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */;
  TRACE_POP
}

/*
equation index: 546
type: SIMPLE_ASSIGN
$DER.discharge.Vdot.$pDERNLSJac190.dummyVarNLSJac190 = $DER.discharge.mdot.$pDERNLSJac190.dummyVarNLSJac190 / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_546(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 8;
  const int equationIndexes[2] = {1,546};
  jacobian->tmpVars[10] /* der(discharge.Vdot.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[9] /* der(discharge.mdot.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */,(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho");
  TRACE_POP
}

/*
equation index: 547
type: SIMPLE_ASSIGN
$DER.discharge.M.$pDERNLSJac190.dummyVarNLSJac190 = data.rho * discharge.L * $DER.discharge.Vdot.$pDERNLSJac190.dummyVarNLSJac190
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_547(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 9;
  const int equationIndexes[2] = {1,547};
  jacobian->tmpVars[11] /* der(discharge.M.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */ = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[51] /* discharge.L PARAM */)) * (jacobian->tmpVars[10] /* der(discharge.Vdot.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */));
  TRACE_POP
}

/*
equation index: 548
type: SIMPLE_ASSIGN
discharge.p_i.$pDERNLSJac190.dummyVarNLSJac190 = $DER.discharge.M.$pDERNLSJac190.dummyVarNLSJac190 / discharge.A_i
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_548(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 10;
  const int equationIndexes[2] = {1,548};
  jacobian->tmpVars[12] /* discharge.p_i.$pDERNLSJac190.dummyVarNLSJac190 JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[11] /* der(discharge.M.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */,(data->localData[0]->realVars[89] /* discharge.A_i variable */),"discharge.A_i");
  TRACE_POP
}

/*
equation index: 549
type: SIMPLE_ASSIGN
$DER.penstock.M.$pDERNLSJac190.dummyVarNLSJac190 = data.rho * penstock.L * $DER.discharge.Vdot.$pDERNLSJac190.dummyVarNLSJac190
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_549(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 11;
  const int equationIndexes[2] = {1,549};
  jacobian->tmpVars[14] /* der(penstock.M.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */ = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[69] /* penstock.L PARAM */)) * (jacobian->tmpVars[10] /* der(discharge.Vdot.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */));
  TRACE_POP
}

/*
equation index: 550
type: SIMPLE_ASSIGN
penstock.p_o.$pDERNLSJac190.dummyVarNLSJac190 = (intake.p_o.$pDERNLSJac190.dummyVarNLSJac190 * penstock.A_i - $DER.penstock.M.$pDERNLSJac190.dummyVarNLSJac190) / penstock.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_550(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 12;
  const int equationIndexes[2] = {1,550};
  jacobian->tmpVars[15] /* penstock.p_o.$pDERNLSJac190.dummyVarNLSJac190 JACOBIAN_DIFF_VAR */ = DIVISION((jacobian->tmpVars[3] /* intake.p_o.$pDERNLSJac190.dummyVarNLSJac190 JACOBIAN_DIFF_VAR */) * ((data->localData[0]->realVars[119] /* penstock.A_i variable */)) - jacobian->tmpVars[14] /* der(penstock.M.$pDERNLSJac190.dummyVarNLSJac190) JACOBIAN_DIFF_VAR */,(data->localData[0]->realVars[120] /* penstock.A_o variable */),"penstock.A_o");
  TRACE_POP
}

/*
equation index: 551
type: SIMPLE_ASSIGN
turbine1.Vdot.$pDERNLSJac190.dummyVarNLSJac190 = if turbine1.WaterCompress then (-discharge.mdot) * data.rho * data.beta * penstock.p_o.$pDERNLSJac190.dummyVarNLSJac190 / (data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 2.0 else 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_551(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 13;
  const int equationIndexes[2] = {1,551};
  modelica_real tmp18;
  modelica_boolean tmp19;
  modelica_real tmp20;
  tmp19 = (modelica_boolean)(data->simulationInfo->booleanParameter[15] /* turbine1.WaterCompress PARAM */);
  if(tmp19)
  {
    tmp18 = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (1.0 + ((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->simulationInfo->realParameter[45] /* data.p_a PARAM */)));
    tmp20 = DIVISION(((-(data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */))) * (((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * (jacobian->tmpVars[15] /* penstock.p_o.$pDERNLSJac190.dummyVarNLSJac190 JACOBIAN_DIFF_VAR */))),(tmp18 * tmp18),"(data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 2.0");
  }
  else
  {
    tmp20 = 0.0;
  }
  jacobian->tmpVars[16] /* turbine1.Vdot.$pDERNLSJac190.dummyVarNLSJac190 JACOBIAN_DIFF_VAR */ = tmp20;
  TRACE_POP
}

/*
equation index: 552
type: SIMPLE_ASSIGN
turbine1.dp.$pDERNLSJac190.dummyVarNLSJac190 = 2.0 * turbine1.Vdot * turbine1.Vdot.$pDERNLSJac190.dummyVarNLSJac190 * data.p_a / (turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_552(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 14;
  const int equationIndexes[2] = {1,552};
  modelica_real tmp21;
  tmp21 = ((data->localData[0]->realVars[162] /* turbine1.C_v_ variable */)) * ((data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */));
  jacobian->tmpVars[17] /* turbine1.dp.$pDERNLSJac190.dummyVarNLSJac190 JACOBIAN_DIFF_VAR */ = (2.0) * (((data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */)) * ((jacobian->tmpVars[16] /* turbine1.Vdot.$pDERNLSJac190.dummyVarNLSJac190 JACOBIAN_DIFF_VAR */) * (DIVISION((data->simulationInfo->realParameter[45] /* data.p_a PARAM */),(tmp21 * tmp21),"(turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0"))));
  TRACE_POP
}

/*
equation index: 553
type: SIMPLE_ASSIGN
$res_NLSJac190_1.$pDERNLSJac190.dummyVarNLSJac190 = penstock.p_o.$pDERNLSJac190.dummyVarNLSJac190 + (-discharge.p_i.$pDERNLSJac190.dummyVarNLSJac190) - turbine1.dp.$pDERNLSJac190.dummyVarNLSJac190
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_553(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 15;
  const int equationIndexes[2] = {1,553};
  jacobian->resultVars[0] /* $res_NLSJac190_1.$pDERNLSJac190.dummyVarNLSJac190 JACOBIAN_VAR */ = jacobian->tmpVars[15] /* penstock.p_o.$pDERNLSJac190.dummyVarNLSJac190 JACOBIAN_DIFF_VAR */ + (-jacobian->tmpVars[12] /* discharge.p_i.$pDERNLSJac190.dummyVarNLSJac190 JACOBIAN_DIFF_VAR */) - jacobian->tmpVars[17] /* turbine1.dp.$pDERNLSJac190.dummyVarNLSJac190 JACOBIAN_DIFF_VAR */;
  TRACE_POP
}

OMC_DISABLE_OPT
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacNLSJac190_constantEqns(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_NLSJac190;
  
  
  TRACE_POP
  return 0;
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacNLSJac190_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_NLSJac190;
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_538(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_539(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_540(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_541(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_542(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_543(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_544(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_545(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_546(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_547(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_548(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_549(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_550(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_551(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_552(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_553(data, threadData, jacobian, parentJacobian);
  TRACE_POP
  return 0;
}
/* constant equations */
/* dynamic equations */

/*
equation index: 605
type: SIMPLE_ASSIGN
$DER.$DER.surgeTank.Vdot.$pDERLSJac191.dummyVarLSJac191 = $DER.$DER.surgeTank.v.SeedLSJac191 * surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_605(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 0;
  const int equationIndexes[2] = {1,605};
  jacobian->tmpVars[1] /* der(der(surgeTank.Vdot.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */ = (jacobian->seedVars[0] /* der(der(surgeTank.v.SeedLSJac191)) SEED_VAR */) * ((data->localData[0]->realVars[138] /* surgeTank.A variable */));
  TRACE_POP
}

/*
equation index: 606
type: SIMPLE_ASSIGN
$DER.$DER.surgeTank.mdot.$pDERLSJac191.dummyVarLSJac191 = data.rho * $DER.$DER.surgeTank.Vdot.$pDERLSJac191.dummyVarLSJac191
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_606(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 1;
  const int equationIndexes[2] = {1,606};
  jacobian->tmpVars[2] /* der(der(surgeTank.mdot.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */ = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (jacobian->tmpVars[1] /* der(der(surgeTank.Vdot.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */);
  TRACE_POP
}

/*
equation index: 607
type: SIMPLE_ASSIGN
$DER.surgeTank.F.$pDERLSJac191.dummyVarLSJac191 = surgeTank.m * $DER.$DER.surgeTank.v.SeedLSJac191
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_607(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 2;
  const int equationIndexes[2] = {1,607};
  jacobian->tmpVars[3] /* der(surgeTank.F.$pDERLSJac191.dummyVarLSJac191) JACOBIAN_DIFF_VAR */ = ((data->localData[0]->realVars[2] /* surgeTank.m STATE(1,surgeTank.mdot) */)) * (jacobian->seedVars[0] /* der(der(surgeTank.v.SeedLSJac191)) SEED_VAR */);
  TRACE_POP
}

/*
equation index: 608
type: SIMPLE_ASSIGN
$DER.intake.p_o.$pDERLSJac191.dummyVarLSJac191 = $DER.surgeTank.F.$pDERLSJac191.dummyVarLSJac191 / surgeTank.A
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_608(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 3;
  const int equationIndexes[2] = {1,608};
  jacobian->tmpVars[5] /* der(intake.p_o.$pDERLSJac191.dummyVarLSJac191) JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[3] /* der(surgeTank.F.$pDERLSJac191.dummyVarLSJac191) JACOBIAN_DIFF_VAR */,(data->localData[0]->realVars[138] /* surgeTank.A variable */),"surgeTank.A");
  TRACE_POP
}

/*
equation index: 609
type: SIMPLE_ASSIGN
$DER.$DER.intake.M.$pDERLSJac191.dummyVarLSJac191 = (-$DER.intake.p_o.$pDERLSJac191.dummyVarLSJac191) * intake.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_609(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 4;
  const int equationIndexes[2] = {1,609};
  jacobian->tmpVars[6] /* der(der(intake.M.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */ = ((-jacobian->tmpVars[5] /* der(intake.p_o.$pDERLSJac191.dummyVarLSJac191) JACOBIAN_DIFF_VAR */)) * ((data->localData[0]->realVars[107] /* intake.A_o variable */));
  TRACE_POP
}

/*
equation index: 610
type: SIMPLE_ASSIGN
$DER.$DER.intake.Vdot.$pDERLSJac191.dummyVarLSJac191 = $DER.$DER.intake.M.$pDERLSJac191.dummyVarLSJac191 / (data.rho * intake.L)
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_610(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 5;
  const int equationIndexes[2] = {1,610};
  jacobian->tmpVars[7] /* der(der(intake.Vdot.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[6] /* der(der(intake.M.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */,((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * ((data->simulationInfo->realParameter[62] /* intake.L PARAM */)),"data.rho * intake.L");
  TRACE_POP
}

/*
equation index: 611
type: SIMPLE_ASSIGN
$DER.$DER.intake.mdot.$pDERLSJac191.dummyVarLSJac191 = $DER.$DER.intake.Vdot.$pDERLSJac191.dummyVarLSJac191 * data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_611(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 6;
  const int equationIndexes[2] = {1,611};
  jacobian->tmpVars[8] /* der(der(intake.mdot.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */ = (jacobian->tmpVars[7] /* der(der(intake.Vdot.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */) * ((data->simulationInfo->realParameter[47] /* data.rho PARAM */));
  TRACE_POP
}

/*
equation index: 612
type: SIMPLE_ASSIGN
$DER.$DER.discharge.mdot.$pDERLSJac191.dummyVarLSJac191 = $DER.$DER.intake.mdot.$pDERLSJac191.dummyVarLSJac191 - $DER.$DER.surgeTank.mdot.$pDERLSJac191.dummyVarLSJac191
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_612(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 7;
  const int equationIndexes[2] = {1,612};
  jacobian->tmpVars[9] /* der(der(discharge.mdot.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */ = jacobian->tmpVars[8] /* der(der(intake.mdot.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */ - jacobian->tmpVars[2] /* der(der(surgeTank.mdot.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */;
  TRACE_POP
}

/*
equation index: 613
type: SIMPLE_ASSIGN
$DER.$DER.discharge.Vdot.$pDERLSJac191.dummyVarLSJac191 = $DER.$DER.discharge.mdot.$pDERLSJac191.dummyVarLSJac191 / data.rho
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_613(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 8;
  const int equationIndexes[2] = {1,613};
  jacobian->tmpVars[10] /* der(der(discharge.Vdot.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[9] /* der(der(discharge.mdot.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */,(data->simulationInfo->realParameter[47] /* data.rho PARAM */),"data.rho");
  TRACE_POP
}

/*
equation index: 614
type: SIMPLE_ASSIGN
$DER.$DER.discharge.M.$pDERLSJac191.dummyVarLSJac191 = data.rho * discharge.L * $DER.$DER.discharge.Vdot.$pDERLSJac191.dummyVarLSJac191
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_614(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 9;
  const int equationIndexes[2] = {1,614};
  jacobian->tmpVars[11] /* der(der(discharge.M.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */ = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[51] /* discharge.L PARAM */)) * (jacobian->tmpVars[10] /* der(der(discharge.Vdot.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */));
  TRACE_POP
}

/*
equation index: 615
type: SIMPLE_ASSIGN
$DER.discharge.p_i.$pDERLSJac191.dummyVarLSJac191 = $DER.$DER.discharge.M.$pDERLSJac191.dummyVarLSJac191 / discharge.A_i
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_615(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 10;
  const int equationIndexes[2] = {1,615};
  jacobian->tmpVars[12] /* der(discharge.p_i.$pDERLSJac191.dummyVarLSJac191) JACOBIAN_DIFF_VAR */ = DIVISION(jacobian->tmpVars[11] /* der(der(discharge.M.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */,(data->localData[0]->realVars[89] /* discharge.A_i variable */),"discharge.A_i");
  TRACE_POP
}

/*
equation index: 616
type: SIMPLE_ASSIGN
$DER.$DER.penstock.M.$pDERLSJac191.dummyVarLSJac191 = data.rho * penstock.L * $DER.$DER.discharge.Vdot.$pDERLSJac191.dummyVarLSJac191
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_616(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 11;
  const int equationIndexes[2] = {1,616};
  jacobian->tmpVars[14] /* der(der(penstock.M.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */ = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (((data->simulationInfo->realParameter[69] /* penstock.L PARAM */)) * (jacobian->tmpVars[10] /* der(der(discharge.Vdot.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */));
  TRACE_POP
}

/*
equation index: 617
type: SIMPLE_ASSIGN
$DER.penstock.p_o.$pDERLSJac191.dummyVarLSJac191 = ($DER.intake.p_o.$pDERLSJac191.dummyVarLSJac191 * penstock.A_i - $DER.$DER.penstock.M.$pDERLSJac191.dummyVarLSJac191) / penstock.A_o
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_617(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 12;
  const int equationIndexes[2] = {1,617};
  jacobian->tmpVars[15] /* der(penstock.p_o.$pDERLSJac191.dummyVarLSJac191) JACOBIAN_DIFF_VAR */ = DIVISION((jacobian->tmpVars[5] /* der(intake.p_o.$pDERLSJac191.dummyVarLSJac191) JACOBIAN_DIFF_VAR */) * ((data->localData[0]->realVars[119] /* penstock.A_i variable */)) - jacobian->tmpVars[14] /* der(der(penstock.M.$pDERLSJac191.dummyVarLSJac191)) JACOBIAN_DIFF_VAR */,(data->localData[0]->realVars[120] /* penstock.A_o variable */),"penstock.A_o");
  TRACE_POP
}

/*
equation index: 618
type: SIMPLE_ASSIGN
$DER.turbine1.Vdot.$pDERLSJac191.dummyVarLSJac191 = if turbine1.WaterCompress then (-data.rho) * discharge.mdot * data.beta * $DER.penstock.p_o.$pDERLSJac191.dummyVarLSJac191 * (data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 2.0 / (data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 4.0 else 0.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_618(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 13;
  const int equationIndexes[2] = {1,618};
  modelica_real tmp22;
  modelica_real tmp23;
  modelica_boolean tmp24;
  modelica_real tmp25;
  tmp24 = (modelica_boolean)(data->simulationInfo->booleanParameter[15] /* turbine1.WaterCompress PARAM */);
  if(tmp24)
  {
    tmp22 = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (1.0 + ((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->simulationInfo->realParameter[45] /* data.p_a PARAM */)));
    tmp23 = ((data->simulationInfo->realParameter[47] /* data.rho PARAM */)) * (1.0 + ((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * ((data->localData[0]->realVars[127] /* penstock.p_o DUMMY_STATE */) - (data->simulationInfo->realParameter[45] /* data.p_a PARAM */)));
    tmp23 *= tmp23;
    tmp25 = DIVISION((((-(data->simulationInfo->realParameter[47] /* data.rho PARAM */))) * (((data->localData[0]->realVars[98] /* discharge.mdot DUMMY_STATE */)) * (((data->simulationInfo->realParameter[38] /* data.beta PARAM */)) * (jacobian->tmpVars[15] /* der(penstock.p_o.$pDERLSJac191.dummyVarLSJac191) JACOBIAN_DIFF_VAR */)))) * ((tmp22 * tmp22)),(tmp23 * tmp23),"(data.rho * (1.0 + data.beta * (penstock.p_o - data.p_a))) ^ 4.0");
  }
  else
  {
    tmp25 = 0.0;
  }
  jacobian->tmpVars[16] /* der(turbine1.Vdot.$pDERLSJac191.dummyVarLSJac191) JACOBIAN_DIFF_VAR */ = tmp25;
  TRACE_POP
}

/*
equation index: 619
type: SIMPLE_ASSIGN
$DER.turbine1.dp.$pDERLSJac191.dummyVarLSJac191 = 2.0 * turbine1.Vdot * $DER.turbine1.Vdot.$pDERLSJac191.dummyVarLSJac191 * data.p_a / (turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_619(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 14;
  const int equationIndexes[2] = {1,619};
  modelica_real tmp26;
  tmp26 = ((data->localData[0]->realVars[162] /* turbine1.C_v_ variable */)) * ((data->localData[0]->realVars[179] /* turbine1.look_up_table.u[1] DUMMY_STATE */));
  jacobian->tmpVars[17] /* der(turbine1.dp.$pDERLSJac191.dummyVarLSJac191) JACOBIAN_DIFF_VAR */ = (2.0) * (((data->localData[0]->realVars[164] /* turbine1.Vdot DUMMY_STATE */)) * ((jacobian->tmpVars[16] /* der(turbine1.Vdot.$pDERLSJac191.dummyVarLSJac191) JACOBIAN_DIFF_VAR */) * (DIVISION((data->simulationInfo->realParameter[45] /* data.p_a PARAM */),(tmp26 * tmp26),"(turbine1.C_v_ * turbine1.look_up_table.u[1]) ^ 2.0"))));
  TRACE_POP
}

/*
equation index: 620
type: SIMPLE_ASSIGN
$res_LSJac191_1.$pDERLSJac191.dummyVarLSJac191 = $DER.penstock.p_o.$pDERLSJac191.dummyVarLSJac191 + (-$DER.discharge.p_i.$pDERLSJac191.dummyVarLSJac191) - $DER.turbine1.dp.$pDERLSJac191.dummyVarLSJac191
*/
void TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_620(DATA *data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  const int baseClockIndex = 0;
  const int subClockIndex = 15;
  const int equationIndexes[2] = {1,620};
  jacobian->resultVars[0] /* $res_LSJac191_1.$pDERLSJac191.dummyVarLSJac191 JACOBIAN_VAR */ = jacobian->tmpVars[15] /* der(penstock.p_o.$pDERLSJac191.dummyVarLSJac191) JACOBIAN_DIFF_VAR */ + (-jacobian->tmpVars[12] /* der(discharge.p_i.$pDERLSJac191.dummyVarLSJac191) JACOBIAN_DIFF_VAR */) - jacobian->tmpVars[17] /* der(turbine1.dp.$pDERLSJac191.dummyVarLSJac191) JACOBIAN_DIFF_VAR */;
  TRACE_POP
}

OMC_DISABLE_OPT
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacLSJac191_constantEqns(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_LSJac191;
  
  
  TRACE_POP
  return 0;
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacLSJac191_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_LSJac191;
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_605(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_606(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_607(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_608(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_609(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_610(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_611(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_612(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_613(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_614(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_615(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_616(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_617(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_618(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_619(data, threadData, jacobian, parentJacobian);
  TestPackage_ActiveWork_WaterModel_HydroPowerModel1_eqFunction_620(data, threadData, jacobian, parentJacobian);
  TRACE_POP
  return 0;
}
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacH_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  TRACE_POP
  return 0;
}
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacF_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  TRACE_POP
  return 0;
}
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacD_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  TRACE_POP
  return 0;
}
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacC_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  TRACE_POP
  return 0;
}
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacB_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH
  TRACE_POP
  return 0;
}
/* constant equations */
/* dynamic equations */

OMC_DISABLE_OPT
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacA_constantEqns(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_A;
  
  
  TRACE_POP
  return 0;
}

int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacA_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian, ANALYTIC_JACOBIAN *parentJacobian)
{
  TRACE_PUSH

  int index = TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_A;
  TRACE_POP
  return 0;
}

OMC_DISABLE_OPT
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianNLSJac186(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  size_t count;

  FILE* pFile = openSparsePatternFile(data, threadData, "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_JacNLSJac186.bin");
  
  initAnalyticJacobian(jacobian, 1, 1, 19, NULL, jacobian->sparsePattern);
  jacobian->sparsePattern = allocSparsePattern(1, 1, 1);
  jacobian->availability = JACOBIAN_AVAILABLE;
  
  /* read lead index of compressed sparse column */
  count = omc_fread(jacobian->sparsePattern->leadindex, sizeof(unsigned int), 1+1, pFile, FALSE);
  if (count != 1+1) {
    throwStreamPrint(threadData, "Error while reading lead index list of sparsity pattern. Expected %d, got %ld", 1+1, count);
  }
  
  /* read sparse index */
  count = omc_fread(jacobian->sparsePattern->index, sizeof(unsigned int), 1, pFile, FALSE);
  if (count != 1) {
    throwStreamPrint(threadData, "Error while reading row index list of sparsity pattern. Expected %d, got %ld", 1+1, count);
  }
  
  /* write color array */
  /* color 1 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 1, 1);
  
  omc_fclose(pFile);
  
  TRACE_POP
  return 0;
}
OMC_DISABLE_OPT
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianLSJac187(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  size_t count;

  FILE* pFile = openSparsePatternFile(data, threadData, "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_JacLSJac187.bin");
  
  initAnalyticJacobian(jacobian, 1, 1, 19, NULL, jacobian->sparsePattern);
  jacobian->sparsePattern = allocSparsePattern(1, 1, 1);
  jacobian->availability = JACOBIAN_AVAILABLE;
  
  /* read lead index of compressed sparse column */
  count = omc_fread(jacobian->sparsePattern->leadindex, sizeof(unsigned int), 1+1, pFile, FALSE);
  if (count != 1+1) {
    throwStreamPrint(threadData, "Error while reading lead index list of sparsity pattern. Expected %d, got %ld", 1+1, count);
  }
  
  /* read sparse index */
  count = omc_fread(jacobian->sparsePattern->index, sizeof(unsigned int), 1, pFile, FALSE);
  if (count != 1) {
    throwStreamPrint(threadData, "Error while reading row index list of sparsity pattern. Expected %d, got %ld", 1+1, count);
  }
  
  /* write color array */
  /* color 1 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 1, 1);
  
  omc_fclose(pFile);
  
  TRACE_POP
  return 0;
}
OMC_DISABLE_OPT
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianNLSJac188(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  size_t count;

  FILE* pFile = openSparsePatternFile(data, threadData, "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_JacNLSJac188.bin");
  
  initAnalyticJacobian(jacobian, 1, 1, 19, NULL, jacobian->sparsePattern);
  jacobian->sparsePattern = allocSparsePattern(1, 1, 1);
  jacobian->availability = JACOBIAN_AVAILABLE;
  
  /* read lead index of compressed sparse column */
  count = omc_fread(jacobian->sparsePattern->leadindex, sizeof(unsigned int), 1+1, pFile, FALSE);
  if (count != 1+1) {
    throwStreamPrint(threadData, "Error while reading lead index list of sparsity pattern. Expected %d, got %ld", 1+1, count);
  }
  
  /* read sparse index */
  count = omc_fread(jacobian->sparsePattern->index, sizeof(unsigned int), 1, pFile, FALSE);
  if (count != 1) {
    throwStreamPrint(threadData, "Error while reading row index list of sparsity pattern. Expected %d, got %ld", 1+1, count);
  }
  
  /* write color array */
  /* color 1 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 1, 1);
  
  omc_fclose(pFile);
  
  TRACE_POP
  return 0;
}
OMC_DISABLE_OPT
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianLSJac189(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  size_t count;

  FILE* pFile = openSparsePatternFile(data, threadData, "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_JacLSJac189.bin");
  
  initAnalyticJacobian(jacobian, 1, 1, 19, NULL, jacobian->sparsePattern);
  jacobian->sparsePattern = allocSparsePattern(1, 1, 1);
  jacobian->availability = JACOBIAN_AVAILABLE;
  
  /* read lead index of compressed sparse column */
  count = omc_fread(jacobian->sparsePattern->leadindex, sizeof(unsigned int), 1+1, pFile, FALSE);
  if (count != 1+1) {
    throwStreamPrint(threadData, "Error while reading lead index list of sparsity pattern. Expected %d, got %ld", 1+1, count);
  }
  
  /* read sparse index */
  count = omc_fread(jacobian->sparsePattern->index, sizeof(unsigned int), 1, pFile, FALSE);
  if (count != 1) {
    throwStreamPrint(threadData, "Error while reading row index list of sparsity pattern. Expected %d, got %ld", 1+1, count);
  }
  
  /* write color array */
  /* color 1 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 1, 1);
  
  omc_fclose(pFile);
  
  TRACE_POP
  return 0;
}
OMC_DISABLE_OPT
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianNLSJac190(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  size_t count;

  FILE* pFile = openSparsePatternFile(data, threadData, "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_JacNLSJac190.bin");
  
  initAnalyticJacobian(jacobian, 1, 1, 19, NULL, jacobian->sparsePattern);
  jacobian->sparsePattern = allocSparsePattern(1, 1, 1);
  jacobian->availability = JACOBIAN_AVAILABLE;
  
  /* read lead index of compressed sparse column */
  count = omc_fread(jacobian->sparsePattern->leadindex, sizeof(unsigned int), 1+1, pFile, FALSE);
  if (count != 1+1) {
    throwStreamPrint(threadData, "Error while reading lead index list of sparsity pattern. Expected %d, got %ld", 1+1, count);
  }
  
  /* read sparse index */
  count = omc_fread(jacobian->sparsePattern->index, sizeof(unsigned int), 1, pFile, FALSE);
  if (count != 1) {
    throwStreamPrint(threadData, "Error while reading row index list of sparsity pattern. Expected %d, got %ld", 1+1, count);
  }
  
  /* write color array */
  /* color 1 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 1, 1);
  
  omc_fclose(pFile);
  
  TRACE_POP
  return 0;
}
OMC_DISABLE_OPT
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianLSJac191(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  size_t count;

  FILE* pFile = openSparsePatternFile(data, threadData, "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_JacLSJac191.bin");
  
  initAnalyticJacobian(jacobian, 1, 1, 19, NULL, jacobian->sparsePattern);
  jacobian->sparsePattern = allocSparsePattern(1, 1, 1);
  jacobian->availability = JACOBIAN_AVAILABLE;
  
  /* read lead index of compressed sparse column */
  count = omc_fread(jacobian->sparsePattern->leadindex, sizeof(unsigned int), 1+1, pFile, FALSE);
  if (count != 1+1) {
    throwStreamPrint(threadData, "Error while reading lead index list of sparsity pattern. Expected %d, got %ld", 1+1, count);
  }
  
  /* read sparse index */
  count = omc_fread(jacobian->sparsePattern->index, sizeof(unsigned int), 1, pFile, FALSE);
  if (count != 1) {
    throwStreamPrint(threadData, "Error while reading row index list of sparsity pattern. Expected %d, got %ld", 1+1, count);
  }
  
  /* write color array */
  /* color 1 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 1, 1);
  
  omc_fclose(pFile);
  
  TRACE_POP
  return 0;
}
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianH(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  TRACE_POP
  jacobian->availability = JACOBIAN_NOT_AVAILABLE;
  return 1;
}
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianF(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  TRACE_POP
  jacobian->availability = JACOBIAN_NOT_AVAILABLE;
  return 1;
}
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianD(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  TRACE_POP
  jacobian->availability = JACOBIAN_NOT_AVAILABLE;
  return 1;
}
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianC(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  TRACE_POP
  jacobian->availability = JACOBIAN_NOT_AVAILABLE;
  return 1;
}
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianB(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  TRACE_POP
  jacobian->availability = JACOBIAN_NOT_AVAILABLE;
  return 1;
}
OMC_DISABLE_OPT
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianA(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian)
{
  TRACE_PUSH
  size_t count;

  FILE* pFile = openSparsePatternFile(data, threadData, "TestPackage_ActiveWork_WaterModel_HydroPowerModel1_JacA.bin");
  
  initAnalyticJacobian(jacobian, 5, 5, 0, NULL, jacobian->sparsePattern);
  jacobian->sparsePattern = allocSparsePattern(5, 10, 3);
  jacobian->availability = JACOBIAN_ONLY_SPARSITY;
  
  /* read lead index of compressed sparse column */
  count = omc_fread(jacobian->sparsePattern->leadindex, sizeof(unsigned int), 5+1, pFile, FALSE);
  if (count != 5+1) {
    throwStreamPrint(threadData, "Error while reading lead index list of sparsity pattern. Expected %d, got %ld", 5+1, count);
  }
  
  /* read sparse index */
  count = omc_fread(jacobian->sparsePattern->index, sizeof(unsigned int), 10, pFile, FALSE);
  if (count != 10) {
    throwStreamPrint(threadData, "Error while reading row index list of sparsity pattern. Expected %d, got %ld", 5+1, count);
  }
  
  /* write color array */
  /* color 1 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 1, 1);
  /* color 2 with 1 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 2, 1);
  /* color 3 with 3 columns */
  readSparsePatternColor(threadData, pFile, jacobian->sparsePattern->colorCols, 3, 3);
  
  omc_fclose(pFile);
  
  TRACE_POP
  return 0;
}



