/* Jacobians */
static const REAL_ATTRIBUTE dummyREAL_ATTRIBUTE = omc_dummyRealAttribute;

#if defined(__cplusplus)
extern "C" {
#endif

/* Jacobian Variables */
#define TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_NLSJac186 0
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacNLSJac186_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *thisJacobian, ANALYTIC_JACOBIAN *parentJacobian);
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianNLSJac186(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian);


#define TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_LSJac187 1
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacLSJac187_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *thisJacobian, ANALYTIC_JACOBIAN *parentJacobian);
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianLSJac187(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian);


#define TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_NLSJac188 2
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacNLSJac188_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *thisJacobian, ANALYTIC_JACOBIAN *parentJacobian);
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianNLSJac188(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian);


#define TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_LSJac189 3
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacLSJac189_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *thisJacobian, ANALYTIC_JACOBIAN *parentJacobian);
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianLSJac189(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian);


#define TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_NLSJac190 4
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacNLSJac190_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *thisJacobian, ANALYTIC_JACOBIAN *parentJacobian);
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianNLSJac190(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian);


#define TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_LSJac191 5
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacLSJac191_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *thisJacobian, ANALYTIC_JACOBIAN *parentJacobian);
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianLSJac191(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian);


#define TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_H 6
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacH_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *thisJacobian, ANALYTIC_JACOBIAN *parentJacobian);
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianH(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian);


#define TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_F 7
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacF_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *thisJacobian, ANALYTIC_JACOBIAN *parentJacobian);
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianF(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian);


#define TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_D 8
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacD_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *thisJacobian, ANALYTIC_JACOBIAN *parentJacobian);
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianD(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian);


#define TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_C 9
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacC_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *thisJacobian, ANALYTIC_JACOBIAN *parentJacobian);
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianC(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian);


#define TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_B 10
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacB_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *thisJacobian, ANALYTIC_JACOBIAN *parentJacobian);
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianB(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian);


#define TestPackage_ActiveWork_WaterModel_HydroPowerModel1_INDEX_JAC_A 11
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_functionJacA_column(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *thisJacobian, ANALYTIC_JACOBIAN *parentJacobian);
int TestPackage_ActiveWork_WaterModel_HydroPowerModel1_initialAnalyticJacobianA(DATA* data, threadData_t *threadData, ANALYTIC_JACOBIAN *jacobian);

#if defined(__cplusplus)
}
#endif

