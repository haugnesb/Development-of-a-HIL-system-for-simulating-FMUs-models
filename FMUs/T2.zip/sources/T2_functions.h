#ifndef T2__H
#define T2__H
#include "meta/meta_modelica.h"
#include "util/modelica.h"
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#include "simulation/simulation_runtime.h"
#ifdef __cplusplus
extern "C" {
#endif


DLLExport
real_array omc_Modelica_Math_Matrices_inv(threadData_t *threadData, real_array _A);
DLLExport
modelica_metatype boxptr_Modelica_Math_Matrices_inv(threadData_t *threadData, modelica_metatype _A);
static const MMC_DEFSTRUCTLIT(boxvar_lit_Modelica_Math_Matrices_inv,2,0) {(void*) boxptr_Modelica_Math_Matrices_inv,0}};
#define boxvar_Modelica_Math_Matrices_inv MMC_REFSTRUCTLIT(boxvar_lit_Modelica_Math_Matrices_inv)


DLLExport
real_array omc_Modelica_Math_Matrices_LAPACK_dgetrf(threadData_t *threadData, real_array _A, integer_array *out_pivots, modelica_integer *out_info);
DLLExport
modelica_metatype boxptr_Modelica_Math_Matrices_LAPACK_dgetrf(threadData_t *threadData, modelica_metatype _A, modelica_metatype *out_pivots, modelica_metatype *out_info);
static const MMC_DEFSTRUCTLIT(boxvar_lit_Modelica_Math_Matrices_LAPACK_dgetrf,2,0) {(void*) boxptr_Modelica_Math_Matrices_LAPACK_dgetrf,0}};
#define boxvar_Modelica_Math_Matrices_LAPACK_dgetrf MMC_REFSTRUCTLIT(boxvar_lit_Modelica_Math_Matrices_LAPACK_dgetrf)

extern void dgetrf_(int* /*_m*/, int* /*_n*/, double* /*_LU*/, int* /*_lda*/, int* /*_pivots*/, int* /*_info*/);

DLLExport
real_array omc_Modelica_Math_Matrices_LAPACK_dgetri(threadData_t *threadData, real_array _LU, integer_array _pivots, modelica_integer *out_info);
DLLExport
modelica_metatype boxptr_Modelica_Math_Matrices_LAPACK_dgetri(threadData_t *threadData, modelica_metatype _LU, modelica_metatype _pivots, modelica_metatype *out_info);
static const MMC_DEFSTRUCTLIT(boxvar_lit_Modelica_Math_Matrices_LAPACK_dgetri,2,0) {(void*) boxptr_Modelica_Math_Matrices_LAPACK_dgetri,0}};
#define boxvar_Modelica_Math_Matrices_LAPACK_dgetri MMC_REFSTRUCTLIT(boxvar_lit_Modelica_Math_Matrices_LAPACK_dgetri)

extern void dgetri_(int* /*_n*/, double* /*_inv*/, int* /*_lda*/, int* /*_pivots*/, double* /*_work*/, int* /*_lwork*/, int* /*_info*/);

DLLExport
modelica_real omc_OpenHPL_Functions_DarcyFriction_Friction(threadData_t *threadData, modelica_real _v, modelica_real _D, modelica_real _L, modelica_real _rho, modelica_real _mu, modelica_real _p_eps);
DLLExport
modelica_metatype boxptr_OpenHPL_Functions_DarcyFriction_Friction(threadData_t *threadData, modelica_metatype _v, modelica_metatype _D, modelica_metatype _L, modelica_metatype _rho, modelica_metatype _mu, modelica_metatype _p_eps);
static const MMC_DEFSTRUCTLIT(boxvar_lit_OpenHPL_Functions_DarcyFriction_Friction,2,0) {(void*) boxptr_OpenHPL_Functions_DarcyFriction_Friction,0}};
#define boxvar_OpenHPL_Functions_DarcyFriction_Friction MMC_REFSTRUCTLIT(boxvar_lit_OpenHPL_Functions_DarcyFriction_Friction)


DLLExport
modelica_real omc_OpenHPL_Functions_DarcyFriction_fDarcy(threadData_t *threadData, modelica_real _N_Re, modelica_real _D, modelica_real _p_eps);
DLLExport
modelica_metatype boxptr_OpenHPL_Functions_DarcyFriction_fDarcy(threadData_t *threadData, modelica_metatype _N_Re, modelica_metatype _D, modelica_metatype _p_eps);
static const MMC_DEFSTRUCTLIT(boxvar_lit_OpenHPL_Functions_DarcyFriction_fDarcy,2,0) {(void*) boxptr_OpenHPL_Functions_DarcyFriction_fDarcy,0}};
#define boxvar_OpenHPL_Functions_DarcyFriction_fDarcy MMC_REFSTRUCTLIT(boxvar_lit_OpenHPL_Functions_DarcyFriction_fDarcy)
#include "T2_model.h"


#ifdef __cplusplus
}
#endif
#endif

