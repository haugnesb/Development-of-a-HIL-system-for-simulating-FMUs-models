/* update bound parameters and variable attributes (start, nominal, min, max) */
#include "T2_model.h"
#if defined(__cplusplus)
extern "C" {
#endif


/*
equation index: 45
type: SIMPLE_ASSIGN
$START.intake.Vdot = intake.Vdot_0
*/
OMC_DISABLE_OPT
static void T2_eqFunction_45(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,45};
  (data->modelData->realVarsData[7]/* intake.Vdot variable */).attribute .start = (data->simulationInfo->realParameter[20]/* intake.Vdot_0 PARAM */) ;
    (data->localData[0]->realVars[7]/* intake.Vdot variable */)  = (data->modelData->realVarsData[7]/* intake.Vdot variable */).attribute .start;
    infoStreamPrint(LOG_INIT_V, 0, "updated start value: %s(start=%g)", data->modelData->realVarsData[7].info /* intake.Vdot */.name, (modelica_real) (data->localData[0]->realVars[7]/* intake.Vdot variable */) );
  TRACE_POP
}
OMC_DISABLE_OPT
int T2_updateBoundVariableAttributes(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  /* min ******************************************************** */
  
  infoStreamPrint(LOG_INIT, 1, "updating min-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* max ******************************************************** */
  
  infoStreamPrint(LOG_INIT, 1, "updating max-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* nominal **************************************************** */
  
  infoStreamPrint(LOG_INIT, 1, "updating nominal-values");
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  /* start ****************************************************** */
  infoStreamPrint(LOG_INIT, 1, "updating primary start-values");
  T2_eqFunction_45(data, threadData);
  if (ACTIVE_STREAM(LOG_INIT)) messageClose(LOG_INIT);
  
  TRACE_POP
  return 0;
}

void T2_updateBoundParameters_0(DATA *data, threadData_t *threadData);

/*
equation index: 46
type: SIMPLE_ASSIGN
$cse1 = tan(reservoir.alpha)
*/
OMC_DISABLE_OPT
static void T2_eqFunction_46(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,46};
  (data->simulationInfo->realParameter[0]/* $cse1 PARAM */)  = tan((data->simulationInfo->realParameter[24]/* reservoir.alpha PARAM */) );
  TRACE_POP
}

/*
equation index: 47
type: SIMPLE_ASSIGN
tail.h = constant1.k
*/
OMC_DISABLE_OPT
static void T2_eqFunction_47(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,47};
  (data->simulationInfo->realParameter[31]/* tail.h PARAM */)  = (data->simulationInfo->realParameter[1]/* constant1.k PARAM */) ;
  TRACE_POP
}

/*
equation index: 48
type: SIMPLE_ASSIGN
tail.level = constant1.k
*/
OMC_DISABLE_OPT
static void T2_eqFunction_48(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,48};
  (data->simulationInfo->realParameter[33]/* tail.level PARAM */)  = (data->simulationInfo->realParameter[1]/* constant1.k PARAM */) ;
  TRACE_POP
}

/*
equation index: 49
type: SIMPLE_ASSIGN
constant1.y = constant1.k
*/
OMC_DISABLE_OPT
static void T2_eqFunction_49(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,49};
  (data->simulationInfo->realParameter[2]/* constant1.y PARAM */)  = (data->simulationInfo->realParameter[1]/* constant1.k PARAM */) ;
  TRACE_POP
}

/*
equation index: 52
type: SIMPLE_ASSIGN
intake.Vdot_0 = data.Vdot_0
*/
OMC_DISABLE_OPT
static void T2_eqFunction_52(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,52};
  (data->simulationInfo->realParameter[20]/* intake.Vdot_0 PARAM */)  = (data->simulationInfo->realParameter[5]/* data.Vdot_0 PARAM */) ;
  TRACE_POP
}

/*
equation index: 54
type: SIMPLE_ASSIGN
intake.p_eps = data.p_eps
*/
OMC_DISABLE_OPT
static void T2_eqFunction_54(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,54};
  (data->simulationInfo->realParameter[21]/* intake.p_eps PARAM */)  = (data->simulationInfo->realParameter[14]/* data.p_eps PARAM */) ;
  TRACE_POP
}

/*
equation index: 55
type: SIMPLE_ASSIGN
intake.D_o = intake.D_i
*/
OMC_DISABLE_OPT
static void T2_eqFunction_55(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,55};
  (data->simulationInfo->realParameter[17]/* intake.D_o PARAM */)  = (data->simulationInfo->realParameter[16]/* intake.D_i PARAM */) ;
  TRACE_POP
}

/*
equation index: 59
type: SIMPLE_ASSIGN
data.beta_total = 1e-06 / data.rho
*/
OMC_DISABLE_OPT
static void T2_eqFunction_59(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,59};
  (data->simulationInfo->realParameter[7]/* data.beta_total PARAM */)  = DIVISION_SIM(1e-06,(data->simulationInfo->realParameter[15]/* data.rho PARAM */) ,"data.rho",equationIndexes);
  TRACE_POP
}
extern void T2_eqFunction_9(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_8(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_7(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_4(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_27(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_26(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_25(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_20(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_24(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_3(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_5(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_23(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_22(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_21(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_6(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_2(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_1(DATA *data, threadData_t *threadData);


/*
equation index: 77
type: ALGORITHM

  assert(tail.h >= 0.0, "Variable violating min constraint: 0.0 <= tail.h, has value: " + String(tail.h, "g"));
*/
OMC_DISABLE_OPT
static void T2_eqFunction_77(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,77};
  modelica_boolean tmp0;
  static const MMC_DEFSTRINGLIT(tmp1,61,"Variable violating min constraint: 0.0 <= tail.h, has value: ");
  modelica_string tmp2;
  modelica_metatype tmpMeta3;
  static int tmp4 = 0;
  if(!tmp4)
  {
    tmp0 = GreaterEq((data->simulationInfo->realParameter[31]/* tail.h PARAM */) ,0.0);
    if(!tmp0)
    {
      tmp2 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[31]/* tail.h PARAM */) , (modelica_string) mmc_strings_len1[103]);
      tmpMeta3 = stringAppend(MMC_REFSTRINGLIT(tmp1),tmp2);
      {
        if (data->simulationInfo->noThrowAsserts) {
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, 0, equationIndexes, "The following assertion has been violated %sat time %f\ntail.h >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          infoStreamPrint(LOG_ASSERT, 0, "%s", MMC_STRINGDATA(tmpMeta3));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Reservoir.mo",36,3,36,28,0};
          omc_assert_warning(info, "The following assertion has been violated %sat time %f\ntail.h >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta3));
        }
      }
      tmp4 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 78
type: ALGORITHM

  assert(tail.h_0 >= 0.0, "Variable violating min constraint: 0.0 <= tail.h_0, has value: " + String(tail.h_0, "g"));
*/
OMC_DISABLE_OPT
static void T2_eqFunction_78(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,78};
  modelica_boolean tmp5;
  static const MMC_DEFSTRINGLIT(tmp6,63,"Variable violating min constraint: 0.0 <= tail.h_0, has value: ");
  modelica_string tmp7;
  modelica_metatype tmpMeta8;
  static int tmp9 = 0;
  if(!tmp9)
  {
    tmp5 = GreaterEq((data->simulationInfo->realParameter[32]/* tail.h_0 PARAM */) ,0.0);
    if(!tmp5)
    {
      tmp7 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[32]/* tail.h_0 PARAM */) , (modelica_string) mmc_strings_len1[103]);
      tmpMeta8 = stringAppend(MMC_REFSTRINGLIT(tmp6),tmp7);
      {
        if (data->simulationInfo->noThrowAsserts) {
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, 0, equationIndexes, "The following assertion has been violated %sat time %f\ntail.h_0 >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          infoStreamPrint(LOG_ASSERT, 0, "%s", MMC_STRINGDATA(tmpMeta8));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Reservoir.mo",12,3,13,60,0};
          omc_assert_warning(info, "The following assertion has been violated %sat time %f\ntail.h_0 >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta8));
        }
      }
      tmp9 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 79
type: ALGORITHM

  assert(data.p_eps >= 0.0, "Variable violating min constraint: 0.0 <= data.p_eps, has value: " + String(data.p_eps, "g"));
*/
OMC_DISABLE_OPT
static void T2_eqFunction_79(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,79};
  modelica_boolean tmp10;
  static const MMC_DEFSTRINGLIT(tmp11,65,"Variable violating min constraint: 0.0 <= data.p_eps, has value: ");
  modelica_string tmp12;
  modelica_metatype tmpMeta13;
  static int tmp14 = 0;
  if(!tmp14)
  {
    tmp10 = GreaterEq((data->simulationInfo->realParameter[14]/* data.p_eps PARAM */) ,0.0);
    if(!tmp10)
    {
      tmp12 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[14]/* data.p_eps PARAM */) , (modelica_string) mmc_strings_len1[103]);
      tmpMeta13 = stringAppend(MMC_REFSTRINGLIT(tmp11),tmp12);
      {
        if (data->simulationInfo->noThrowAsserts) {
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, 0, equationIndexes, "The following assertion has been violated %sat time %f\ndata.p_eps >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          infoStreamPrint(LOG_ASSERT, 0, "%s", MMC_STRINGDATA(tmpMeta13));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Data.mo",16,3,17,55,0};
          omc_assert_warning(info, "The following assertion has been violated %sat time %f\ndata.p_eps >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta13));
        }
      }
      tmp14 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 80
type: ALGORITHM

  assert(intake.p_eps >= 0.0, "Variable violating min constraint: 0.0 <= intake.p_eps, has value: " + String(intake.p_eps, "g"));
*/
OMC_DISABLE_OPT
static void T2_eqFunction_80(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,80};
  modelica_boolean tmp15;
  static const MMC_DEFSTRINGLIT(tmp16,67,"Variable violating min constraint: 0.0 <= intake.p_eps, has value: ");
  modelica_string tmp17;
  modelica_metatype tmpMeta18;
  static int tmp19 = 0;
  if(!tmp19)
  {
    tmp15 = GreaterEq((data->simulationInfo->realParameter[21]/* intake.p_eps PARAM */) ,0.0);
    if(!tmp15)
    {
      tmp17 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[21]/* intake.p_eps PARAM */) , (modelica_string) mmc_strings_len1[103]);
      tmpMeta18 = stringAppend(MMC_REFSTRINGLIT(tmp16),tmp17);
      {
        if (data->simulationInfo->noThrowAsserts) {
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, 0, equationIndexes, "The following assertion has been violated %sat time %f\nintake.p_eps >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          infoStreamPrint(LOG_ASSERT, 0, "%s", MMC_STRINGDATA(tmpMeta18));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",15,3,16,32,0};
          omc_assert_warning(info, "The following assertion has been violated %sat time %f\nintake.p_eps >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta18));
        }
      }
      tmp19 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 81
type: ALGORITHM

  assert(intake.D_i >= 0.0, "Variable violating min constraint: 0.0 <= intake.D_i, has value: " + String(intake.D_i, "g"));
*/
OMC_DISABLE_OPT
static void T2_eqFunction_81(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,81};
  modelica_boolean tmp20;
  static const MMC_DEFSTRINGLIT(tmp21,65,"Variable violating min constraint: 0.0 <= intake.D_i, has value: ");
  modelica_string tmp22;
  modelica_metatype tmpMeta23;
  static int tmp24 = 0;
  if(!tmp24)
  {
    tmp20 = GreaterEq((data->simulationInfo->realParameter[16]/* intake.D_i PARAM */) ,0.0);
    if(!tmp20)
    {
      tmp22 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[16]/* intake.D_i PARAM */) , (modelica_string) mmc_strings_len1[103]);
      tmpMeta23 = stringAppend(MMC_REFSTRINGLIT(tmp21),tmp22);
      {
        if (data->simulationInfo->noThrowAsserts) {
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, 0, equationIndexes, "The following assertion has been violated %sat time %f\nintake.D_i >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          infoStreamPrint(LOG_ASSERT, 0, "%s", MMC_STRINGDATA(tmpMeta23));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",11,3,12,32,0};
          omc_assert_warning(info, "The following assertion has been violated %sat time %f\nintake.D_i >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta23));
        }
      }
      tmp24 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 82
type: ALGORITHM

  assert(intake.D_o >= 0.0, "Variable violating min constraint: 0.0 <= intake.D_o, has value: " + String(intake.D_o, "g"));
*/
OMC_DISABLE_OPT
static void T2_eqFunction_82(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,82};
  modelica_boolean tmp25;
  static const MMC_DEFSTRINGLIT(tmp26,65,"Variable violating min constraint: 0.0 <= intake.D_o, has value: ");
  modelica_string tmp27;
  modelica_metatype tmpMeta28;
  static int tmp29 = 0;
  if(!tmp29)
  {
    tmp25 = GreaterEq((data->simulationInfo->realParameter[17]/* intake.D_o PARAM */) ,0.0);
    if(!tmp25)
    {
      tmp27 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[17]/* intake.D_o PARAM */) , (modelica_string) mmc_strings_len1[103]);
      tmpMeta28 = stringAppend(MMC_REFSTRINGLIT(tmp26),tmp27);
      {
        if (data->simulationInfo->noThrowAsserts) {
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, 0, equationIndexes, "The following assertion has been violated %sat time %f\nintake.D_o >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          infoStreamPrint(LOG_ASSERT, 0, "%s", MMC_STRINGDATA(tmpMeta28));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Pipe.mo",13,3,14,32,0};
          omc_assert_warning(info, "The following assertion has been violated %sat time %f\nintake.D_o >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta28));
        }
      }
      tmp29 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 83
type: ALGORITHM

  assert(reservoir.h_0 >= 0.0, "Variable violating min constraint: 0.0 <= reservoir.h_0, has value: " + String(reservoir.h_0, "g"));
*/
OMC_DISABLE_OPT
static void T2_eqFunction_83(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,83};
  modelica_boolean tmp30;
  static const MMC_DEFSTRINGLIT(tmp31,68,"Variable violating min constraint: 0.0 <= reservoir.h_0, has value: ");
  modelica_string tmp32;
  modelica_metatype tmpMeta33;
  static int tmp34 = 0;
  if(!tmp34)
  {
    tmp30 = GreaterEq((data->simulationInfo->realParameter[26]/* reservoir.h_0 PARAM */) ,0.0);
    if(!tmp30)
    {
      tmp32 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[26]/* reservoir.h_0 PARAM */) , (modelica_string) mmc_strings_len1[103]);
      tmpMeta33 = stringAppend(MMC_REFSTRINGLIT(tmp31),tmp32);
      {
        if (data->simulationInfo->noThrowAsserts) {
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, 0, equationIndexes, "The following assertion has been violated %sat time %f\nreservoir.h_0 >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          infoStreamPrint(LOG_ASSERT, 0, "%s", MMC_STRINGDATA(tmpMeta33));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Reservoir.mo",12,3,13,60,0};
          omc_assert_warning(info, "The following assertion has been violated %sat time %f\nreservoir.h_0 >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta33));
        }
      }
      tmp34 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 84
type: ALGORITHM

  assert(data.T_0 >= 0.0, "Variable violating min constraint: 0.0 <= data.T_0, has value: " + String(data.T_0, "g"));
*/
OMC_DISABLE_OPT
static void T2_eqFunction_84(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,84};
  modelica_boolean tmp35;
  static const MMC_DEFSTRINGLIT(tmp36,63,"Variable violating min constraint: 0.0 <= data.T_0, has value: ");
  modelica_string tmp37;
  modelica_metatype tmpMeta38;
  static int tmp39 = 0;
  if(!tmp39)
  {
    tmp35 = GreaterEq((data->simulationInfo->realParameter[4]/* data.T_0 PARAM */) ,0.0);
    if(!tmp35)
    {
      tmp37 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[4]/* data.T_0 PARAM */) , (modelica_string) mmc_strings_len1[103]);
      tmpMeta38 = stringAppend(MMC_REFSTRINGLIT(tmp36),tmp37);
      {
        if (data->simulationInfo->noThrowAsserts) {
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, 0, equationIndexes, "The following assertion has been violated %sat time %f\ndata.T_0 >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          infoStreamPrint(LOG_ASSERT, 0, "%s", MMC_STRINGDATA(tmpMeta38));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Data.mo",31,3,32,93,0};
          omc_assert_warning(info, "The following assertion has been violated %sat time %f\ndata.T_0 >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta38));
        }
      }
      tmp39 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 85
type: ALGORITHM

  assert(data.rho >= 0.0, "Variable violating min constraint: 0.0 <= data.rho, has value: " + String(data.rho, "g"));
*/
OMC_DISABLE_OPT
static void T2_eqFunction_85(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,85};
  modelica_boolean tmp40;
  static const MMC_DEFSTRINGLIT(tmp41,63,"Variable violating min constraint: 0.0 <= data.rho, has value: ");
  modelica_string tmp42;
  modelica_metatype tmpMeta43;
  static int tmp44 = 0;
  if(!tmp44)
  {
    tmp40 = GreaterEq((data->simulationInfo->realParameter[15]/* data.rho PARAM */) ,0.0);
    if(!tmp40)
    {
      tmp42 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[15]/* data.rho PARAM */) , (modelica_string) mmc_strings_len1[103]);
      tmpMeta43 = stringAppend(MMC_REFSTRINGLIT(tmp41),tmp42);
      {
        if (data->simulationInfo->noThrowAsserts) {
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, 0, equationIndexes, "The following assertion has been violated %sat time %f\ndata.rho >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          infoStreamPrint(LOG_ASSERT, 0, "%s", MMC_STRINGDATA(tmpMeta43));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Data.mo",12,3,13,55,0};
          omc_assert_warning(info, "The following assertion has been violated %sat time %f\ndata.rho >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta43));
        }
      }
      tmp44 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 86
type: ALGORITHM

  assert(data.mu >= 0.0, "Variable violating min constraint: 0.0 <= data.mu, has value: " + String(data.mu, "g"));
*/
OMC_DISABLE_OPT
static void T2_eqFunction_86(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,86};
  modelica_boolean tmp45;
  static const MMC_DEFSTRINGLIT(tmp46,62,"Variable violating min constraint: 0.0 <= data.mu, has value: ");
  modelica_string tmp47;
  modelica_metatype tmpMeta48;
  static int tmp49 = 0;
  if(!tmp49)
  {
    tmp45 = GreaterEq((data->simulationInfo->realParameter[12]/* data.mu PARAM */) ,0.0);
    if(!tmp45)
    {
      tmp47 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[12]/* data.mu PARAM */) , (modelica_string) mmc_strings_len1[103]);
      tmpMeta48 = stringAppend(MMC_REFSTRINGLIT(tmp46),tmp47);
      {
        if (data->simulationInfo->noThrowAsserts) {
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, 0, equationIndexes, "The following assertion has been violated %sat time %f\ndata.mu >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          infoStreamPrint(LOG_ASSERT, 0, "%s", MMC_STRINGDATA(tmpMeta48));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Data.mo",14,3,15,55,0};
          omc_assert_warning(info, "The following assertion has been violated %sat time %f\ndata.mu >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta48));
        }
      }
      tmp49 = 1;
    }
  }
  TRACE_POP
}

/*
equation index: 87
type: ALGORITHM

  assert(data.M_a >= 0.0, "Variable violating min constraint: 0.0 <= data.M_a, has value: " + String(data.M_a, "g"));
*/
OMC_DISABLE_OPT
static void T2_eqFunction_87(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,87};
  modelica_boolean tmp50;
  static const MMC_DEFSTRINGLIT(tmp51,63,"Variable violating min constraint: 0.0 <= data.M_a, has value: ");
  modelica_string tmp52;
  modelica_metatype tmpMeta53;
  static int tmp54 = 0;
  if(!tmp54)
  {
    tmp50 = GreaterEq((data->simulationInfo->realParameter[3]/* data.M_a PARAM */) ,0.0);
    if(!tmp50)
    {
      tmp52 = modelica_real_to_modelica_string_format((data->simulationInfo->realParameter[3]/* data.M_a PARAM */) , (modelica_string) mmc_strings_len1[103]);
      tmpMeta53 = stringAppend(MMC_REFSTRINGLIT(tmp51),tmp52);
      {
        if (data->simulationInfo->noThrowAsserts) {
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, 0, equationIndexes, "The following assertion has been violated %sat time %f\ndata.M_a >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          infoStreamPrint(LOG_ASSERT, 0, "%s", MMC_STRINGDATA(tmpMeta53));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Data.mo",10,3,11,45,0};
          omc_assert_warning(info, "The following assertion has been violated %sat time %f\ndata.M_a >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta53));
        }
      }
      tmp54 = 1;
    }
  }
  TRACE_POP
}
OMC_DISABLE_OPT
void T2_updateBoundParameters_0(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  T2_eqFunction_46(data, threadData);
  T2_eqFunction_47(data, threadData);
  T2_eqFunction_48(data, threadData);
  T2_eqFunction_49(data, threadData);
  T2_eqFunction_52(data, threadData);
  T2_eqFunction_54(data, threadData);
  T2_eqFunction_55(data, threadData);
  T2_eqFunction_59(data, threadData);
  T2_eqFunction_9(data, threadData);
  T2_eqFunction_8(data, threadData);
  T2_eqFunction_7(data, threadData);
  T2_eqFunction_4(data, threadData);
  T2_eqFunction_27(data, threadData);
  T2_eqFunction_26(data, threadData);
  T2_eqFunction_25(data, threadData);
  T2_eqFunction_20(data, threadData);
  T2_eqFunction_24(data, threadData);
  T2_eqFunction_3(data, threadData);
  T2_eqFunction_5(data, threadData);
  T2_eqFunction_23(data, threadData);
  T2_eqFunction_22(data, threadData);
  T2_eqFunction_21(data, threadData);
  T2_eqFunction_6(data, threadData);
  T2_eqFunction_2(data, threadData);
  T2_eqFunction_1(data, threadData);
  T2_eqFunction_77(data, threadData);
  T2_eqFunction_78(data, threadData);
  T2_eqFunction_79(data, threadData);
  T2_eqFunction_80(data, threadData);
  T2_eqFunction_81(data, threadData);
  T2_eqFunction_82(data, threadData);
  T2_eqFunction_83(data, threadData);
  T2_eqFunction_84(data, threadData);
  T2_eqFunction_85(data, threadData);
  T2_eqFunction_86(data, threadData);
  T2_eqFunction_87(data, threadData);
  TRACE_POP
}
OMC_DISABLE_OPT
int T2_updateBoundParameters(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  (data->simulationInfo->booleanParameter[1]/* data.TempUse PARAM */)  = 0;
  data->modelData->booleanParameterData[1].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[2]/* intake.SteadyState PARAM */)  = 0;
  data->modelData->booleanParameterData[2].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[4]/* reservoir.useInflow PARAM */)  = 0;
  data->modelData->booleanParameterData[4].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[5]/* reservoir.useLevel PARAM */)  = 1;
  data->modelData->booleanParameterData[5].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[6]/* tail.useInflow PARAM */)  = 0;
  data->modelData->booleanParameterData[6].time_unvarying = 1;
  (data->simulationInfo->booleanParameter[7]/* tail.useLevel PARAM */)  = 1;
  data->modelData->booleanParameterData[7].time_unvarying = 1;
  T2_updateBoundParameters_0(data, threadData);
  TRACE_POP
  return 0;
}

#if defined(__cplusplus)
}
#endif

