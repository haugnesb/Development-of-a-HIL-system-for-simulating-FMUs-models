/* Mixed Systems */
#include "T2_model.h"
#include "T2_11mix.h"
/* initial mixed systems */
/* initial_lambda0 mixed systems */
/* parameter mixed systems */
/* model mixed systems */
/* jacobians mixed systems */


