/* Linearization */
#include "T2_model.h"
#if defined(__cplusplus)
extern "C" {
#endif
const char *T2_linear_model_frame()
{
  return "model linearized_model \"T2\" \n  parameter Integer n = 1 \"number of states\";\n  parameter Integer m = 1 \"number of inputs\";\n  parameter Integer p = 0 \"number of outputs\";\n"
  "  parameter Real x0[n] = %s;\n"
  "  parameter Real u0[m] = %s;\n"
  "\n"
  "  parameter Real A[n, n] =\n\t[%s];\n\n"
  "  parameter Real B[n, m] =\n\t[%s];\n\n"
  "  parameter Real C[p, n] = zeros(p, n);%s\n\n"
  "  parameter Real D[p, m] = zeros(p, m);%s\n\n"
  "\n"
  "  Real x[n](start=x0);\n"
  "  input Real u[m](start=u0);\n"
  "  output Real y[p];\n"
  "\n"
  "  Real 'x_intake.M' = x[1];\n"
  "  Real 'u_u' = u[1];\n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\nend linearized_model;\n";
}
const char *T2_linear_model_datarecovery_frame()
{
  return "model linearized_model \"T2\" \n parameter Integer n = 1 \"number of states\";\n  parameter Integer m = 1 \"number of inputs\";\n  parameter Integer p = 0 \"number of outputs\";\n  parameter Integer nz = 30 \"data recovery variables\";\n"
  "  parameter Real x0[1] = %s;\n"
  "  parameter Real u0[1] = %s;\n"
  "  parameter Real z0[30] = %s;\n"
  "\n"
  "  parameter Real A[n, n] =\n\t[%s];\n\n"
  "  parameter Real B[n, m] =\n\t[%s];\n\n"
  "  parameter Real C[p, n] = zeros(p, n);%s\n\n"
  "  parameter Real D[p, m] = zeros(p, m);%s\n\n"
  "  parameter Real Cz[nz, n] =\n\t[%s];\n\n"
  "  parameter Real Dz[nz, m] =\n\t[%s];\n\n"
  "\n"
  "  Real x[n](start=x0);\n"
  "  input Real u[m](start=u0);\n"
  "  output Real y[p];\n"
  "  output Real z[nz];\n"
  "\n"
  "  Real 'x_intake.M' = x[1];\n"
  "  Real 'u_u' = u[1];\n"
  "  Real 'z_intake.A_' = z[1];\n""  Real 'z_intake.A_i' = z[2];\n""  Real 'z_intake.A_o' = z[3];\n""  Real 'z_intake.D_' = z[4];\n""  Real 'z_intake.F_f' = z[5];\n""  Real 'z_intake.Vdot' = z[6];\n""  Real 'z_intake.cos_theta' = z[7];\n""  Real 'z_intake.dp' = z[8];\n""  Real 'z_intake.m' = z[9];\n""  Real 'z_intake.mdot' = z[10];\n""  Real 'z_intake.p_i' = z[11];\n""  Real 'z_intake.p_o' = z[12];\n""  Real 'z_intake.v' = z[13];\n""  Real 'z_reservoir.A' = z[14];\n""  Real 'z_reservoir.F_f' = z[15];\n""  Real 'z_reservoir.M' = z[16];\n""  Real 'z_reservoir.Vdot' = z[17];\n""  Real 'z_reservoir.Vdot_i' = z[18];\n""  Real 'z_reservoir.m' = z[19];\n""  Real 'z_reservoir.mdot' = z[20];\n""  Real 'z_reservoir.v' = z[21];\n""  Real 'z_tail.A' = z[22];\n""  Real 'z_tail.F_f' = z[23];\n""  Real 'z_tail.M' = z[24];\n""  Real 'z_tail.Vdot' = z[25];\n""  Real 'z_tail.Vdot_i' = z[26];\n""  Real 'z_tail.m' = z[27];\n""  Real 'z_tail.mdot' = z[28];\n""  Real 'z_tail.v' = z[29];\n""  Real 'z_u' = z[30];\n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\n  z = Cz * x + Dz * u;\nend linearized_model;\n";
}
#if defined(__cplusplus)
}
#endif

