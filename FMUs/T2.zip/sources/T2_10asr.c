/* Asserts */
#include "T2_model.h"
#if defined(__cplusplus)
extern "C" {
#endif


/*
equation index: 88
type: ALGORITHM

  assert(reservoir.m >= 0.0, "Variable violating min constraint: 0.0 <= reservoir.m, has value: " + String(reservoir.m, "g"));
*/
void T2_eqFunction_88(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,88};
  modelica_boolean tmp0;
  static const MMC_DEFSTRINGLIT(tmp1,66,"Variable violating min constraint: 0.0 <= reservoir.m, has value: ");
  modelica_string tmp2;
  modelica_metatype tmpMeta3;
  static int tmp4 = 0;
  if(!tmp4)
  {
    tmp0 = GreaterEq((data->localData[0]->realVars[20]/* reservoir.m variable */) ,0.0);
    if(!tmp0)
    {
      tmp2 = modelica_real_to_modelica_string_format((data->localData[0]->realVars[20]/* reservoir.m variable */) , (modelica_string) mmc_strings_len1[103]);
      tmpMeta3 = stringAppend(MMC_REFSTRINGLIT(tmp1),tmp2);
      {
        if (data->simulationInfo->noThrowAsserts) {
          infoStreamPrintWithEquationIndexes(LOG_ASSERT, 0, equationIndexes, "The following assertion has been violated %sat time %f\nreservoir.m >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          infoStreamPrint(LOG_ASSERT, 0, "%s", MMC_STRINGDATA(tmpMeta3));
        } else {
          FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1/Waterway/Reservoir.mo",28,3,28,25,0};
          omc_assert_warning(info, "The following assertion has been violated %sat time %f\nreservoir.m >= 0.0", initial() ? "during initialization " : "", data->localData[0]->timeValue);
          omc_assert_warning_withEquationIndexes(info, equationIndexes, MMC_STRINGDATA(tmpMeta3));
        }
      }
      tmp4 = 1;
    }
  }
  TRACE_POP
}
/* function to check assert after a step is done */
OMC_DISABLE_OPT
int T2_checkForAsserts(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  T2_eqFunction_88(data, threadData);
  
  TRACE_POP
  return 0;
}

#if defined(__cplusplus)
}
#endif

