/* DAE residuals is empty */
 #include "T2_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int T2_initializeDAEmodeData(DATA* data, DAEMODE_DATA* daeModeData){ return -1; }
#ifdef __cplusplus
}
#endif
