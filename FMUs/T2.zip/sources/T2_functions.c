#include "omc_simulation_settings.h"
#include "T2_functions.h"
#ifdef __cplusplus
extern "C" {
#endif

#include "T2_includes.h"


DLLExport
real_array omc_Modelica_Math_Matrices_inv(threadData_t *threadData, real_array _A)
{
  real_array _invA;
  modelica_integer tmp1;
  modelica_integer tmp2;
  modelica_integer _info;
  integer_array _pivots;
  modelica_integer tmp3;
  real_array _LU;
  modelica_integer tmp4;
  modelica_integer tmp5;
  static int tmp6 = 0;
  _tailrecursive: OMC_LABEL_UNUSED
  tmp1 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  tmp2 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  alloc_real_array(&(_invA), 2, (_index_t)tmp1, (_index_t)tmp2); // _invA has no default value.
  // _info has no default value.
  tmp3 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  alloc_integer_array(&(_pivots), 1, (_index_t)tmp3); // _pivots has no default value.
  tmp4 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  tmp5 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  alloc_real_array(&(_LU), 2, (_index_t)tmp4, (_index_t)tmp5); // _LU has no default value.
  real_array_copy_data(omc_Modelica_Math_Matrices_LAPACK_dgetrf(threadData, _A ,&_pivots ,&_info), _LU);

  {
    if(!(_info == ((modelica_integer) 0)))
    {
      {
        FILE_INFO info = {"C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om/Math/package.mo",2603,5,2604,64,0};
        omc_assert(threadData, info, MMC_STRINGDATA(_OMC_LIT0));
      }
    }
  }

  real_array_copy_data(omc_Modelica_Math_Matrices_LAPACK_dgetri(threadData, _LU, _pivots, NULL), _invA);
  _return: OMC_LABEL_UNUSED
  return _invA;
}
modelica_metatype boxptr_Modelica_Math_Matrices_inv(threadData_t *threadData, modelica_metatype _A)
{
  real_array _invA;
  modelica_integer tmp1;
  modelica_integer tmp2;
  modelica_metatype out_invA;
  _invA = omc_Modelica_Math_Matrices_inv(threadData, *((base_array_t*)_A));
  out_invA = mmc_mk_modelica_array(_invA);
  return out_invA;
}

real_array omc_Modelica_Math_Matrices_LAPACK_dgetrf(threadData_t *threadData, real_array _A, integer_array *out_pivots, modelica_integer *out_info)
{
  /* extFunCallF77: varDecs */
  real_array _LU_ext;
  integer_array _pivots_ext;
  int _info_ext = 0;
  /* extFunCallF77: biVarDecs */
  modelica_integer _m;
  modelica_integer _m_ext;
  modelica_integer tmp1;
  modelica_integer _n;
  modelica_integer _n_ext;
  modelica_integer tmp2;
  modelica_integer _lda;
  modelica_integer _lda_ext;
  modelica_integer tmp3;
  /* extFunCallF77: args */
  real_array _LU;
  modelica_integer tmp4;
  modelica_integer tmp5;
  integer_array _pivots;
  modelica_integer tmp6;
  modelica_integer tmp7;
  modelica_integer _info;
  tmp1 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  _m = tmp1;
  tmp2 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  _n = tmp2;
  tmp3 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  _lda = modelica_integer_max((modelica_integer)(((modelica_integer) 1)),(modelica_integer)(tmp3));
  tmp4 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  tmp5 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  alloc_real_array(&(_LU), 2, (_index_t)tmp4, (_index_t)tmp5);
  real_array_copy_data(_A, _LU);
  
  tmp6 = size_of_dimension_base_array(_A, ((modelica_integer) 1));
  tmp7 = size_of_dimension_base_array(_A, ((modelica_integer) 2));
  alloc_integer_array(&(_pivots), 1, (_index_t)modelica_integer_min((modelica_integer)(tmp6),(modelica_integer)(tmp7))); // _pivots has no default value.
  // _info has no default value.
  /* extFunCallF77: biVarDecs */
  /* extFunCallF77: args */
  /* extFunCallF77: end args */
  convert_alloc_real_array_to_f77(&_LU, &_LU_ext);
  convert_alloc_integer_array_to_f77(&_pivots, &_pivots_ext);
  /* extFunCallF77: extReturn */
  /* extFunCallF77: CALL */
  dgetrf_((int*) &_m, (int*) &_n, data_of_real_f77_array(_LU_ext), (int*) &_lda, data_of_integer_f77_array(_pivots_ext), (int*) &_info_ext);
  /* extFunCallF77: copy args */
  convert_alloc_real_array_from_f77(&_LU_ext, &_LU);
  convert_alloc_integer_array_from_f77(&_pivots_ext, &_pivots);
  _info = (modelica_integer)_info_ext;
  /* extFunCallF77: copy return */
  if (out_pivots) { if (out_pivots->dim_size == NULL) {copy_integer_array(_pivots, out_pivots);} else {integer_array_copy_data(_pivots, *out_pivots);} }
  if (out_info) { *out_info = _info; }
  return _LU;
}
modelica_metatype boxptr_Modelica_Math_Matrices_LAPACK_dgetrf(threadData_t *threadData, modelica_metatype _A, modelica_metatype *out_pivots, modelica_metatype *out_info)
{
  integer_array _pivots;
  modelica_integer tmp1;
  modelica_integer tmp2;
  modelica_integer _info;
  real_array _LU;
  modelica_integer tmp3;
  modelica_integer tmp4;
  modelica_metatype out_LU;
  _LU = omc_Modelica_Math_Matrices_LAPACK_dgetrf(threadData, *((base_array_t*)_A), &_pivots, &_info);
  out_LU = mmc_mk_modelica_array(_LU);
  if (out_pivots) { *out_pivots = mmc_mk_modelica_array(_pivots); }
  if (out_info) { *out_info = mmc_mk_icon(_info); }
  return out_LU;
}

real_array omc_Modelica_Math_Matrices_LAPACK_dgetri(threadData_t *threadData, real_array _LU, integer_array _pivots, modelica_integer *out_info)
{
  /* extFunCallF77: varDecs */
  real_array _inv_ext;
  integer_array _pivots_ext;
  int _info_ext = 0;
  /* extFunCallF77: biVarDecs */
  modelica_integer _n;
  modelica_integer _n_ext;
  modelica_integer tmp1;
  modelica_integer _lda;
  modelica_integer _lda_ext;
  modelica_integer tmp2;
  modelica_integer _lwork;
  modelica_integer _lwork_ext;
  modelica_integer tmp3;
  modelica_integer tmp4;
  real_array _work;
  real_array _work_ext;
  modelica_integer tmp5;
  modelica_integer tmp6;
  /* extFunCallF77: args */
  real_array _inv;
  modelica_integer tmp7;
  modelica_integer tmp8;
  modelica_integer _info;
  tmp1 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  _n = tmp1;
  tmp2 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  _lda = modelica_integer_max((modelica_integer)(((modelica_integer) 1)),(modelica_integer)(tmp2));
  tmp3 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  tmp4 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  _lwork = modelica_integer_max((modelica_integer)(((modelica_integer) 1)),(modelica_integer)((modelica_integer_min((modelica_integer)(((modelica_integer) 10)),(modelica_integer)(tmp3))) * (tmp4)));
  tmp5 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  tmp6 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  alloc_real_array(&_work, 1, (_index_t)modelica_integer_max((modelica_integer)(((modelica_integer) 1)),(modelica_integer)((modelica_integer_min((modelica_integer)(((modelica_integer) 10)),(modelica_integer)(tmp5))) * (tmp6))));
  convert_alloc_real_array_to_f77(&_work, &_work_ext);
  tmp7 = size_of_dimension_base_array(_LU, ((modelica_integer) 1));
  tmp8 = size_of_dimension_base_array(_LU, ((modelica_integer) 2));
  alloc_real_array(&(_inv), 2, (_index_t)tmp7, (_index_t)tmp8);
  real_array_copy_data(_LU, _inv);
  
  // _info has no default value.
  /* extFunCallF77: biVarDecs */
  /* extFunCallF77: args */
  /* extFunCallF77: end args */
  convert_alloc_real_array_to_f77(&_inv, &_inv_ext);
  convert_alloc_integer_array_to_f77(&_pivots, &_pivots_ext);
  /* extFunCallF77: extReturn */
  /* extFunCallF77: CALL */
  dgetri_((int*) &_n, data_of_real_f77_array(_inv_ext), (int*) &_lda, data_of_integer_f77_array(_pivots_ext), data_of_real_f77_array(_work_ext), (int*) &_lwork, (int*) &_info_ext);
  /* extFunCallF77: copy args */
  convert_alloc_real_array_from_f77(&_inv_ext, &_inv);
  _info = (modelica_integer)_info_ext;
  /* extFunCallF77: copy return */
  if (out_info) { *out_info = _info; }
  return _inv;
}
modelica_metatype boxptr_Modelica_Math_Matrices_LAPACK_dgetri(threadData_t *threadData, modelica_metatype _LU, modelica_metatype _pivots, modelica_metatype *out_info)
{
  modelica_integer _info;
  real_array _inv;
  modelica_integer tmp1;
  modelica_integer tmp2;
  modelica_metatype out_inv;
  _inv = omc_Modelica_Math_Matrices_LAPACK_dgetri(threadData, *((base_array_t*)_LU), *((base_array_t*)_pivots), &_info);
  out_inv = mmc_mk_modelica_array(_inv);
  if (out_info) { *out_info = mmc_mk_icon(_info); }
  return out_inv;
}

DLLExport
modelica_real omc_OpenHPL_Functions_DarcyFriction_Friction(threadData_t *threadData, modelica_real _v, modelica_real _D, modelica_real _L, modelica_real _rho, modelica_real _mu, modelica_real _p_eps)
{
  modelica_real _F_f;
  modelica_real _N_Re;
  modelica_real _f;
  modelica_real tmp1;
  modelica_real tmp2;
  _tailrecursive: OMC_LABEL_UNUSED
  // _F_f has no default value.
  // _N_Re has no default value.
  // _f has no default value.
  tmp1 = _mu;
  if (tmp1 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "rho * abs(v) * D / mu");}
  _N_Re = (((_rho) * (fabs(_v))) * (_D)) / tmp1;

  _f = omc_OpenHPL_Functions_DarcyFriction_fDarcy(threadData, _N_Re, _D, _p_eps);

  tmp2 = 4.0;
  if (tmp2 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "1.570796326794897 * f * rho * L * v * abs(v) * D / 4.0");}
  _F_f = (((((((1.570796326794897) * (_f)) * (_rho)) * (_L)) * (_v)) * (fabs(_v))) * (_D)) / tmp2;
  _return: OMC_LABEL_UNUSED
  return _F_f;
}
modelica_metatype boxptr_OpenHPL_Functions_DarcyFriction_Friction(threadData_t *threadData, modelica_metatype _v, modelica_metatype _D, modelica_metatype _L, modelica_metatype _rho, modelica_metatype _mu, modelica_metatype _p_eps)
{
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  modelica_real tmp5;
  modelica_real tmp6;
  modelica_real _F_f;
  modelica_metatype out_F_f;
  tmp1 = mmc_unbox_real(_v);
  tmp2 = mmc_unbox_real(_D);
  tmp3 = mmc_unbox_real(_L);
  tmp4 = mmc_unbox_real(_rho);
  tmp5 = mmc_unbox_real(_mu);
  tmp6 = mmc_unbox_real(_p_eps);
  _F_f = omc_OpenHPL_Functions_DarcyFriction_Friction(threadData, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6);
  out_F_f = mmc_mk_rcon(_F_f);
  return out_F_f;
}

DLLExport
modelica_real omc_OpenHPL_Functions_DarcyFriction_fDarcy(threadData_t *threadData, modelica_real _N_Re, modelica_real _D, modelica_real _p_eps)
{
  modelica_real _fD;
  modelica_real _arg;
  modelica_real _N_Re_lam;
  modelica_real _N_Re_tur;
  real_array _X;
  real_array _Y;
  real_array _K;
  real_array tmp1;
  real_array tmp2;
  modelica_real tmp3;
  modelica_real tmp4;
  real_array tmp5;
  modelica_real tmp6;
  modelica_real tmp7;
  real_array tmp8;
  modelica_real tmp9;
  real_array tmp10;
  modelica_real tmp11;
  real_array tmp12;
  modelica_real tmp13;
  modelica_real tmp14;
  modelica_real tmp15;
  modelica_real tmp16;
  modelica_real tmp17;
  modelica_real tmp18;
  modelica_real tmp19;
  modelica_real tmp20;
  modelica_real tmp21;
  modelica_real tmp22;
  modelica_real tmp23;
  modelica_real tmp24;
  modelica_real tmp25;
  modelica_real tmp26;
  modelica_real tmp27;
  modelica_real tmp28;
  modelica_real tmp29;
  modelica_real tmp30;
  modelica_real tmp31;
  modelica_real tmp32;
  modelica_real tmp33;
  modelica_real tmp34;
  modelica_real tmp35;
  modelica_real tmp36;
  modelica_real tmp37;
  modelica_real tmp38;
  modelica_real tmp39;
  modelica_real tmp40;
  modelica_real tmp41;
  modelica_real tmp42;
  modelica_real tmp43;
  modelica_real tmp44;
  modelica_real tmp45;
  modelica_real tmp46;
  modelica_real tmp47;
  modelica_real tmp48;
  modelica_real tmp49;
  modelica_real tmp50;
  modelica_real tmp51;
  modelica_real tmp52;
  _tailrecursive: OMC_LABEL_UNUSED
  // _fD has no default value.
  // _arg has no default value.
  _N_Re_lam = 2100.0;
  _N_Re_tur = 2300.0;
  alloc_real_array(&(_X), 2, (_index_t)4, (_index_t)4); // _X has no default value.
  alloc_real_array(&(_Y), 1, (_index_t)4); // _Y has no default value.
  alloc_real_array(&(_K), 1, (_index_t)4); // _K has no default value.
  tmp3 = _N_Re_lam;
  tmp4 = _N_Re_lam;
  array_alloc_scalar_real_array(&tmp2, 4, (modelica_real)(tmp3 * tmp3 * tmp3), (modelica_real)(tmp4 * tmp4), (modelica_real)_N_Re_lam, (modelica_real)1.0);
  tmp6 = _N_Re_tur;
  tmp7 = _N_Re_tur;
  array_alloc_scalar_real_array(&tmp5, 4, (modelica_real)(tmp6 * tmp6 * tmp6), (modelica_real)(tmp7 * tmp7), (modelica_real)_N_Re_tur, (modelica_real)1.0);
  tmp9 = _N_Re_lam;
  array_alloc_scalar_real_array(&tmp8, 4, (modelica_real)(3.0) * ((tmp9 * tmp9)), (modelica_real)(2.0) * (_N_Re_lam), (modelica_real)1.0, (modelica_real)0.0);
  tmp11 = _N_Re_tur;
  array_alloc_scalar_real_array(&tmp10, 4, (modelica_real)(3.0) * ((tmp11 * tmp11)), (modelica_real)(2.0) * (_N_Re_tur), (modelica_real)1.0, (modelica_real)0.0);
  array_alloc_real_array(&tmp1, 4, tmp2, tmp5, tmp8, tmp10);
  real_array_copy_data(tmp1, _X);

  tmp13 = _N_Re_lam;
  if (tmp13 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "64.0 / N_Re_lam");}
  tmp14 = 3.7;
  if (tmp14 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "p_eps / 3.7");}
  tmp15 = _D;
  if (tmp15 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "p_eps / 3.7 / D");}
  tmp16 = _N_Re_tur;
  tmp17 = 0.9;
  if(tmp16 < 0.0 && tmp17 != 0.0)
  {
    tmp19 = modf(tmp17, &tmp20);
    
    if(tmp19 > 0.5)
    {
      tmp19 -= 1.0;
      tmp20 += 1.0;
    }
    else if(tmp19 < -0.5)
    {
      tmp19 += 1.0;
      tmp20 -= 1.0;
    }
    
    if(fabs(tmp19) < 1e-10)
      tmp18 = pow(tmp16, tmp20);
    else
    {
      tmp22 = modf(1.0/tmp17, &tmp21);
      if(tmp22 > 0.5)
      {
        tmp22 -= 1.0;
        tmp21 += 1.0;
      }
      else if(tmp22 < -0.5)
      {
        tmp22 += 1.0;
        tmp21 -= 1.0;
      }
      if(fabs(tmp22) < 1e-10 && ((unsigned long)tmp21 & 1))
      {
        tmp18 = -pow(-tmp16, tmp19)*pow(tmp16, tmp20);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp16, tmp17);
      }
    }
  }
  else
  {
    tmp18 = pow(tmp16, tmp17);
  }
  if(isnan(tmp18) || isinf(tmp18))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp16, tmp17);
  }tmp23 = tmp18;
  if (tmp23 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "5.74 / N_Re_tur ^ 0.9");}
  tmp24 = ((_p_eps) / tmp14) / tmp15 + (5.74) / tmp23;
  if(!(tmp24 > 0.0))
  {
    FILE_INFO info = {"",0,0,0,0,0};
    omc_assert(threadData, info, "Model error: Argument of log10(p_eps / 3.7 / D + 5.74 / N_Re_tur ^ 0.9) was %g should be > 0", tmp24);
  }tmp25 = (2.0) * (log10(tmp24));
  tmp26 = (tmp25 * tmp25);
  if (tmp26 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "1.0 / (2.0 * log10(p_eps / 3.7 / D + 5.74 / N_Re_tur ^ 0.9)) ^ 2.0");}
  tmp27 = _N_Re_lam;
  tmp28 = (tmp27 * tmp27);
  if (tmp28 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "64.0 / N_Re_lam ^ 2.0");}
  tmp29 = _N_Re_tur;
  tmp30 = 1.25;
  if(tmp29 < 0.0 && tmp30 != 0.0)
  {
    tmp32 = modf(tmp30, &tmp33);
    
    if(tmp32 > 0.5)
    {
      tmp32 -= 1.0;
      tmp33 += 1.0;
    }
    else if(tmp32 < -0.5)
    {
      tmp32 += 1.0;
      tmp33 -= 1.0;
    }
    
    if(fabs(tmp32) < 1e-10)
      tmp31 = pow(tmp29, tmp33);
    else
    {
      tmp35 = modf(1.0/tmp30, &tmp34);
      if(tmp35 > 0.5)
      {
        tmp35 -= 1.0;
        tmp34 += 1.0;
      }
      else if(tmp35 < -0.5)
      {
        tmp35 += 1.0;
        tmp34 -= 1.0;
      }
      if(fabs(tmp35) < 1e-10 && ((unsigned long)tmp34 & 1))
      {
        tmp31 = -pow(-tmp29, tmp32)*pow(tmp29, tmp33);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp29, tmp30);
      }
    }
  }
  else
  {
    tmp31 = pow(tmp29, tmp30);
  }
  if(isnan(tmp31) || isinf(tmp31))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp29, tmp30);
  }tmp36 = tmp31;
  if (tmp36 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "0.079 / N_Re_tur ^ 1.25");}
  array_alloc_scalar_real_array(&tmp12, 4, (modelica_real)(64.0) / tmp13, (modelica_real)(1.0) / tmp26, (modelica_real)(-((64.0) / tmp28)), (modelica_real)(-((0.079) / tmp36)));
  real_array_copy_data(tmp12, _Y);

  real_array_copy_data(mul_alloc_real_matrix_product_smart(omc_Modelica_Math_Matrices_inv(threadData, _X), _Y), _K);

  tmp37 = 3.7;
  if (tmp37 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "p_eps / 3.7");}
  tmp38 = _D;
  if (tmp38 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "p_eps / 3.7 / D");}
  tmp39 = _N_Re + 1e-15;
  tmp40 = 0.9;
  if(tmp39 < 0.0 && tmp40 != 0.0)
  {
    tmp42 = modf(tmp40, &tmp43);
    
    if(tmp42 > 0.5)
    {
      tmp42 -= 1.0;
      tmp43 += 1.0;
    }
    else if(tmp42 < -0.5)
    {
      tmp42 += 1.0;
      tmp43 -= 1.0;
    }
    
    if(fabs(tmp42) < 1e-10)
      tmp41 = pow(tmp39, tmp43);
    else
    {
      tmp45 = modf(1.0/tmp40, &tmp44);
      if(tmp45 > 0.5)
      {
        tmp45 -= 1.0;
        tmp44 += 1.0;
      }
      else if(tmp45 < -0.5)
      {
        tmp45 += 1.0;
        tmp44 -= 1.0;
      }
      if(fabs(tmp45) < 1e-10 && ((unsigned long)tmp44 & 1))
      {
        tmp41 = -pow(-tmp39, tmp42)*pow(tmp39, tmp43);
      }
      else
      {
        throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp39, tmp40);
      }
    }
  }
  else
  {
    tmp41 = pow(tmp39, tmp40);
  }
  if(isnan(tmp41) || isinf(tmp41))
  {
    throwStreamPrint(threadData, "%s:%d: Invalid root: (%g)^(%g)", __FILE__, __LINE__, tmp39, tmp40);
  }tmp46 = tmp41;
  if (tmp46 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "5.74 / (N_Re + 1e-15) ^ 0.9");}
  _arg = ((_p_eps) / tmp37) / tmp38 + (5.74) / tmp46;

  if((_N_Re <= 0.0))
  {
    _fD = 0.0;
  }
  else
  {
    if((_N_Re <= 2100.0))
    {
      tmp47 = _N_Re;
      if (tmp47 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "64.0 / N_Re");}
      _fD = (64.0) / tmp47;
    }
    else
    {
      if((_N_Re < 2300.0))
      {
        tmp48 = _N_Re;
        tmp49 = _N_Re;
        _fD = (real_array_get(_K, 1, ((modelica_integer) 1))) * ((tmp48 * tmp48 * tmp48)) + (real_array_get(_K, 1, ((modelica_integer) 2))) * ((tmp49 * tmp49)) + (real_array_get(_K, 1, ((modelica_integer) 3))) * (_N_Re) + real_array_get(_K, 1, ((modelica_integer) 4));
      }
      else
      {
        tmp50 = _arg;
        if(!(tmp50 > 0.0))
        {
          FILE_INFO info = {"",0,0,0,0,0};
          omc_assert(threadData, info, "Model error: Argument of log10(arg) was %g should be > 0", tmp50);
        }tmp51 = (2.0) * (log10(tmp50));
        tmp52 = (tmp51 * tmp51);
        if (tmp52 == 0) {throwStreamPrint(threadData, "Division by zero %s in function context", "1.0 / (2.0 * log10(arg)) ^ 2.0");}
        _fD = (1.0) / tmp52;
      }
    }
  }
  _return: OMC_LABEL_UNUSED
  return _fD;
}
modelica_metatype boxptr_OpenHPL_Functions_DarcyFriction_fDarcy(threadData_t *threadData, modelica_metatype _N_Re, modelica_metatype _D, modelica_metatype _p_eps)
{
  modelica_real tmp1;
  modelica_real tmp2;
  modelica_real tmp3;
  modelica_real _fD;
  modelica_metatype out_fD;
  tmp1 = mmc_unbox_real(_N_Re);
  tmp2 = mmc_unbox_real(_D);
  tmp3 = mmc_unbox_real(_p_eps);
  _fD = omc_OpenHPL_Functions_DarcyFriction_fDarcy(threadData, tmp1, tmp2, tmp3);
  out_fD = mmc_mk_rcon(_fD);
  return out_fD;
}

#ifdef __cplusplus
}
#endif
