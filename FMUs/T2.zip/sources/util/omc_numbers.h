#ifndef __OMC_STRTOD
#define __OMC_STRTOD

#if defined(__cplusplus)
extern "C" {
#endif

double om_strtod(const char *nptr, char **endptr);

#if defined(__cplusplus)
}
#endif

#endif
