/* Initialization */
#include "T2_model.h"
#include "T2_11mix.h"
#include "T2_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

void T2_functionInitialEquations_0(DATA *data, threadData_t *threadData);

/*
equation index: 1
type: SIMPLE_ASSIGN
reservoir.v = 0.0
*/
void T2_eqFunction_1(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,1};
  (data->localData[0]->realVars[22]/* reservoir.v variable */)  = 0.0;
  TRACE_POP
}

/*
equation index: 2
type: SIMPLE_ASSIGN
reservoir.M = 0.0
*/
void T2_eqFunction_2(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,2};
  (data->localData[0]->realVars[17]/* reservoir.M variable */)  = 0.0;
  TRACE_POP
}

/*
equation index: 3
type: SIMPLE_ASSIGN
intake.p_o = data.p_a + data.g * data.rho * constant1.k
*/
void T2_eqFunction_3(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,3};
  (data->localData[0]->realVars[13]/* intake.p_o variable */)  = (data->simulationInfo->realParameter[13]/* data.p_a PARAM */)  + ((data->simulationInfo->realParameter[10]/* data.g PARAM */) ) * (((data->simulationInfo->realParameter[15]/* data.rho PARAM */) ) * ((data->simulationInfo->realParameter[1]/* constant1.k PARAM */) ));
  TRACE_POP
}

/*
equation index: 4
type: SIMPLE_ASSIGN
intake.D_ = 0.5 * (intake.D_i + intake.D_o)
*/
void T2_eqFunction_4(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,4};
  (data->localData[0]->realVars[5]/* intake.D_ variable */)  = (0.5) * ((data->simulationInfo->realParameter[16]/* intake.D_i PARAM */)  + (data->simulationInfo->realParameter[17]/* intake.D_o PARAM */) );
  TRACE_POP
}

/*
equation index: 5
type: SIMPLE_ASSIGN
intake.A_ = 0.7853981633974483 * intake.D_ ^ 2.0
*/
void T2_eqFunction_5(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,5};
  modelica_real tmp0;
  tmp0 = (data->localData[0]->realVars[5]/* intake.D_ variable */) ;
  (data->localData[0]->realVars[2]/* intake.A_ variable */)  = (0.7853981633974483) * ((tmp0 * tmp0));
  TRACE_POP
}

/*
equation index: 6
type: SIMPLE_ASSIGN
intake.m = data.rho * intake.A_ * intake.L
*/
void T2_eqFunction_6(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,6};
  (data->localData[0]->realVars[10]/* intake.m variable */)  = ((data->simulationInfo->realParameter[15]/* data.rho PARAM */) ) * (((data->localData[0]->realVars[2]/* intake.A_ variable */) ) * ((data->simulationInfo->realParameter[19]/* intake.L PARAM */) ));
  TRACE_POP
}

/*
equation index: 7
type: SIMPLE_ASSIGN
intake.A_i = 0.7853981633974483 * intake.D_i ^ 2.0
*/
void T2_eqFunction_7(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,7};
  modelica_real tmp1;
  tmp1 = (data->simulationInfo->realParameter[16]/* intake.D_i PARAM */) ;
  (data->localData[0]->realVars[3]/* intake.A_i variable */)  = (0.7853981633974483) * ((tmp1 * tmp1));
  TRACE_POP
}

/*
equation index: 8
type: SIMPLE_ASSIGN
intake.A_o = 0.7853981633974483 * intake.D_o ^ 2.0
*/
void T2_eqFunction_8(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,8};
  modelica_real tmp2;
  tmp2 = (data->simulationInfo->realParameter[17]/* intake.D_o PARAM */) ;
  (data->localData[0]->realVars[4]/* intake.A_o variable */)  = (0.7853981633974483) * ((tmp2 * tmp2));
  TRACE_POP
}

/*
equation index: 9
type: SIMPLE_ASSIGN
intake.cos_theta = intake.H / intake.L
*/
void T2_eqFunction_9(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,9};
  (data->localData[0]->realVars[8]/* intake.cos_theta variable */)  = DIVISION_SIM((data->simulationInfo->realParameter[18]/* intake.H PARAM */) ,(data->simulationInfo->realParameter[19]/* intake.L PARAM */) ,"intake.L",equationIndexes);
  TRACE_POP
}
extern void T2_eqFunction_36(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_37(DATA *data, threadData_t *threadData);


/*
equation index: 12
type: SIMPLE_ASSIGN
intake.Vdot = intake.Vdot_0
*/
void T2_eqFunction_12(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,12};
  (data->localData[0]->realVars[7]/* intake.Vdot variable */)  = (data->simulationInfo->realParameter[20]/* intake.Vdot_0 PARAM */) ;
  TRACE_POP
}

/*
equation index: 13
type: SIMPLE_ASSIGN
intake.M = data.rho * intake.L * intake.Vdot
*/
void T2_eqFunction_13(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,13};
  (data->localData[0]->realVars[0]/* intake.M STATE(1) */)  = ((data->simulationInfo->realParameter[15]/* data.rho PARAM */) ) * (((data->simulationInfo->realParameter[19]/* intake.L PARAM */) ) * ((data->localData[0]->realVars[7]/* intake.Vdot variable */) ));
  TRACE_POP
}
extern void T2_eqFunction_39(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_40(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_44(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_41(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_42(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_43(DATA *data, threadData_t *threadData);


/*
equation index: 20
type: SIMPLE_ASSIGN
tail.A = constant1.k * (tail.W + constant1.k * tan(tail.alpha))
*/
void T2_eqFunction_20(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,20};
  (data->localData[0]->realVars[23]/* tail.A variable */)  = ((data->simulationInfo->realParameter[1]/* constant1.k PARAM */) ) * ((data->simulationInfo->realParameter[28]/* tail.W PARAM */)  + ((data->simulationInfo->realParameter[1]/* constant1.k PARAM */) ) * (tan((data->simulationInfo->realParameter[29]/* tail.alpha PARAM */) )));
  TRACE_POP
}

/*
equation index: 21
type: SIMPLE_ASSIGN
tail.m = data.rho * tail.A * tail.L
*/
void T2_eqFunction_21(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,21};
  (data->localData[0]->realVars[28]/* tail.m variable */)  = ((data->simulationInfo->realParameter[15]/* data.rho PARAM */) ) * (((data->localData[0]->realVars[23]/* tail.A variable */) ) * ((data->simulationInfo->realParameter[27]/* tail.L PARAM */) ));
  TRACE_POP
}

/*
equation index: 22
type: SIMPLE_ASSIGN
tail.v = 0.0
*/
void T2_eqFunction_22(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,22};
  (data->localData[0]->realVars[30]/* tail.v variable */)  = 0.0;
  TRACE_POP
}

/*
equation index: 23
type: SIMPLE_ASSIGN
tail.M = 0.0
*/
void T2_eqFunction_23(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,23};
  (data->localData[0]->realVars[25]/* tail.M variable */)  = 0.0;
  TRACE_POP
}

/*
equation index: 24
type: SIMPLE_ASSIGN
tail.mdot = 0.0
*/
void T2_eqFunction_24(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,24};
  (data->localData[0]->realVars[29]/* tail.mdot variable */)  = 0.0;
  TRACE_POP
}

/*
equation index: 25
type: SIMPLE_ASSIGN
reservoir.mdot = 0.0
*/
void T2_eqFunction_25(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,25};
  (data->localData[0]->realVars[21]/* reservoir.mdot variable */)  = 0.0;
  TRACE_POP
}

/*
equation index: 26
type: SIMPLE_ASSIGN
reservoir.Vdot = 0.0
*/
void T2_eqFunction_26(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,26};
  (data->localData[0]->realVars[18]/* reservoir.Vdot variable */)  = 0.0;
  TRACE_POP
}

/*
equation index: 27
type: SIMPLE_ASSIGN
tail.Vdot = 0.0
*/
void T2_eqFunction_27(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,27};
  (data->localData[0]->realVars[26]/* tail.Vdot variable */)  = 0.0;
  TRACE_POP
}

/*
equation index: 28
type: SIMPLE_ASSIGN
reservoir.A = u * (reservoir.W + u * tan(reservoir.alpha))
*/
void T2_eqFunction_28(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,28};
  (data->localData[0]->realVars[15]/* reservoir.A variable */)  = ((data->localData[0]->realVars[31]/* u variable */) ) * ((data->simulationInfo->realParameter[23]/* reservoir.W PARAM */)  + ((data->localData[0]->realVars[31]/* u variable */) ) * (tan((data->simulationInfo->realParameter[24]/* reservoir.alpha PARAM */) )));
  TRACE_POP
}
extern void T2_eqFunction_35(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_33(DATA *data, threadData_t *threadData);

extern void T2_eqFunction_32(DATA *data, threadData_t *threadData);

OMC_DISABLE_OPT
void T2_functionInitialEquations_0(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  T2_eqFunction_1(data, threadData);
  T2_eqFunction_2(data, threadData);
  T2_eqFunction_3(data, threadData);
  T2_eqFunction_4(data, threadData);
  T2_eqFunction_5(data, threadData);
  T2_eqFunction_6(data, threadData);
  T2_eqFunction_7(data, threadData);
  T2_eqFunction_8(data, threadData);
  T2_eqFunction_9(data, threadData);
  T2_eqFunction_36(data, threadData);
  T2_eqFunction_37(data, threadData);
  T2_eqFunction_12(data, threadData);
  T2_eqFunction_13(data, threadData);
  T2_eqFunction_39(data, threadData);
  T2_eqFunction_40(data, threadData);
  T2_eqFunction_44(data, threadData);
  T2_eqFunction_41(data, threadData);
  T2_eqFunction_42(data, threadData);
  T2_eqFunction_43(data, threadData);
  T2_eqFunction_20(data, threadData);
  T2_eqFunction_21(data, threadData);
  T2_eqFunction_22(data, threadData);
  T2_eqFunction_23(data, threadData);
  T2_eqFunction_24(data, threadData);
  T2_eqFunction_25(data, threadData);
  T2_eqFunction_26(data, threadData);
  T2_eqFunction_27(data, threadData);
  T2_eqFunction_28(data, threadData);
  T2_eqFunction_35(data, threadData);
  T2_eqFunction_33(data, threadData);
  T2_eqFunction_32(data, threadData);
  TRACE_POP
}

int T2_functionInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->discreteCall = 1;
  T2_functionInitialEquations_0(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}

/* No T2_functionInitialEquations_lambda0 function */

int T2_functionRemovedInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int *equationIndexes = NULL;
  double res = 0.0;

  
  TRACE_POP
  return 0;
}


#if defined(__cplusplus)
}
#endif

