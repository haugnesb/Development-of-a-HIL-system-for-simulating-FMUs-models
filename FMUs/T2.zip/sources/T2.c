/* Main Simulation File */

#if defined(__cplusplus)
extern "C" {
#endif

#include "T2_model.h"
#include "simulation/solver/events.h"



/* dummy VARINFO and FILEINFO */
const FILE_INFO dummyFILE_INFO = omc_dummyFileInfo;
const VAR_INFO dummyVAR_INFO = omc_dummyVarInfo;

int T2_input_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  (data->localData[0]->realVars[31]/* u variable */)  = data->simulationInfo->inputVars[0];
  
  TRACE_POP
  return 0;
}

int T2_input_function_init(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->inputVars[0] = data->modelData->realVarsData[31].attribute.start;
  
  TRACE_POP
  return 0;
}

int T2_input_function_updateStartValues(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->modelData->realVarsData[31].attribute.start = data->simulationInfo->inputVars[0];
  
  TRACE_POP
  return 0;
}

int T2_inputNames(DATA *data, char ** names){
  TRACE_PUSH

  names[0] = (char *) data->modelData->realVarsData[31].info.name;
  
  TRACE_POP
  return 0;
}

int T2_data_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  TRACE_POP
  return 0;
}

int T2_dataReconciliationInputNames(DATA *data, char ** names){
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int T2_output_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int T2_setc_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}


/*
equation index: 32
type: SIMPLE_ASSIGN
tail.F_f = 0.0
*/
void T2_eqFunction_32(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,32};
  (data->localData[0]->realVars[24]/* tail.F_f variable */)  = 0.0;
  TRACE_POP
}
/*
equation index: 33
type: SIMPLE_ASSIGN
reservoir.F_f = 0.0
*/
void T2_eqFunction_33(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,33};
  (data->localData[0]->realVars[16]/* reservoir.F_f variable */)  = 0.0;
  TRACE_POP
}
/*
equation index: 34
type: SIMPLE_ASSIGN
reservoir.A = u * (reservoir.W + u * $cse1)
*/
void T2_eqFunction_34(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,34};
  (data->localData[0]->realVars[15]/* reservoir.A variable */)  = ((data->localData[0]->realVars[31]/* u variable */) ) * ((data->simulationInfo->realParameter[23]/* reservoir.W PARAM */)  + ((data->localData[0]->realVars[31]/* u variable */) ) * ((data->simulationInfo->realParameter[0]/* $cse1 PARAM */) ));
  TRACE_POP
}
/*
equation index: 35
type: SIMPLE_ASSIGN
reservoir.m = data.rho * reservoir.A * reservoir.L
*/
void T2_eqFunction_35(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,35};
  (data->localData[0]->realVars[20]/* reservoir.m variable */)  = ((data->simulationInfo->realParameter[15]/* data.rho PARAM */) ) * (((data->localData[0]->realVars[15]/* reservoir.A variable */) ) * ((data->simulationInfo->realParameter[22]/* reservoir.L PARAM */) ));
  TRACE_POP
}
/*
equation index: 36
type: SIMPLE_ASSIGN
intake.p_i = data.p_a + data.g * data.rho * u
*/
void T2_eqFunction_36(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,36};
  (data->localData[0]->realVars[12]/* intake.p_i variable */)  = (data->simulationInfo->realParameter[13]/* data.p_a PARAM */)  + ((data->simulationInfo->realParameter[10]/* data.g PARAM */) ) * (((data->simulationInfo->realParameter[15]/* data.rho PARAM */) ) * ((data->localData[0]->realVars[31]/* u variable */) ));
  TRACE_POP
}
/*
equation index: 37
type: SIMPLE_ASSIGN
intake.dp = intake.p_o - intake.p_i
*/
void T2_eqFunction_37(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,37};
  (data->localData[0]->realVars[9]/* intake.dp variable */)  = (data->localData[0]->realVars[13]/* intake.p_o variable */)  - (data->localData[0]->realVars[12]/* intake.p_i variable */) ;
  TRACE_POP
}
/*
equation index: 38
type: SIMPLE_ASSIGN
intake.Vdot = intake.M / (data.rho * intake.L)
*/
void T2_eqFunction_38(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,38};
  (data->localData[0]->realVars[7]/* intake.Vdot variable */)  = DIVISION_SIM((data->localData[0]->realVars[0]/* intake.M STATE(1) */) ,((data->simulationInfo->realParameter[15]/* data.rho PARAM */) ) * ((data->simulationInfo->realParameter[19]/* intake.L PARAM */) ),"data.rho * intake.L",equationIndexes);
  TRACE_POP
}
/*
equation index: 39
type: SIMPLE_ASSIGN
intake.v = intake.Vdot / intake.A_
*/
void T2_eqFunction_39(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,39};
  (data->localData[0]->realVars[14]/* intake.v variable */)  = DIVISION_SIM((data->localData[0]->realVars[7]/* intake.Vdot variable */) ,(data->localData[0]->realVars[2]/* intake.A_ variable */) ,"intake.A_",equationIndexes);
  TRACE_POP
}
/*
equation index: 40
type: SIMPLE_ASSIGN
intake.F_f = OpenHPL.Functions.DarcyFriction.Friction(intake.v, intake.D_, intake.L, data.rho, data.mu, intake.p_eps)
*/
void T2_eqFunction_40(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,40};
  (data->localData[0]->realVars[6]/* intake.F_f variable */)  = omc_OpenHPL_Functions_DarcyFriction_Friction(threadData, (data->localData[0]->realVars[14]/* intake.v variable */) , (data->localData[0]->realVars[5]/* intake.D_ variable */) , (data->simulationInfo->realParameter[19]/* intake.L PARAM */) , (data->simulationInfo->realParameter[15]/* data.rho PARAM */) , (data->simulationInfo->realParameter[12]/* data.mu PARAM */) , (data->simulationInfo->realParameter[21]/* intake.p_eps PARAM */) );
  TRACE_POP
}
/*
equation index: 41
type: SIMPLE_ASSIGN
intake.mdot = intake.Vdot * data.rho
*/
void T2_eqFunction_41(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,41};
  (data->localData[0]->realVars[11]/* intake.mdot variable */)  = ((data->localData[0]->realVars[7]/* intake.Vdot variable */) ) * ((data->simulationInfo->realParameter[15]/* data.rho PARAM */) );
  TRACE_POP
}
/*
equation index: 42
type: SIMPLE_ASSIGN
tail.Vdot_i = (-intake.mdot) / data.rho
*/
void T2_eqFunction_42(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,42};
  (data->localData[0]->realVars[27]/* tail.Vdot_i variable */)  = DIVISION_SIM((-(data->localData[0]->realVars[11]/* intake.mdot variable */) ),(data->simulationInfo->realParameter[15]/* data.rho PARAM */) ,"data.rho",equationIndexes);
  TRACE_POP
}
/*
equation index: 43
type: SIMPLE_ASSIGN
reservoir.Vdot_i = intake.mdot / data.rho
*/
void T2_eqFunction_43(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,43};
  (data->localData[0]->realVars[19]/* reservoir.Vdot_i variable */)  = DIVISION_SIM((data->localData[0]->realVars[11]/* intake.mdot variable */) ,(data->simulationInfo->realParameter[15]/* data.rho PARAM */) ,"data.rho",equationIndexes);
  TRACE_POP
}
/*
equation index: 44
type: SIMPLE_ASSIGN
$DER.intake.M = data.rho * intake.Vdot ^ 2.0 * (1.0 / intake.A_i + (-1.0) / intake.A_o) + intake.p_i * intake.A_i + intake.m * data.g * intake.cos_theta - intake.F_f - intake.p_o * intake.A_o
*/
void T2_eqFunction_44(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,44};
  modelica_real tmp0;
  tmp0 = (data->localData[0]->realVars[7]/* intake.Vdot variable */) ;
  (data->localData[0]->realVars[1]/* der(intake.M) STATE_DER */)  = ((data->simulationInfo->realParameter[15]/* data.rho PARAM */) ) * (((tmp0 * tmp0)) * (DIVISION_SIM(1.0,(data->localData[0]->realVars[3]/* intake.A_i variable */) ,"intake.A_i",equationIndexes) + DIVISION_SIM(-1.0,(data->localData[0]->realVars[4]/* intake.A_o variable */) ,"intake.A_o",equationIndexes))) + ((data->localData[0]->realVars[12]/* intake.p_i variable */) ) * ((data->localData[0]->realVars[3]/* intake.A_i variable */) ) + ((data->localData[0]->realVars[10]/* intake.m variable */) ) * (((data->simulationInfo->realParameter[10]/* data.g PARAM */) ) * ((data->localData[0]->realVars[8]/* intake.cos_theta variable */) )) - (data->localData[0]->realVars[6]/* intake.F_f variable */)  - (((data->localData[0]->realVars[13]/* intake.p_o variable */) ) * ((data->localData[0]->realVars[4]/* intake.A_o variable */) ));
  TRACE_POP
}

OMC_DISABLE_OPT
int T2_functionDAE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  int equationIndexes[1] = {0};
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_DAE);
#endif

  data->simulationInfo->needToIterate = 0;
  data->simulationInfo->discreteCall = 1;
  T2_functionLocalKnownVars(data, threadData);
  T2_eqFunction_32(data, threadData);

  T2_eqFunction_33(data, threadData);

  T2_eqFunction_34(data, threadData);

  T2_eqFunction_35(data, threadData);

  T2_eqFunction_36(data, threadData);

  T2_eqFunction_37(data, threadData);

  T2_eqFunction_38(data, threadData);

  T2_eqFunction_39(data, threadData);

  T2_eqFunction_40(data, threadData);

  T2_eqFunction_41(data, threadData);

  T2_eqFunction_42(data, threadData);

  T2_eqFunction_43(data, threadData);

  T2_eqFunction_44(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_DAE);
#endif
  TRACE_POP
  return 0;
}


int T2_functionLocalKnownVars(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}


/* forwarded equations */
extern void T2_eqFunction_36(DATA* data, threadData_t *threadData);
extern void T2_eqFunction_38(DATA* data, threadData_t *threadData);
extern void T2_eqFunction_39(DATA* data, threadData_t *threadData);
extern void T2_eqFunction_40(DATA* data, threadData_t *threadData);
extern void T2_eqFunction_44(DATA* data, threadData_t *threadData);

static void functionODE_system0(DATA *data, threadData_t *threadData)
{
  {
    T2_eqFunction_36(data, threadData);
    threadData->lastEquationSolved = 36;
  }
  {
    T2_eqFunction_38(data, threadData);
    threadData->lastEquationSolved = 38;
  }
  {
    T2_eqFunction_39(data, threadData);
    threadData->lastEquationSolved = 39;
  }
  {
    T2_eqFunction_40(data, threadData);
    threadData->lastEquationSolved = 40;
  }
  {
    T2_eqFunction_44(data, threadData);
    threadData->lastEquationSolved = 44;
  }
}

int T2_functionODE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_tick(SIM_TIMER_FUNCTION_ODE);
#endif

  
  data->simulationInfo->callStatistics.functionODE++;
  
  T2_functionLocalKnownVars(data, threadData);
  functionODE_system0(data, threadData);

#if !defined(OMC_MINIMAL_RUNTIME)
  if (measure_time_flag) rt_accumulate(SIM_TIMER_FUNCTION_ODE);
#endif

  TRACE_POP
  return 0;
}

/* forward the main in the simulation runtime */
extern int _main_SimulationRuntime(int argc, char**argv, DATA *data, threadData_t *threadData);

#include "T2_12jac.h"
#include "T2_13opt.h"

struct OpenModelicaGeneratedFunctionCallbacks T2_callback = {
   NULL,    /* performSimulation */
   NULL,    /* performQSSSimulation */
   NULL,    /* updateContinuousSystem */
   T2_callExternalObjectDestructors,    /* callExternalObjectDestructors */
   NULL,    /* initialNonLinearSystem */
   NULL,    /* initialLinearSystem */
   NULL,    /* initialMixedSystem */
   #if !defined(OMC_NO_STATESELECTION)
   T2_initializeStateSets,
   #else
   NULL,
   #endif    /* initializeStateSets */
   T2_initializeDAEmodeData,
   T2_functionODE,
   T2_functionAlgebraics,
   T2_functionDAE,
   T2_functionLocalKnownVars,
   T2_input_function,
   T2_input_function_init,
   T2_input_function_updateStartValues,
   T2_data_function,
   T2_output_function,
   T2_setc_function,
   T2_function_storeDelayed,
   T2_function_storeSpatialDistribution,
   T2_function_initSpatialDistribution,
   T2_updateBoundVariableAttributes,
   T2_functionInitialEquations,
   1, /* useHomotopy - 0: local homotopy (equidistant lambda), 1: global homotopy (equidistant lambda), 2: new global homotopy approach (adaptive lambda), 3: new local homotopy approach (adaptive lambda)*/
   NULL,
   T2_functionRemovedInitialEquations,
   T2_updateBoundParameters,
   T2_checkForAsserts,
   T2_function_ZeroCrossingsEquations,
   T2_function_ZeroCrossings,
   T2_function_updateRelations,
   T2_zeroCrossingDescription,
   T2_relationDescription,
   T2_function_initSample,
   T2_INDEX_JAC_A,
   T2_INDEX_JAC_B,
   T2_INDEX_JAC_C,
   T2_INDEX_JAC_D,
   T2_INDEX_JAC_F,
   T2_initialAnalyticJacobianA,
   T2_initialAnalyticJacobianB,
   T2_initialAnalyticJacobianC,
   T2_initialAnalyticJacobianD,
   T2_initialAnalyticJacobianF,
   T2_functionJacA_column,
   T2_functionJacB_column,
   T2_functionJacC_column,
   T2_functionJacD_column,
   T2_functionJacF_column,
   T2_linear_model_frame,
   T2_linear_model_datarecovery_frame,
   T2_mayer,
   T2_lagrange,
   T2_pickUpBoundsForInputsInOptimization,
   T2_setInputData,
   T2_getTimeGrid,
   T2_symbolicInlineSystem,
   T2_function_initSynchronous,
   T2_function_updateSynchronous,
   T2_function_equationsSynchronous,
   T2_inputNames,
   T2_dataReconciliationInputNames,
   T2_read_input_fmu,
   NULL,
   NULL,
   -1,
   NULL,
   NULL,
   -1

};

#define _OMC_LIT_RESOURCE_0_name_data "Complex"
#define _OMC_LIT_RESOURCE_0_dir_data "C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Complex 4.0.0+maint.om"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_0_name,7,_OMC_LIT_RESOURCE_0_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_0_dir,77,_OMC_LIT_RESOURCE_0_dir_data);

#define _OMC_LIT_RESOURCE_1_name_data "Modelica"
#define _OMC_LIT_RESOURCE_1_dir_data "C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/Modelica 4.0.0+maint.om"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_1_name,8,_OMC_LIT_RESOURCE_1_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_1_dir,78,_OMC_LIT_RESOURCE_1_dir_data);

#define _OMC_LIT_RESOURCE_2_name_data "ModelicaServices"
#define _OMC_LIT_RESOURCE_2_dir_data "C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/ModelicaServices 4.0.0+maint.om"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_2_name,16,_OMC_LIT_RESOURCE_2_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_2_dir,86,_OMC_LIT_RESOURCE_2_dir_data);

#define _OMC_LIT_RESOURCE_3_name_data "OpenHPL"
#define _OMC_LIT_RESOURCE_3_dir_data "C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenHPL 2.0.1"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_3_name,7,_OMC_LIT_RESOURCE_3_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_3_dir,68,_OMC_LIT_RESOURCE_3_dir_data);

#define _OMC_LIT_RESOURCE_4_name_data "OpenIPSL"
#define _OMC_LIT_RESOURCE_4_dir_data "C:/Users/haugn/AppData/Roaming/.openmodelica/libraries/OpenIPSL 3.0.1"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_4_name,8,_OMC_LIT_RESOURCE_4_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_4_dir,69,_OMC_LIT_RESOURCE_4_dir_data);

#define _OMC_LIT_RESOURCE_5_name_data "T2"
#define _OMC_LIT_RESOURCE_5_dir_data "."
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_5_name,2,_OMC_LIT_RESOURCE_5_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_5_dir,1,_OMC_LIT_RESOURCE_5_dir_data);

#define _OMC_LIT_RESOURCE_6_name_data "TestPackage"
#define _OMC_LIT_RESOURCE_6_dir_data "C:/Users/haugn/OneDrive/Dokumenter/Master/FMU_Models/Modelica_files"
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_6_name,11,_OMC_LIT_RESOURCE_6_name_data);
static const MMC_DEFSTRINGLIT(_OMC_LIT_RESOURCE_6_dir,67,_OMC_LIT_RESOURCE_6_dir_data);

static const MMC_DEFSTRUCTLIT(_OMC_LIT_RESOURCES,14,MMC_ARRAY_TAG) {MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_0_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_0_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_1_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_1_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_2_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_2_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_3_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_3_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_4_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_4_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_5_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_5_dir), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_6_name), MMC_REFSTRINGLIT(_OMC_LIT_RESOURCE_6_dir)}};
void T2_setupDataStruc(DATA *data, threadData_t *threadData)
{
  assertStreamPrint(threadData,0!=data, "Error while initialize Data");
  threadData->localRoots[LOCAL_ROOT_SIMULATION_DATA] = data;
  data->callback = &T2_callback;
  OpenModelica_updateUriMapping(threadData, MMC_REFSTRUCTLIT(_OMC_LIT_RESOURCES));
  data->modelData->modelName = "T2";
  data->modelData->modelFilePrefix = "T2";
  data->modelData->resultFileName = NULL;
  data->modelData->modelDir = "";
  data->modelData->modelGUID = "{a7a3f9b3-0d1b-4dc7-8b8b-7a5cdaf582f8}";
  data->modelData->initXMLData = NULL;
  data->modelData->modelDataXml.infoXMLData = NULL;
  data->modelData->runTestsuite = 0;
  
  data->modelData->nStates = 1;
  data->modelData->nVariablesReal = 32;
  data->modelData->nDiscreteReal = 0;
  data->modelData->nVariablesInteger = 0;
  data->modelData->nVariablesBoolean = 0;
  data->modelData->nVariablesString = 0;
  data->modelData->nParametersReal = 34;
  data->modelData->nParametersInteger = 0;
  data->modelData->nParametersBoolean = 8;
  data->modelData->nParametersString = 0;
  data->modelData->nInputVars = 1;
  data->modelData->nOutputVars = 0;
  
  data->modelData->nAliasReal = 14;
  data->modelData->nAliasInteger = 0;
  data->modelData->nAliasBoolean = 0;
  data->modelData->nAliasString = 0;
  
  data->modelData->nZeroCrossings = 0;
  data->modelData->nSamples = 0;
  data->modelData->nRelations = 0;
  data->modelData->nMathEvents = 0;
  data->modelData->nExtObjs = 0;
  
  GC_asprintf(&data->modelData->modelDataXml.fileName, "%s/T2_info.json", data->modelData->resourcesDir);
  data->modelData->modelDataXml.modelInfoXmlLength = 0;
  data->modelData->modelDataXml.nFunctions = 5;
  data->modelData->modelDataXml.nProfileBlocks = 0;
  data->modelData->modelDataXml.nEquations = 89;
  data->modelData->nMixedSystems = 0;
  data->modelData->nLinearSystems = 0;
  data->modelData->nNonLinearSystems = 0;
  data->modelData->nStateSets = 0;
  data->modelData->nJacobians = 5;
  data->modelData->nOptimizeConstraints = 0;
  data->modelData->nOptimizeFinalConstraints = 0;
  
  data->modelData->nDelayExpressions = 0;
  
  data->modelData->nBaseClocks = 0;
  
  data->modelData->nSpatialDistributions = 0;
  
  data->modelData->nSensitivityVars = 0;
  data->modelData->nSensitivityParamVars = 0;
  data->modelData->nSetcVars = 0;
  data->modelData->ndataReconVars = 0;
  data->modelData->linearizationDumpLanguage =
  OMC_LINEARIZE_DUMP_LANGUAGE_MODELICA;
}

static int rml_execution_failed()
{
  fflush(NULL);
  fprintf(stderr, "Execution failed!\n");
  fflush(NULL);
  return 1;
}

